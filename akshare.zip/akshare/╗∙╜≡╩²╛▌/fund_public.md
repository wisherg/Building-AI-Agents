# 公募基金数据

```python
import akshare as ak
```

## fund_name_em
描述: 东方财富网-天天基金网-基金数据-所有基金的基本信息数据
输入: 无
输出: 基金代码, 拼音缩写, 基金简称, 基金类型, 拼音全称

```python
df = ak.fund_name_em()
```

## fund_info_ths
描述: 同花顺-基金数据-基金基本信息
输入: symbol - 基金代码
输出: 字段, 值

```python
df = ak.fund_info_ths(symbol="161130")
```

## fund_individual_basic_info_xq
描述: 雪球基金-基金详情
输入: symbol - 基金代码; timeout - 超时时间
输出: item, value

```python
df = ak.fund_individual_basic_info_xq(symbol="000001")
```

## fund_info_index_em
描述: 东方财富网-天天基金网-基金数据-基金基本信息-指数型
输入: symbol - 指数类型; indicator - 指标类型
输出: 基金代码, 基金名称, 单位净值, 日期, 日增长率, 近1周, 近1月, 近3月, 近6月, 近1年, 近2年, 近3年, 今年来, 成立来, 手续费, 起购金额, 跟踪标的, 跟踪方式

```python
df = ak.fund_info_index_em(symbol="沪深指数", indicator="增强指数型")
```

## fund_purchase_em
描述: 东方财富网站-天天基金网-基金数据-基金申购状态
输入: 无
输出: 序号, 基金代码, 基金简称, 基金类型, 最新净值/万份收益, 最新净值/万份收益-报告时间, 申购状态, 赎回状态, 下一开放日, 购买起点, 日累计限定金额, 手续费

```python
df = ak.fund_purchase_em()
```

## fund_etf_spot_em
描述: 东方财富-ETF 实时行情
输入: 无
输出: 代码, 名称, 最新价, IOPV实时估值, 基金折价率, 涨跌额, 涨跌幅, 成交量, 成交额, 开盘价, 最高价, 最低价, 昨收, 换手率, 量比, 委比, 外盘, 内盘, 主力净流入-净额, 主力净流入-净占比, 超大单净流入-净额, 超大单净流入-净占比, 大单净流入-净额, 大单净流入-净占比, 中单净流入-净额, 中单净流入-净占比, 小单净流入-净额, 小单净流入-净占比, 现手, 买一, 卖一, 最新份额, 流通市值, 总市值, 数据日期, 更新时间

```python
df = ak.fund_etf_spot_em()
```

## fund_etf_category_ths
描述: 同花顺理财-基金数据-每日净值-实时行情
输入: symbol - 基金类型; date - 查询日期
输出: 序号, 基金代码, 基金名称, 当前-单位净值, 当前-累计净值, 前一日-单位净值, 前一日-累计净值, 增长值, 增长率, 赎回状态, 申购状态, 最新-交易日, 最新-单位净值, 最新-累计净值, 基金类型, 查询日期

```python
df = ak.fund_etf_category_ths(symbol="ETF", date="20240620")
```

## fund_etf_spot_ths
描述: 同花顺理财-基金数据-每日净值-ETF-实时行情
输入: date - 查询日期
输出: 序号, 基金代码, 基金名称, 当前-单位净值, 当前-累计净值, 前一日-单位净值, 前一日-累计净值, 增长值, 增长率, 赎回状态, 申购状态, 最新-交易日, 最新-单位净值, 最新-累计净值, 基金类型, 查询日期

```python
df = ak.fund_etf_spot_ths(date="20240620")
```

## fund_lof_spot_em
描述: 东方财富-LOF 实时行情
输入: 无
输出: 代码, 名称, 最新价, 涨跌额, 涨跌幅, 成交量, 成交额, 开盘价, 最高价, 最低价, 昨收, 换手率, 流通市值, 总市值

```python
df = ak.fund_lof_spot_em()
```

## fund_etf_category_sina
描述: 新浪财经-基金列表及行情数据
输入: symbol - 基金类型; choice of {"封闭式基金", "ETF基金", "LOF基金"}
输出: 代码, 名称, 最新价, 涨跌额, 涨跌幅, 买入, 卖出, 昨收, 今开, 最高, 最低, 成交量, 成交额

```python
df = ak.fund_etf_category_sina(symbol="LOF基金")
```

## fund_etf_hist_min_em
描述: 东方财富-ETF 分时行情; 1分钟数据只返回近5个交易日且不复权
输入: symbol - ETF代码; start_date - 开始时间; end_date - 结束时间; period - 频率{'1','5','15','30','60'}; adjust - 复权{'','qfq','hfq'}
输出: 时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 均价(1分钟); 或 时间, 开盘, 收盘, 最高, 最低, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 换手率(其他)

```python
df = ak.fund_etf_hist_min_em(symbol="513500", period="5", adjust="hfq", start_date="2023-12-11 09:32:00", end_date="2023-12-11 17:40:00")
```

## fund_lof_hist_min_em
描述: 东方财富-LOF 分时行情; 1分钟数据只返回近5个交易日且不复权
输入: symbol - LOF代码; start_date - 开始时间; end_date - 结束时间; period - 频率{'1','5','15','30','60'}; adjust - 复权{'','qfq','hfq'}
输出: 时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 均价(1分钟); 或 时间, 开盘, 收盘, 最高, 最低, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 换手率(其他)

```python
df = ak.fund_lof_hist_min_em(symbol="166009", period="5", adjust="hfq", start_date="2023-07-01 09:32:00", end_date="2023-07-04 14:40:00")
```

## fund_etf_hist_em
描述: 东方财富-ETF 行情; 历史数据按日频率更新
输入: symbol - ETF代码; period - 周期{'daily','weekly','monthly'}; start_date - 开始日期; end_date - 结束日期; adjust - 复权{'','qfq','hfq'}
输出: 日期, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 振幅, 涨跌幅, 涨跌额, 换手率

```python
df = ak.fund_etf_hist_em(symbol="513500", period="daily", start_date="20000101", end_date="20230201", adjust="")
```

## fund_lof_hist_em
描述: 东方财富-LOF 行情; 历史数据按日频率更新
输入: symbol - LOF代码; period - 周期{'daily','weekly','monthly'}; start_date - 开始日期; end_date - 结束日期; adjust - 复权{'','qfq','hfq'}
输出: 日期, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 振幅, 涨跌幅, 涨跌额, 换手率

```python
df = ak.fund_lof_hist_em(symbol="166009", period="daily", start_date="20000101", end_date="20230703", adjust="")
```

## fund_etf_hist_sina
描述: 新浪财经-基金行情的日频率行情数据
输入: symbol - 基金代码; 如"sh510050"
输出: date, open, high, low, close, volume

```python
df = ak.fund_etf_hist_sina(symbol="sh510050")
```

## fund_open_fund_daily_em
描述: 东方财富网-天天基金网-基金数据-开放式基金实时数据; 每个交易日16:00-23:00更新
输入: 无
输出: 基金代码, 基金简称, 单位净值, 累计净值, 前交易日-单位净值, 前交易日-累计净值, 日增长值, 日增长率, 申购状态, 赎回状态, 手续费

```python
df = ak.fund_open_fund_daily_em()
```

## fund_open_fund_info_em
描述: 东方财富网-天天基金网-基金数据-具体基金信息
输入: symbol - 基金代码; indicator - 指标; period - 周期(仅累计收益率走势有效)
输出: 按indicator不同返回不同字段: 单位净值走势(净值日期,单位净值,日增长率); 累计净值走势(净值日期,累计净值); 累计收益率走势(日期,累计收益率); 同类排名走势(报告日期,同类型排名,总排名); 同类排名百分比(报告日期,排名百分比); 分红送配详情(年份,权益登记日,除息日,每份分红,分红发放日); 拆分详情(年份,拆分折算日,拆分类型,拆分折算比例)

```python
df = ak.fund_open_fund_info_em(symbol="710001", indicator="单位净值走势")
```

## fund_money_fund_daily_em
描述: 东方财富网-天天基金网-基金数据-货币型基金收益; 每个交易日16:00-23:00更新
输入: 无
输出: 基金代码, 基金简称, 当前交易日-万份收益, 当前交易日-7日年化%, 当前交易日-单位净值, 前一交易日-万份收益, 前一交易日-7日年化%, 前一交易日-单位净值, 日涨幅, 成立日期, 基金经理, 手续费, 可购全部

```python
df = ak.fund_money_fund_daily_em()
```

## fund_money_fund_info_em
描述: 东方财富网-天天基金网-基金数据-货币型基金-历史净值
输入: symbol - 基金代码
输出: 净值日期, 每万份收益, 7日年化收益率, 申购状态, 赎回状态

```python
df = ak.fund_money_fund_info_em(symbol="000009")
```

## fund_financial_fund_daily_em
描述: 东方财富网-天天基金网-基金数据-理财型基金-实时数据
输入: 无
输出: 序号, 基金代码, 基金简称, 上一期年化收益率, 当前交易日-万份收益, 当前交易日-7日年华, 前一个交易日-万份收益, 前一个交易日-7日年华, 封闭期, 申购状态

```python
df = ak.fund_financial_fund_daily_em()
```

## fund_financial_fund_info_em
描述: 东方财富网站-天天基金网-基金数据-理财型基金收益-历史净值明细
输入: symbol - 基金代码
输出: 净值日期, 单位净值, 累计净值, 日增长率, 申购状态, 赎回状态, 分红送配

```python
df = ak.fund_financial_fund_info_em(symbol="000134")
```

## fund_graded_fund_daily_em
描述: 东方财富网-天天基金网-基金数据-分级基金-实时数据
输入: 无
输出: 基金代码, 基金简称, 单位净值, 累计净值, 前交易日-单位净值, 前交易日-累计净值, 日增长值, 日增长率, 市价, 折价率, 手续费

```python
df = ak.fund_graded_fund_daily_em()
```

## fund_graded_fund_info_em
描述: 东方财富网站-天天基金网-基金数据-分级基金-历史数据
输入: symbol - 基金代码
输出: 净值日期, 单位净值, 累计净值, 日增长率, 申购状态, 赎回状态

```python
df = ak.fund_graded_fund_info_em(symbol="150232")
```

## fund_etf_fund_daily_em
描述: 东方财富网站-天天基金网-基金数据-场内交易基金-实时数据
输入: 无
输出: 基金代码, 基金简称, 类型, 当前交易日-单位净值, 当前交易日-累计净值, 前一个交易日-单位净值, 前一个交易日-累计净值, 增长值, 增长率, 市价, 折价率

```python
df = ak.fund_etf_fund_daily_em()
```

## fund_etf_fund_info_em
描述: 东方财富网站-天天基金网-基金数据-场内交易基金-历史净值数据
输入: fund - 基金代码; start_date - 开始时间; end_date - 结束时间
输出: 净值日期, 单位净值, 累计净值, 日增长率, 申购状态, 赎回状态

```python
df = ak.fund_etf_fund_info_em(fund="511280", start_date="20000101", end_date="20500101")
```

## fund_hk_fund_hist_em
描述: 东方财富网站-天天基金网-基金数据-香港基金-历史净值明细
输入: code - 香港基金代码; symbol - 类型{"历史净值明细","分红送配详情"}
输出: 历史净值明细(净值日期,单位净值,日增长值,日增长率,单位); 分红送配详情(年份,权益登记日,除息日,分红发放日,分红金额,单位)

```python
df = ak.fund_hk_fund_hist_em(code='1002200683', symbol="历史净值明细")
```

## fund_etf_dividend_sina
描述: 新浪财经-基金-ETF 基金-累计分红
输入: symbol - 基金代码; 如"sh510050"
输出: 日期, 累计分红

```python
df = ak.fund_etf_dividend_sina(symbol="sh510050")
```

## fund_fh_em
描述: 天天基金网-基金数据-分红送配-基金分红
输入: year - 年份; typ - 基金类型; rank - 排序字段; sort - 排序方式; page - 页码
输出: 序号, 基金代码, 基金简称, 权益登记日, 除息日期, 分红, 分红发放日

```python
df = ak.fund_fh_em(year="2025")
```

## fund_cf_em
描述: 天天基金网-基金数据-分红送配-基金拆分
输入: year - 年份; typ - 基金类型; rank - 排序字段; sort - 排序方式; page - 页码
输出: 序号, 基金代码, 基金简称, 拆分折算日, 拆分类型, 拆分折算

```python
df = ak.fund_cf_em(year="2025")
```

## fund_fh_rank_em
描述: 天天基金网-基金数据-分红送配-基金分红排行
输入: 无
输出: 序号, 基金代码, 基金简称, 累计分红, 累计次数, 成立日期

```python
df = ak.fund_fh_rank_em()
```

## fund_open_fund_rank_em
描述: 东方财富网-数据中心-开放式基金排行
输入: symbol - 基金类型; {"全部","股票型","混合型","债券型","指数型","QDII","FOF"}
输出: 序号, 基金代码, 基金简称, 日期, 单位净值, 累计净值, 日增长率, 近1周, 近1月, 近3月, 近6月, 近1年, 近2年, 近3年, 今年来, 成立来, 自定义, 手续费

```python
df = ak.fund_open_fund_rank_em(symbol="全部")
```

## fund_exchange_rank_em
描述: 东方财富网-数据中心-场内交易基金排行榜
输入: 无
输出: 序号, 基金代码, 基金简称, 类型, 日期, 单位净值, 累计净值, 近1周, 近1月, 近3月, 近6月, 近1年, 近2年, 近3年, 今年来, 成立来, 成立日期

```python
df = ak.fund_exchange_rank_em()
```

## fund_money_rank_em
描述: 东方财富网-数据中心-货币型基金排行
输入: 无
输出: 序号, 基金代码, 基金简称, 日期, 万份收益, 年化收益率7日, 年化收益率14日, 年化收益率28日, 近1月, 近3月, 近6月, 近1年, 近2年, 近3年, 近5年, 今年来, 成立来, 手续费

```python
df = ak.fund_money_rank_em()
```

## fund_lcx_rank_em
描述: 东方财富网-数据中心-理财基金排行
输入: 无
输出: 序号, 基金代码, 基金简称, 日期, 万份收益, 年化收益率7日, 年化收益率14日, 年化收益率28日, 近1周, 近1月, 近3月, 近6月, 今年来, 成立来, 可购买, 手续费

```python
df = ak.fund_lcx_rank_em()
```

## fund_hk_rank_em
描述: 东方财富网-数据中心-基金排行-香港基金排行
输入: 无
输出: 序号, 基金代码, 基金简称, 币种, 日期, 单位净值, 日增长率, 近1周, 近1月, 近3月, 近6月, 近1年, 近2年, 近3年, 今年来, 成立来, 可购买, 香港基金代码

```python
df = ak.fund_hk_rank_em()
```

## fund_individual_achievement_xq
描述: 雪球基金-基金详情-基金业绩-详情
输入: symbol - 基金代码; timeout - 超时时间
输出: 业绩类型, 周期, 本产品区间收益, 本产品最大回撒, 周期收益同类排名

```python
df = ak.fund_individual_achievement_xq(symbol="000001")
```

## fund_value_estimation_em
描述: 东方财富网-数据中心-净值估算
输入: symbol - 基金类型; {'全部','股票型','混合型','债券型','指数型','QDII','ETF联接','LOF','场内交易基金'}
输出: 序号, 基金代码, 基金名称, 交易日-估算数据-估算值, 交易日-估算数据-估算增长率, 交易日-公布数据-单位净值, 交易日-公布数据-日增长率, 估算偏差, 交易日-单位净值

```python
df = ak.fund_value_estimation_em(symbol="混合型")
```

## fund_individual_analysis_xq
描述: 雪球基金-基金详情-数据分析
输入: symbol - 基金代码; timeout - 超时时间
输出: 周期, 较同类风险收益比, 较同类抗风险波动, 年化波动率, 年化夏普比率, 最大回撤

```python
df = ak.fund_individual_analysis_xq(symbol="000001")
```

## fund_individual_profit_probability_xq
描述: 雪球基金-基金详情-盈利概率
输入: symbol - 基金代码; timeout - 超时时间
输出: 持有时长, 盈利概率, 平均收益

```python
df = ak.fund_individual_profit_probability_xq(symbol="000001")
```

## fund_individual_detail_hold_xq
描述: 雪球基金-基金详情-基金持仓-详情
输入: symbol - 基金代码; date - 季度日期; timeout - 超时时间
输出: 资产类型, 仓位占比

```python
df = ak.fund_individual_detail_hold_xq(symbol="002804", date="20231231")
```

## fund_overview_em
描述: 天天基金-基金档案-基本概况
输入: symbol - 基金代码
输出: 基金全称, 基金简称, 基金代码, 基金类型, 发行日期, 成立日期/规模, 资产规模, 份额规模, 基金管理人, 基金托管人, 基金经理人, 成立来分红, 管理费率, 托管费率, 销售服务费率, 最高认购费率, 业绩比较基准, 跟踪标的

```python
df = ak.fund_overview_em(symbol="015641")
```

## fund_fee_em
描述: 天天基金-基金档案-购买信息
输入: symbol - 基金代码; indicator - 费用类型
输出: 费用类型, 条件或名称, 费用

```python
df = ak.fund_fee_em(symbol="015641", indicator="认购费率")
```

## fund_individual_detail_info_xq
描述: 雪球基金-基金详情-基金交易规则
输入: symbol - 基金代码; timeout - 超时时间
输出: 费用类型, 条件或名称, 费用

```python
df = ak.fund_individual_detail_info_xq(symbol="000001")
```

## fund_portfolio_hold_em
描述: 天天基金网-基金档案-投资组合-基金持仓
输入: symbol - 基金代码; date - 指定年份
输出: 序号, 股票代码, 股票名称, 占净值比例, 持股数, 持仓市值, 季度

```python
df = ak.fund_portfolio_hold_em(symbol="000001", date="2024")
```

## fund_portfolio_bond_hold_em
描述: 天天基金网-基金档案-投资组合-债券持仓
输入: symbol - 基金代码; date - 指定年份
输出: 序号, 债券代码, 债券名称, 占净值比例, 持仓市值, 季度

```python
df = ak.fund_portfolio_bond_hold_em(symbol="000001", date="2023")
```

## fund_portfolio_industry_allocation_em
描述: 天天基金网-基金档案-投资组合-行业配置
输入: symbol - 基金代码; date - 指定年份
输出: 序号, 行业类别, 占净值比例, 市值, 截止时间

```python
df = ak.fund_portfolio_industry_allocation_em(symbol="000001", date="2023")
```

## fund_portfolio_change_em
描述: 天天基金网-基金档案-投资组合-重大变动
输入: symbol - 基金代码; indicator - 类型{"累计买入","累计卖出"}; date - 指定年份
输出: 序号, 股票代码, 股票名称, 本期累计买入金额, 占期初基金资产净值比例, 季度

```python
df = ak.fund_portfolio_change_em(symbol="003567", indicator="累计买入", date="2023")
```

## fund_rating_all
描述: 天天基金网-基金评级-基金评级总汇
输入: 无
输出: 代码, 简称, 基金经理, 基金公司, 5星评级家数, 上海证券, 招商证券, 济安金信, 手续费, 类型

```python
df = ak.fund_rating_all()
```

## fund_rating_sh
描述: 天天基金网-基金评级-上海证券评级
输入: date - 查询日期
输出: 代码, 简称, 基金经理, 基金公司, 3年期评级-3年评级, 3年期评级-较上期, 5年期评级-5年评级, 5年期评级-较上期, 单位净值, 日期, 日增长率, 近1年涨幅, 近3年涨幅, 近5年涨幅, 手续费, 类型

```python
df = ak.fund_rating_sh(date='20230630')
```

## fund_rating_zs
描述: 天天基金网-基金评级-招商证券评级
输入: date - 查询日期
输出: 代码, 简称, 基金经理, 基金公司, 3年期评级-3年评级, 3年期评级-较上期, 单位净值, 日期, 日增长率, 近1年涨幅, 近3年涨幅, 近5年涨幅, 手续费

```python
df = ak.fund_rating_zs(date='20230331')
```

## fund_rating_ja
描述: 天天基金网-基金评级-济安金信评级
输入: date - 查询日期
输出: 代码, 简称, 基金经理, 基金公司, 3年期评级-3年评级, 3年期评级-较上期, 单位净值, 日期, 日增长率, 近1年涨幅, 近3年涨幅, 近5年涨幅, 手续费, 类型

```python
df = ak.fund_rating_ja(date='20200930')
```

## fund_manager_em
描述: 天天基金网-基金数据-基金经理大全
输入: 无
输出: 序号, 姓名, 所属公司, 现任基金代码, 现任基金, 累计从业时间, 现任基金资产总规模, 现任基金最佳回报

```python
df = ak.fund_manager_em()
```

## fund_new_found_em
描述: 天天基金网-基金数据-新发基金-新成立基金
输入: 无
输出: 基金代码, 基金简称, 发行公司, 基金类型, 集中认购期, 募集份额, 成立日期, 成立来涨幅, 基金经理, 申购状态, 优惠费率

```python
df = ak.fund_new_found_em()
```

## fund_new_found_ths
描述: 同花顺-基金数据-新发基金
输入: symbol - 类型{"全部","发行中","将发行"}
输出: 基金代码, 基金名称, 投资类型, 募集起始日, 募集终止日, 管理人, 基金经理, 认购费率, 最低认购, 基金类型, 投资风格

```python
df = ak.fund_new_found_ths(symbol="全部")
```

## fund_scale_open_sina
描述: 基金数据中心-基金规模-开放式基金
输入: symbol - 基金类型; {"股票型基金","混合型基金","债券型基金","货币型基金","QDII基金"}
输出: 序号, 基金代码, 基金简称, 单位净值, 总募集规模, 最近总份额, 成立日期, 基金经理, 更新日期

```python
df = ak.fund_scale_open_sina(symbol='股票型基金')
```

## fund_scale_close_sina
描述: 基金数据中心-基金规模-封闭式基金
输入: 无
输出: 序号, 基金代码, 基金简称, 单位净值, 总募集规模, 最近总份额, 成立日期, 基金经理, 更新日期

```python
df = ak.fund_scale_close_sina()
```

## fund_scale_structured_sina
描述: 基金数据中心-基金规模-分级子基金
输入: 无
输出: 序号, 基金代码, 基金简称, 单位净值, 总募集规模, 最近总份额, 成立日期, 基金经理, 更新日期

```python
df = ak.fund_scale_structured_sina()
```

## fund_etf_scale_sse
描述: 上海证券交易所-ETF产品列表-基金规模
输入: date - 日期; 格式"YYYYMMDD"
输出: 序号, 基金代码, 基金简称, ETF类型, 统计日期, 基金份额

```python
df = ak.fund_etf_scale_sse(date="20250115")
```

## fund_etf_scale_szse
描述: 深圳证券交易所-基金产品-ETF基金份额
输入: 无
输出: 基金代码, 基金简称, 基金类别, 投资类别, 上市日期, 基金份额, 基金管理人, 基金发起人, 基金托管人, 净值

```python
df = ak.fund_etf_scale_szse()
```

## fund_scale_daily_szse
描述: 深圳证券交易所-基金产品-基金规模-日频数据; 日期范围不超过6个月
输入: start_date - 开始日期; end_date - 结束日期; symbol - 基金类别{"ETF","LOF","REITS"}
输出: 日期, 基金代码, 基金简称, 基金份额

```python
df = ak.fund_scale_daily_szse(start_date="20260401", end_date="20260402", symbol="ETF")
```

## fund_aum_em
描述: 天天基金网-基金数据-基金规模
输入: 无
输出: 序号, 基金公司, 成立时间, 全部管理规模, 全部基金数, 全部经理数, 更新日期

```python
df = ak.fund_aum_em()
```

## fund_aum_trend_em
描述: 天天基金网-基金数据-市场全部基金规模走势
输入: 无
输出: date, value

```python
df = ak.fund_aum_trend_em()
```

## fund_aum_hist_em
描述: 天天基金网-基金数据-基金公司历年管理规模排行列表
输入: year - 年份; 从2001年开始
输出: 序号, 基金公司, 总规模, 股票型, 混合型, 债券型, 指数型, QDII, 货币型

```python
df = ak.fund_aum_hist_em(year="2023")
```

## reits_realtime_em
描述: 东方财富网-行情中心-REITs-沪深 REITs-实时行情
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 成交量, 成交额, 开盘价, 最高价, 最低价, 昨收

```python
df = ak.reits_realtime_em()
```

## reits_hist_em
描述: 东方财富网-行情中心-REITs-沪深 REITs-历史行情
输入: symbol - REITs代码
输出: 日期, 今开, 最高, 最低, 最新价, 成交量, 成交额, 振幅, 换手

```python
df = ak.reits_hist_em(symbol="508097")
```

## fund_report_stock_cninfo
描述: 巨潮资讯-数据中心-专题统计-基金报表-基金重仓股
输入: date - 报告期; {"XXXX0331","XXXX0630","XXXX0930","XXXX1231"}
输出: 序号, 股票代码, 股票简称, 报告期, 基金覆盖家数, 持股总数, 持股总市值

```python
df = ak.fund_report_stock_cninfo(date="20210630")
```

## fund_report_industry_allocation_cninfo
描述: 巨潮资讯-数据中心-专题统计-基金报表-基金行业配置
输入: date - 报告期; {"XXXX0331","XXXX0630","XXXX0930","XXXX1231"}
输出: 行业编码, 证监会行业名称, 报告期, 基金覆盖家数, 行业规模, 占净资产比例

```python
df = ak.fund_report_industry_allocation_cninfo(date="20210630")
```

## fund_report_asset_allocation_cninfo
描述: 巨潮资讯-数据中心-专题统计-基金报表-基金资产配置
输入: 无
输出: 报告期, 基金覆盖家数, 股票权益类占净资产比例, 债券固定收益类占净资产比例, 现金货币类占净资产比例, 基金市场净资产规模

```python
df = ak.fund_report_asset_allocation_cninfo()
```

## fund_scale_change_em
描述: 天天基金网-基金数据-规模份额-规模变动
输入: 无
输出: 序号, 截止日期, 基金家数, 期间申购, 期间赎回, 期末总份额, 期末净资产

```python
df = ak.fund_scale_change_em()
```

## fund_hold_structure_em
描述: 天天基金网-基金数据-规模份额-持有人结构
输入: 无
输出: 序号, 截止日期, 基金家数, 机构持有比列, 个人持有比列, 内部持有比列, 总份额

```python
df = ak.fund_hold_structure_em()
```

## fund_stock_position_lg
描述: 乐咕乐股-基金仓位-股票型基金仓位
输入: 无
输出: date, close, position

```python
df = ak.fund_stock_position_lg()
```

## fund_balance_position_lg
描述: 乐咕乐股-基金仓位-平衡混合型基金仓位
输入: 无
输出: date, close, position

```python
df = ak.fund_balance_position_lg()
```

## fund_linghuo_position_lg
描述: 乐咕乐股-基金仓位-灵活配置型基金仓位
输入: 无
输出: date, close, position

```python
df = ak.fund_linghuo_position_lg()
```

## fund_announcement_dividend_em
描述: 东方财富网站-天天基金网-基金档案-基金公告-分红配送
输入: symbol - 基金代码
输出: 基金代码, 公告标题, 基金名称, 公告日期, 报告ID

```python
df = ak.fund_announcement_dividend_em(symbol="000001")
```

## fund_announcement_report_em
描述: 东方财富网站-天天基金网-基金档案-基金公告-定期报告
输入: symbol - 基金代码
输出: 基金代码, 公告标题, 基金名称, 公告日期, 报告ID

```python
df = ak.fund_announcement_report_em(symbol="000001")
```

## fund_announcement_personnel_em
描述: 东方财富网站-天天基金网-基金档案-基金公告-人事调整
输入: symbol - 基金代码
输出: 基金代码, 公告标题, 基金名称, 公告日期, 报告ID

```python
df = ak.fund_announcement_personnel_em(symbol="000001")
```
