# 私募基金数据

```python
import akshare as ak
```

## amac_member_info
描述: 中国证券投资基金业协会-信息公示-会员信息-会员机构综合查询
输入: 无
输出: 机构（会员）名称, 会员代表, 会员类型, 会员编号, 入会时间, 机构类型, 是否星标

```python
df = ak.amac_member_info()
```

## amac_person_fund_org_list
描述: 中国证券投资基金业协会-信息公示-从业人员信息-基金从业人员资格注册信息
输入: symbol - 机构类型; 如"公募基金管理公司", "私募基金管理人"等
输出: 序号, 机构名称, 员工人数, 基金从业资格, 基金销售业务资格, 基金经理, 投资经理

```python
df = ak.amac_person_fund_org_list(symbol="公募基金管理公司")
```

## amac_person_bond_org_list
描述: 中国证券投资基金业协会-信息公示-从业人员信息-债券投资交易相关人员公示
输入: 无
输出: 序号, 机构类型, 机构名称, 公示网址

```python
df = ak.amac_person_bond_org_list()
```

## amac_manager_info
描述: 中国证券投资基金业协会-信息公示-私募基金管理人公示-私募基金管理人综合查询
输入: 无
输出: 私募基金管理人名称, 法定代表人/执行事务合伙人(委派代表)姓名, 机构类型, 注册地, 登记编号, 成立时间, 登记时间

```python
df = ak.amac_manager_info()
```

## amac_manager_classify_info
描述: 中国证券投资基金业协会-信息公示-私募基金管理人公示-私募基金管理人分类公示
输入: 无
输出: 私募基金管理人名称, 法定代表人/执行事务合伙人(委派代表)姓名, 机构类型, 登记编号, 注册地, 办公地, 成立时间, 登记时间, 在管基金数量, 会员类型, 是否有提示信息, 是否有诚信信息

```python
df = ak.amac_manager_classify_info()
```

## amac_member_sub_info
描述: 中国证券投资基金业协会-信息公示-私募基金管理人公示-证券公司私募基金子公司管理人信息公示
输入: 无
输出: 机构（会员）名称, 会员代表, 会员类型, 会员编号, 入会时间, 公司类型

```python
df = ak.amac_member_sub_info()
```

## amac_fund_info
描述: 中国证券投资基金业协会-信息公示-基金产品公示-私募基金管理人基金产品
输入: start_page - 开始页码; end_page - 结束页码
输出: 基金名称, 私募基金管理人名称, 私募基金管理人类型, 运行状态, 备案时间, 建立时间, 托管人名称

```python
df = ak.amac_fund_info(start_page="1", end_page='100')
```

## amac_securities_info
描述: 中国证券投资基金业协会-信息公示-基金产品公示-证券公司集合资管产品公示
输入: 无
输出: 产品名称, 产品编码, 管理人名称, 成立日期, 到期时间, 投资类型, 是否分级, 托管人名称, 备案日期, 运作状态

```python
df = ak.amac_securities_info()
```

## amac_aoin_info
描述: 中国证券投资基金业协会-信息公示-基金产品公示-证券公司直投基金
输入: 无
输出: 产品编码, 产品名称, 直投子公司, 管理机构, 设立日期

```python
df = ak.amac_aoin_info()
```

## amac_fund_sub_info
描述: 中国证券投资基金业协会-信息公示-基金产品公示-证券公司私募投资基金
输入: 无
输出: 产品编码, 产品名称, 私募基金管理人名称, 托管人名称, 成立日期, 备案日期

```python
df = ak.amac_fund_sub_info()
```

## amac_fund_account_info
描述: 中国证券投资基金业协会-信息公示-基金产品公示-基金公司及子公司集合资管产品公示
输入: 无
输出: 成立日期, 产品编码, 产品名称, 管理人名称

```python
df = ak.amac_fund_account_info()
```

## amac_fund_abs
描述: 中国证券投资基金业协会-信息公示-产品公示-资产支持专项计划
输入: 无
输出: 编号, 备案编号, 专项计划全称, 管理人, 托管人, 成立日期, 预期到期时间, 备案通过时间

```python
df = ak.amac_fund_abs()
```

## amac_futures_info
描述: 中国证券投资基金业协会-信息公示-基金产品公示-期货公司集合资管产品公示
输入: 无
输出: 产品名称, 产品编码, 管理人名称, 托管人名称, 成立日期, 投资类型, 是否分级, 备案日期, 到期日, 运作状态

```python
df = ak.amac_futures_info()
```

## amac_manager_cancelled_info
描述: 中国证券投资基金业协会-信息公示-诚信信息-已注销私募基金管理人名单
输入: 无
输出: 管理人名称, 统一社会信用代码, 登记时间, 注销时间, 注销类型

```python
df = ak.amac_manager_cancelled_info()
```
