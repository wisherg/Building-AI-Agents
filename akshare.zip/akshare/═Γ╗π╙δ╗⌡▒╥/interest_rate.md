# 利率数据

```python
import akshare as ak
```

## macro_bank_euro_interest_rate

描述: 欧洲央行决议报告，数据区间从19990101-至今

输入: 无

输出: 商品, 日期, 今值, 预测值, 前值

```python
macro_bank_euro_interest_rate_df = ak.macro_bank_euro_interest_rate()
print(macro_bank_euro_interest_rate_df)
```

## macro_bank_newzealand_interest_rate

描述: 新西兰联储决议报告，数据区间从19990401-至今

输入: 无

输出: 商品, 日期, 今值, 预测值, 前值

```python
macro_bank_newzealand_interest_rate_df = ak.macro_bank_newzealand_interest_rate()
print(macro_bank_newzealand_interest_rate_df)
```

## macro_bank_china_interest_rate

描述: 中国央行决议报告，数据区间从19910105-至今

输入: 无

输出: 商品, 日期, 今值, 预测值, 前值

```python
macro_bank_china_interest_rate_df = ak.macro_bank_china_interest_rate()
print(macro_bank_china_interest_rate_df)
```

## macro_bank_switzerland_interest_rate

描述: 瑞士央行利率决议报告，数据区间从20080313-至今

输入: 无

输出: 商品, 日期, 今值, 预测值, 前值

```python
macro_bank_switzerland_interest_rate_df = ak.macro_bank_switzerland_interest_rate()
print(macro_bank_switzerland_interest_rate_df)
```

## macro_bank_english_interest_rate

描述: 英国央行决议报告，数据区间从19700101-至今

输入: 无

输出: 商品, 日期, 今值, 预测值, 前值

```python
macro_bank_english_interest_rate_df = ak.macro_bank_english_interest_rate()
print(macro_bank_english_interest_rate_df)
```

## macro_bank_australia_interest_rate

描述: 澳洲联储决议报告，数据区间从19800201-至今

输入: 无

输出: 商品, 日期, 今值, 预测值, 前值

```python
macro_bank_australia_interest_rate_df = ak.macro_bank_australia_interest_rate()
print(macro_bank_australia_interest_rate_df)
```

## macro_bank_japan_interest_rate

描述: 日本利率决议报告，数据区间从20080214-至今

输入: 无

输出: 商品, 日期, 今值, 预测值, 前值

```python
macro_bank_japan_interest_rate_df = ak.macro_bank_japan_interest_rate()
print(macro_bank_japan_interest_rate_df)
```

## macro_bank_russia_interest_rate

描述: 俄罗斯利率决议报告，数据区间从20030601-至今

输入: 无

输出: 商品, 日期, 今值, 预测值, 前值

```python
macro_bank_russia_interest_rate_df = ak.macro_bank_russia_interest_rate()
print(macro_bank_russia_interest_rate_df)
```

## macro_bank_india_interest_rate

描述: 印度利率决议报告，数据区间从20000801-至今

输入: 无

输出: 商品, 日期, 今值, 预测值, 前值

```python
macro_bank_india_interest_rate_df = ak.macro_bank_india_interest_rate()
print(macro_bank_india_interest_rate_df)
```

## macro_bank_brazil_interest_rate

描述: 巴西利率决议报告，数据区间从20080201-至今

输入: 无

输出: 商品, 日期, 今值, 预测值, 前值

```python
macro_bank_brazil_interest_rate_df = ak.macro_bank_brazil_interest_rate()
print(macro_bank_brazil_interest_rate_df)
```

## rate_interbank

描述: 东方财富-拆借利率一览-具体市场的具体品种的具体指标的拆借利率数据

输入: market - 市场，如"上海银行同业拆借市场"; symbol - 品种，如"Shibor人民币"; indicator - 指标，如"隔夜"

输出: 日期, 利率, 涨跌

```python
rate_interbank_df = ak.rate_interbank(market="上海银行同业拆借市场", symbol="Shibor人民币", indicator="3月")
print(rate_interbank_df)
```

## repo_rate_hist

描述: 回购定盘利率-历史数据，开始与结束时间需在一年内

输入: start_date - 开始日期，如"20200930"; end_date - 结束日期，如"20201029"

输出: date, FR001, FR007, FR014, FDR001, FDR007, FDR014

```python
repo_rate_hist_df = ak.repo_rate_hist(start_date="20231001", end_date="20240101")
print(repo_rate_hist_df)
```

## repo_rate_query

描述: 回购定盘利率-近期数据

输入: symbol - 类型，可选"回购定盘利率"或"银银间回购定盘利率"

输出: date, FR001, FR007, FR014

```python
repo_rate_query_df = ak.repo_rate_query(symbol="回购定盘利率")
print(repo_rate_query_df)
```
