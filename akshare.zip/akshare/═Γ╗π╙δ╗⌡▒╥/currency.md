# 货币数据

```python
import akshare as ak
```

## currency_history

描述: 货币报价历史数据（使用外部API currencyscoop，免费账号每月限量5000次）

输入: base - 基础货币，如"USD"; date - 日期，如"2023-02-03"; symbols - 目标货币，默认""返回全部，如"AUD"或"AUD,CNY"; api_key - API密钥

输出: currency, date, base, rates

```python
currency_history_df = ak.currency_history(base="USD", date="2023-02-03", symbols="", api_key="此处输入API")
print(currency_history_df)
```

## currency_time_series

描述: 货币报价时间序列数据（使用外部API currencyscoop，免费账号每月限量5000次）

输入: base - 基础货币，如"USD"; start_date - 开始日期，如"2023-02-03"; end_date - 结束日期，如"2023-03-04"; symbols - 目标货币，默认""返回全部，如"AUD"或"AUD,CNY"; api_key - API密钥

输出: date, 各货币价格数据

```python
currency_time_series_df = ak.currency_time_series(base="USD", start_date="2023-02-03", end_date="2023-03-04", symbols="", api_key="此处输入API")
print(currency_time_series_df)
```

## currency_currencies

描述: 所有货币的基础信息（使用外部API currencyscoop，免费账号每月限量5000次）

输入: c_type - 货币类型，如"fiat"; api_key - API密钥

输出: id, name, short_code, code, precision, subunit, symbol, symbol_first, decimal_mark, thousands_separator

```python
currency_currencies_df = ak.currency_currencies(c_type="fiat", api_key="此处输入API")
print(currency_currencies_df)
```

## currency_convert

描述: 指定货币对指定货币数量的转换后价格（使用外部API currencyscoop，免费账号每月限量5000次）

输入: base - 基础货币，如"USD"; to - 目标货币，如"CNY"; amount - 转换量，如"10000"; api_key - API密钥

输出: item, value

```python
currency_convert_df = ak.currency_convert(base="USD", to="CNY", amount="10000", api_key="此处输入API")
print(currency_convert_df)
```
