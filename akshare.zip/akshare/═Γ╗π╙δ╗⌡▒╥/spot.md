# 现货数据

```python
import akshare as ak
```

## spot_hist_sge

描述: 上海黄金交易所-数据资讯-行情走势-历史数据

输入: symbol - 品种代码，如"Au99.99"；可通过 ak.spot_symbol_table_sge() 获取品种表

输出: date, open, close, low, high

```python
spot_hist_sge_df = ak.spot_hist_sge(symbol='Au99.99')
print(spot_hist_sge_df)
```

## spot_quotations_sge

描述: 上海黄金交易所-数据资讯-行情走势-实时数据

输入: symbol - 品种代码，如"Au99.99"；可通过 ak.spot_symbol_table_sge() 获取品种表

输出: 品种, 时间, 现价, 更新时间

```python
spot_quotations_sge_df = ak.spot_quotations_sge(symbol="Au99.99")
print(spot_quotations_sge_df)
```

## spot_golden_benchmark_sge

描述: 上海黄金交易所-数据资讯-上海金基准价-历史数据

输入: 无

输出: 交易时间, 晚盘价, 早盘价

```python
spot_golden_benchmark_sge_df = ak.spot_golden_benchmark_sge()
print(spot_golden_benchmark_sge_df)
```

## spot_silver_benchmark_sge

描述: 上海黄金交易所-数据资讯-上海银基准价-历史数据

输入: 无

输出: 交易时间, 晚盘价, 早盘价

```python
spot_silver_benchmark_sge_df = ak.spot_silver_benchmark_sge()
print(spot_silver_benchmark_sge_df)
```

## spot_hog_soozhu

描述: 搜猪-生猪大数据-各省均价实时排行榜

输入: 无

输出: 省份, 价格, 涨跌幅

```python
spot_hog_soozhu_df = ak.spot_hog_soozhu()
print(spot_hog_soozhu_df)
```

## spot_hog_year_trend_soozhu

描述: 搜猪-生猪大数据-今年以来全国出栏均价走势

输入: 无

输出: 日期, 价格

```python
spot_hog_year_trend_soozhu_df = ak.spot_hog_year_trend_soozhu()
print(spot_hog_year_trend_soozhu_df)
```

## spot_hog_lean_price_soozhu

描述: 搜猪-生猪大数据-全国瘦肉型肉猪

输入: 无

输出: 日期, 价格

```python
spot_hog_lean_price_soozhu_df = ak.spot_hog_lean_price_soozhu()
print(spot_hog_lean_price_soozhu_df)
```

## spot_hog_three_way_soozhu

描述: 搜猪-生猪大数据-全国三元仔猪

输入: 无

输出: 日期, 价格

```python
spot_hog_three_way_soozhu_df = ak.spot_hog_three_way_soozhu()
print(spot_hog_three_way_soozhu_df)
```

## spot_hog_crossbred_soozhu

描述: 搜猪-生猪大数据-全国后备二元母猪

输入: 无

输出: 日期, 价格

```python
spot_hog_crossbred_soozhu_df = ak.spot_hog_crossbred_soozhu()
print(spot_hog_crossbred_soozhu_df)
```

## spot_corn_price_soozhu

描述: 搜猪-生猪大数据-全国玉米价格走势

输入: 无

输出: 日期, 价格

```python
spot_corn_price_soozhu_df = ak.spot_corn_price_soozhu()
print(spot_corn_price_soozhu_df)
```

## spot_soybean_price_soozhu

描述: 搜猪-生猪大数据-全国豆粕价格走势

输入: 无

输出: 日期, 价格

```python
spot_soybean_price_soozhu_df = ak.spot_soybean_price_soozhu()
print(spot_soybean_price_soozhu_df)
```

## spot_mixed_feed_soozhu

描述: 搜猪-生猪大数据-全国育肥猪合料（含自配料）半月走势

输入: 无

输出: 日期, 价格

```python
spot_mixed_feed_soozhu_df = ak.spot_mixed_feed_soozhu()
print(spot_mixed_feed_soozhu_df)
```
