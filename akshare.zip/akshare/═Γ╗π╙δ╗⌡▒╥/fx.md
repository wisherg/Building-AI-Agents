# 外汇数据

```python
import akshare as ak
```

## forex_hist_em

描述: 东方财富网-外汇市场-所有汇率-历史行情数据

输入: symbol - 品种代码，如"USDCNH"；可通过 ak.forex_spot_em() 获取所有品种代码

输出: 日期, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 今开, 最高, 最低, 昨收

```python
forex_hist_em_df = ak.forex_hist_em(symbol="USDCNH")
print(forex_hist_em_df)
```

## currency_boc_sina

描述: 新浪财经-中行人民币牌价历史数据

输入: symbol - 币种名称，如"美元"，可选: 美元/英镑/欧元/澳门元/泰国铢/菲律宾比索/港币/瑞士法郎/新加坡元/瑞典克朗/丹麦克朗/挪威克朗/日元/加拿大元/澳大利亚元/新西兰元/韩国元; start_date - 开始日期，如"20230304"; end_date - 结束日期，如"20231110"，间隔需超过6个月

输出: 日期, 中行汇买价, 中行钞买价, 中行钞卖价/汇卖价, 央行中间价

```python
currency_boc_sina_df = ak.currency_boc_sina(symbol="美元", start_date="20230304", end_date="20231110")
print(currency_boc_sina_df)
```

## currency_boc_safe

描述: 外汇管理局-人民币汇率中间价

输入: 无

输出: 日期, 美元, 欧元, 日元, 港元, 英镑, 林吉特, 卢布, 澳元, 加元, 新西兰元, 新加坡元, 瑞士法郎, 兰特, 韩元, 迪拉姆, 里亚尔, 福林, 兹罗提, 丹麦克朗, 瑞典克朗, 挪威克朗, 里拉, 比索, 泰铢

```python
currency_boc_safe_df = ak.currency_boc_safe()
print(currency_boc_safe_df)
```

## fx_spot_quote

描述: 人民币外汇即期报价（询价报价行情，实时更新）

输入: 无

输出: 货币对, 买报价, 卖报价

```python
fx_spot_quote_df = ak.fx_spot_quote()
print(fx_spot_quote_df)
```

## fx_swap_quote

描述: 人民币外汇远掉报价（询价报价行情，实时更新）

输入: 无

输出: 货币对, 1周, 1月, 3月, 6月, 9月, 1年

```python
fx_swap_quote_df = ak.fx_swap_quote()
print(fx_swap_quote_df)
```

## fx_c_swap_cm

描述: 中国外汇交易中心-外汇掉期C-Swap定盘曲线

输入: 无

输出: 日期时间, 期限品种, 掉期点(Pips), 掉期点数据源, 全价汇率

```python
fx_c_swap_cm_df = ak.fx_c_swap_cm()
print(fx_c_swap_cm_df)
```

## fx_pair_quote

描述: 外币对即期报价（询价报价行情，实时更新）

输入: 无

输出: 货币对, 买报价, 卖报价

```python
fx_pair_quote_df = ak.fx_pair_quote()
print(fx_pair_quote_df)
```

## currency_pair_map

描述: 指定币种的所有能够获取到的货币对信息，历史数据可调用 ak.currency_history() 获取

输入: symbol - 币种中文名称，如"人民币"

输出: name, code

```python
currency_pair_map_df = ak.currency_pair_map(symbol="人民币")
print(currency_pair_map_df)
```

## macro_fx_sentiment

描述: 货币对-投机情绪报告，日期需在当前交易日之前30个交易日内

输入: start_date - 开始日期，如"2020-04-07"; end_date - 结束日期，与start_date一致

输出: date, AUDJPY, AUDUSD, EURAUD, EURJPY, EURUSD, GBPJPY, GBPUSD, NZDUSD, USDCAD, USDCHF, USDJPY, USDX, XAUUSD

```python
from datetime import datetime
test_date = datetime.now().date().isoformat().replace("-", "")
macro_fx_sentiment_df = ak.macro_fx_sentiment(start_date=test_date, end_date=test_date)
print(macro_fx_sentiment_df)
```

## fx_quote_baidu

描述: 百度股市通-外汇-行情榜单

输入: symbol - 币种，可选"人民币"或"美元"; token - 目标网站复制的acs-token

输出: 代码, 名称, 最新价, 涨跌额, 涨跌幅

```python
fx_quote_baidu_df = ak.fx_quote_baidu(symbol="人民币")
print(fx_quote_baidu_df)
```
