# 指数数据

```python
import akshare as ak
```

## stock_zh_index_spot_em
描述: 东方财富网-行情中心-沪深京指数实时行情
输入: symbol - 指数类型; {"沪深重要指数","上证系列指数","深证系列指数","指数成份","中证系列指数"}
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比

```python
df = ak.stock_zh_index_spot_em(symbol="上证系列指数")
```

## stock_zh_index_spot_sina
描述: 新浪财经-中国股票指数数据
输入: 无
输出: 代码, 名称, 最新价, 涨跌额, 涨跌幅, 昨收, 今开, 最高, 最低, 成交量, 成交额

```python
df = ak.stock_zh_index_spot_sina()
```

## stock_zh_index_daily
描述: 股票指数的历史数据-新浪; 按日频率更新
输入: symbol - 指数代码; 如"sz399552"
输出: date, open, high, low, close, volume

```python
df = ak.stock_zh_index_daily(symbol="sz399552")
```

## stock_zh_index_daily_tx
描述: 股票指数(或股票)历史行情数据-腾讯; 支持自定义时间范围
输入: symbol - 指数代码; start_date - 开始日期; end_date - 结束日期
输出: date, open, close, high, low, amount

```python
df = ak.stock_zh_index_daily_tx(symbol="sh000001", start_date="20260101", end_date="20260429")
```

## stock_zh_index_daily_em
描述: 东方财富股票指数数据; 历史数据按日频率更新
输入: symbol - 指数代码; start_date - 开始日期; end_date - 结束日期
输出: date, open, close, high, low, volume, amount

```python
df = ak.stock_zh_index_daily_em(symbol="sz399812")
```

## index_zh_a_hist
描述: 东方财富网-中国股票指数-行情数据
输入: symbol - 指数代码; period - 周期{'daily','weekly','monthly'}; start_date - 开始日期; end_date - 结束日期
输出: 日期, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 振幅, 涨跌幅, 涨跌额, 换手率

```python
df = ak.index_zh_a_hist(symbol="000016", period="daily", start_date="19700101", end_date="22220101")
```

## index_zh_a_hist_min_em
描述: 东方财富网-指数数据-分时行情; 不能返回所有历史数据
输入: symbol - 指数代码; period - 频率{'1','5','15','30','60'}; start_date - 开始时间; end_date - 结束时间
输出: 时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 均价

```python
df = ak.index_zh_a_hist_min_em(symbol="000001", period="1", start_date="2023-12-11 09:30:00", end_date="2023-12-11 19:00:00")
```

## stock_hk_index_spot_sina
描述: 新浪财经-行情中心-港股指数实时行情
输入: 无
输出: 代码, 名称, 最新价, 涨跌额, 涨跌幅, 昨收, 今开, 最高, 最低

```python
df = ak.stock_hk_index_spot_sina()
```

## stock_hk_index_daily_sina
描述: 新浪财经-港股指数-历史行情数据
输入: symbol - 指数代码; 如"CES100"
输出: date, open, close, high, low, volume

```python
df = ak.stock_hk_index_daily_sina(symbol="CES100")
```

## stock_hk_index_spot_em
描述: 东方财富网-行情中心-港股-指数实时行情
输入: 无
输出: 序号, 内部编号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 今开, 最高, 最低, 昨收, 成交量, 成交额

```python
df = ak.stock_hk_index_spot_em()
```

## stock_hk_index_daily_em
描述: 东方财富网-港股-股票指数数据
输入: symbol - 指数代码
输出: date, open, high, low, latest

```python
df = ak.stock_hk_index_daily_em(symbol="HSTECF2L")
```

## index_us_stock_sina
描述: 新浪财经-美股指数行情
输入: symbol - 指数代码; {".IXIC",".DJI",".INX",".NDX"}
输出: date, open, high, low, close, volume, amount

```python
df = ak.index_us_stock_sina(symbol=".INX")
```

## index_global_spot_em
描述: 东方财富网-行情中心-全球指数-实时行情数据
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 开盘价, 最高价, 最低价, 昨收价, 振幅, 最新行情时间

```python
df = ak.index_global_spot_em()
```

## index_global_hist_em
描述: 东方财富网-行情中心-全球指数-历史行情数据
输入: symbol - 指数名称; 如"美元指数"
输出: 日期, 代码, 名称, 今开, 最新价, 最高, 最低, 振幅

```python
df = ak.index_global_hist_em(symbol="美元指数")
```

## index_global_hist_sina
描述: 新浪财经-行情中心-环球市场-历史行情; 返回最近1000条
输入: symbol - 指数名称; 如"瑞士股票指数"
输出: date, open, high, low, close, volume

```python
df = ak.index_global_hist_sina(symbol="瑞士股票指数")
```

## index_stock_cons
描述: 指定指数的最新成份股票信息
输入: symbol - 指数代码; 如"000300"
输出: 指数代码, 指数名称, 成份券代码, 成份券名称

```python
df = ak.index_stock_cons(symbol="000300")
```

## index_stock_cons_csindex
描述: 中证指数公司-指数成份股列表
输入: symbol - 指数代码
输出: 日期, 指数代码, 指数名称, 指数中文全称, 成份券代码, 成份券名称, 交易所, 交易所英文名称

```python
df = ak.index_stock_cons_csindex(symbol="000300")
```

## index_stock_cons_weight_csindex
描述: 中证指数公司-指数成份股权重
输入: symbol - 指数代码
输出: 日期, 指数代码, 指数名称, 指数中文全称, 成份券代码, 成份券名称, 权重

```python
df = ak.index_stock_cons_weight_csindex(symbol="000300")
```

## index_all_cni
描述: 国证指数-指数列表
输入: 无
输出: 指数代码, 指数名称, 基日, 基点, 样本数, 发布时间

```python
df = ak.index_all_cni()
```

## index_hist_cni
描述: 国证指数-历史行情数据
输入: symbol - 指数代码; start_date - 开始日期; end_date - 结束日期
输出: 日期, 开盘, 最高, 最低, 收盘, 成交量, 成交额

```python
df = ak.index_hist_cni(symbol="399001", start_date="20200101", end_date="20240604")
```

## index_detail_cni
描述: 国证指数-指数详情
输入: symbol - 指数代码
输出: 指数代码, 指数名称, 基日, 基点, 样本数, 发布时间, 指数介绍

```python
df = ak.index_detail_cni(symbol="399001")
```

## index_detail_hist_cni
描述: 国证指数-指数详情-历史行情
输入: symbol - 指数代码; start_date - 开始日期; end_date - 结束日期
输出: 日期, 开盘, 最高, 最低, 收盘, 成交量, 成交额

```python
df = ak.index_detail_hist_cni(symbol="399001", start_date="20200101", end_date="20240604")
```

## index_detail_hist_adjust_cni
描述: 国证指数-指数详情-历史行情(复权)
输入: symbol - 指数代码; start_date - 开始日期; end_date - 结束日期
输出: 日期, 开盘, 最高, 最低, 收盘, 成交量, 成交额

```python
df = ak.index_detail_hist_adjust_cni(symbol="399001", start_date="20200101", end_date="20240604")
```

## index_option_50etf_qvix
描述: 50ETF 期权波动率指数 QVIX
输入: 无
输出: date, open, high, low, close

```python
df = ak.index_option_50etf_qvix()
```

## index_option_50etf_min_qvix
描述: 50ETF 期权波动率指数-分时
输入: 无
输出: time, qvix

```python
df = ak.index_option_50etf_min_qvix()
```

## index_option_300etf_qvix
描述: 300ETF 期权波动率指数 QVIX
输入: 无
输出: date, open, high, low, close

```python
df = ak.index_option_300etf_qvix()
```

## index_option_300etf_min_qvix
描述: 300ETF 期权波动率指数-分时
输入: 无
输出: time, qvix

```python
df = ak.index_option_300etf_min_qvix()
```

## index_option_500etf_qvix
描述: 500ETF 期权波动率指数 QVIX
输入: 无
输出: date, open, high, low, close

```python
df = ak.index_option_500etf_qvix()
```

## index_option_500etf_min_qvix
描述: 500ETF 期权波动率指数-分时
输入: 无
输出: time, qvix

```python
df = ak.index_option_500etf_min_qvix()
```

## index_option_cyb_qvix
描述: 创业板 期权波动率指数 QVIX
输入: 无
输出: date, open, high, low, close

```python
df = ak.index_option_cyb_qvix()
```

## index_option_cyb_min_qvix
描述: 创业板 期权波动率指数-分时
输入: 无
输出: time, qvix

```python
df = ak.index_option_cyb_min_qvix()
```

## index_option_kcb_qvix
描述: 科创板 期权波动率指数 QVIX
输入: 无
输出: date, open, high, low, close

```python
df = ak.index_option_kcb_qvix()
```

## index_option_kcb_min_qvix
描述: 科创板 期权波动率指数-分时
输入: 无
输出: time, qvix

```python
df = ak.index_option_kcb_min_qvix()
```

## index_option_100etf_qvix
描述: 深证100ETF 期权波动率指数 QVIX
输入: 无
输出: date, open, high, low, close

```python
df = ak.index_option_100etf_qvix()
```

## index_option_100etf_min_qvix
描述: 深证100ETF 期权波动率指数-分时
输入: 无
输出: time, qvix

```python
df = ak.index_option_100etf_min_qvix()
```

## index_option_300index_qvix
描述: 中证300股指 期权波动率指数 QVIX
输入: 无
输出: date, open, high, low, close

```python
df = ak.index_option_300index_qvix()
```

## index_option_300index_min_qvix
描述: 中证300股指 期权波动率指数-分时
输入: 无
输出: time, qvix

```python
df = ak.index_option_300index_min_qvix()
```

## index_option_1000index_qvix
描述: 中证1000股指 期权波动率指数 QVIX
输入: 无
输出: date, open, high, low, close

```python
df = ak.index_option_1000index_qvix()
```

## index_option_1000index_min_qvix
描述: 中证1000股指 期权波动率指数-分时
输入: 无
输出: time, qvix

```python
df = ak.index_option_1000index_min_qvix()
```

## index_option_50index_qvix
描述: 上证50股指 期权波动率指数 QVIX
输入: 无
输出: date, open, high, low, close

```python
df = ak.index_option_50index_qvix()
```

## index_option_50index_min_qvix
描述: 上证50股指 期权波动率指数-分时
输入: 无
输出: time, qvix

```python
df = ak.index_option_50index_min_qvix()
```

## sw_index_first_info
描述: 申万一级行业信息
输入: 无
输出: 行业代码, 行业名称, 成份个数, 静态市盈率, TTM(滚动)市盈率, 市净率, 静态股息率

```python
df = ak.sw_index_first_info()
```

## sw_index_second_info
描述: 申万二级行业信息
输入: 无
输出: 行业代码, 行业名称, 上级行业, 成份个数, 静态市盈率, TTM(滚动)市盈率, 市净率, 静态股息率

```python
df = ak.sw_index_second_info()
```

## sw_index_third_info
描述: 申万三级行业信息
输入: 无
输出: 行业代码, 行业名称, 成份个数, 静态市盈率, TTM(滚动)市盈率, 市净率, 静态股息率

```python
df = ak.sw_index_third_info()
```

## sw_index_third_cons
描述: 申万三级行业成份
输入: symbol - 行业代码; 如"850111.SI"
输出: 序号, 股票代码, 股票简称, 纳入时间, 申万1级, 申万2级, 申万3级, 价格, 市盈率, 市盈率ttm, 市净率, 股息率, 市值, 归母净利润同比增长, 营业收入同比增长

```python
df = ak.sw_index_third_cons(symbol="850111.SI")
```

## spot_goods
描述: 新浪财经-商品现货价格指数
输入: symbol - 指数名称; 如"波罗的海干散货指数"
输出: 日期, 指数, 涨跌额, 涨跌幅

```python
df = ak.spot_goods(symbol="波罗的海干散货指数")
```

## index_yw
描述: 义乌小商品指数
输入: symbol - 类型; {"周价格指数","月价格指数","月景气指数"}
输出: 周价格指数(期数,价格指数,场内价格指数,网上价格指数,订单价格指数,出口价格指数); 月景气指数(期数,景气指数,规模指数,效益指数,市场信心指数)

```python
df = ak.index_yw(symbol="周价格指数")
```

## index_kq_fz
描述: 恐惧贪婪指数
输入: 无
输出: 日期, 恐惧贪婪指数

```python
df = ak.index_kq_fz()
```

## index_kq_fashion
描述: 趋势恐惧贪婪指数
输入: 无
输出: 日期, 趋势恐惧贪婪指数

```python
df = ak.index_kq_fashion()
```

## index_sugar_msweet
描述: 沐甜科技数据中心-白糖现货价格指数
输入: 无
输出: 日期, 价格, 均价, 最高价, 最低价

```python
df = ak.index_sugar_msweet()
```

## index_inner_quote_sugar_msweet
描述: 沐甜科技数据中心-配额内进口糖估算指数
输入: 无
输出: 日期, 利润空间, 泰国糖, 泰国MA5, 巴西MA5, 利润MA5, 巴西MA10, 巴西糖, 柳州现货价, 广州现货价, 泰国MA10, 利润MA30, 利润MA10

```python
df = ak.index_inner_quote_sugar_msweet()
```

## index_outer_quote_sugar_msweet
描述: 沐甜科技数据中心-配额外进口糖估算指数
输入: 无
输出: 日期, 巴西糖进口成本, 泰国糖进口利润空间, 巴西糖进口利润空间, 泰国糖进口成本, 日照现货价

```python
df = ak.index_outer_quote_sugar_msweet()
```

## index_eri
描述: 浙江省排污权交易指数
输入: symbol - 周期; {"月度","季度"}
输出: 日期, 交易指数, 成交量, 成交额

```python
df = ak.index_eri(symbol="月度")
```

## drewry_wci_index
描述: Drewry 集装箱指数
输入: symbol - 航线; 如"composite"
输出: date, wci

```python
df = ak.drewry_wci_index(symbol="composite")
```

## index_price_cflp
描述: 中国公路物流运价指数
输入: symbol - 周期; {"周指数","月指数","季度指数","年度指数"}
输出: 日期, 定基指数, 环比指数, 同比指数

```python
df = ak.index_price_cflp(symbol="周指数")
```

## index_volume_cflp
描述: 中国公路物流运量指数
输入: symbol - 周期; {"月指数","季度指数","年度指数"}
输出: 日期, 定基指数, 环比指数, 同比指数

```python
df = ak.index_volume_cflp(symbol="月指数")
```

## stock_zh_index_hist_csindex
描述: 中证指数日频率数据
输入: symbol - 指数代码; start_date - 开始日期; end_date - 结束日期
输出: 日期, 指数代码, 指数中文全称, 指数中文简称, 指数英文全称, 指数英文简称, 开盘, 最高, 最低, 收盘, 涨跌, 涨跌幅, 成交量, 成交金额, 样本数量, 滚动市盈率

```python
df = ak.stock_zh_index_hist_csindex(symbol="000928", start_date="20100101", end_date="20240604")
```

## index_pmi_com_cx
描述: 财新数据-指数报告-财新中国 PMI-综合 PMI
输入: 无
输出: 日期, 综合PMI, 变化值

```python
df = ak.index_pmi_com_cx()
```

## index_pmi_man_cx
描述: 财新数据-指数报告-财新中国 PMI-制造业 PMI
输入: 无
输出: 日期, 制造业PMI, 变化值

```python
df = ak.index_pmi_man_cx()
```

## index_pmi_ser_cx
描述: 财新数据-指数报告-财新中国 PMI-服务业 PMI
输入: 无
输出: 日期, 服务业PMI, 变化值

```python
df = ak.index_pmi_ser_cx()
```

## index_dei_cx
描述: 财新指数-数字经济指数
输入: 无
输出: 日期, 数字经济指数, 变化值

```python
df = ak.index_dei_cx()
```

## index_ii_cx
描述: 财新指数-产业指数
输入: 无
输出: 日期, 产业指数, 变化值

```python
df = ak.index_ii_cx()
```

## index_si_cx
描述: 财新指数-溢出指数
输入: 无
输出: 日期, 溢出指数, 变化值

```python
df = ak.index_si_cx()
```

## index_fi_cx
描述: 财新指数-融合指数
输入: 无
输出: 日期, 融合指数, 变化值

```python
df = ak.index_fi_cx()
```

## index_bi_cx
描述: 财新指数-基础指数
输入: 无
输出: 日期, 基础指数, 变化值

```python
df = ak.index_bi_cx()
```

## index_nei_cx
描述: 财新指数-中国新经济指数
输入: 无
输出: 日期, 中国新经济指数, 变化值

```python
df = ak.index_nei_cx()
```

## index_li_cx
描述: 财新指数-劳动力投入指数
输入: 无
输出: 日期, 劳动力投入指数, 变化值

```python
df = ak.index_li_cx()
```

## index_ci_cx
描述: 财新指数-资本投入指数
输入: 无
输出: 日期, 资本投入指数, 变化值

```python
df = ak.index_ci_cx()
```

## index_ti_cx
描述: 财新指数-科技投入指数
输入: 无
输出: 日期, 科技投入指数, 变化值

```python
df = ak.index_ti_cx()
```

## index_neaw_cx
描述: 财新指数-新经济行业入职平均工资水平
输入: 无
输出: 日期, 新经济行业入职平均工资水平, 变化值

```python
df = ak.index_neaw_cx()
```

## index_awpr_cx
描述: 财新指数-新经济入职工资溢价水平
输入: 无
输出: 日期, 新经济入职工资溢价水平, 变化值

```python
df = ak.index_awpr_cx()
```

## index_cci_cx
描述: 财新指数-大宗商品指数
输入: 无
输出: 日期, 大宗商品指数, 变化值

```python
df = ak.index_cci_cx()
```

## index_qli_cx
描述: 财新指数-高质量因子
输入: 无
输出: 日期, 高质量因子指数, 变化幅度

```python
df = ak.index_qli_cx()
```

## index_ai_cx
描述: 财新指数-AI策略指数
输入: 无
输出: 日期, AI策略指数, 变化幅度

```python
df = ak.index_ai_cx()
```

## index_bei_cx
描述: 财新指数-勃艮第指数
输入: 无
输出: 日期, 勃艮第指数, 变化幅度

```python
df = ak.index_bei_cx()
```

## index_neei_cx
描述: 财新指数-新动能指数
输入: 无
输出: 日期, 新动能指数, 变化幅度

```python
df = ak.index_neei_cx()
```

## stock_zh_index_value_csindex
描述: 中证指数-指数估值数据; 只能返回近期数据
输入: symbol - 指数代码
输出: 日期, 指数代码, 指数中文全称, 指数中文简称, 指数英文全称, 指数英文简称, 市盈率1, 市盈率2, 股息率1, 股息率2

```python
df = ak.stock_zh_index_value_csindex(symbol="H30374")
```

## index_realtime_fund_sw
描述: 申万宏源研究-申万指数-基金指数-实时行情
输入: symbol - 类型; {"基础一级","基础二级","基础三级","特色指数"}
输出: 指数代码, 指数名称, 昨收盘, 日涨跌幅, 年涨跌幅

```python
df = ak.index_realtime_fund_sw(symbol="基础一级")
```

## index_hist_fund_sw
描述: 申万宏源研究-申万指数-基金指数-历史行情
输入: symbol - 基金指数代码; period - 周期{"day","week","month"}
输出: 日期, 收盘指数, 开盘指数, 最高指数, 最低指数, 涨跌幅

```python
df = ak.index_hist_fund_sw(symbol="807200", period="day")
```

## index_realtime_sw
描述: 申万宏源研究-指数系列实时行情
输入: symbol - 类型; {"市场表征","一级行业","二级行业","风格指数","大类风格指数","金创指数"}
输出: 指数代码, 指数名称, 昨收盘, 今开盘, 最新价, 成交额, 成交量, 最高价, 最低价

```python
df = ak.index_realtime_sw(symbol="市场表征")
```

## index_hist_sw
描述: 申万宏源研究-指数发布-指数历史数据
输入: symbol - 指数代码; period - 周期{"day","week","month"}
输出: 代码, 日期, 收盘, 开盘, 最高, 最低, 成交量, 成交额

```python
df = ak.index_hist_sw(symbol="801193", period="day")
```

## index_min_sw
描述: 申万宏源研究-指数发布-指数分时数据
输入: symbol - 指数代码
输出: 代码, 名称, 价格, 日期, 时间

```python
df = ak.index_min_sw(symbol="801001")
```

## index_component_sw
描述: 申万宏源研究-指数发布-指数详情-成分股
输入: symbol - 指数代码
输出: 序号, 证券代码, 证券名称, 最新权重, 计入日期

```python
df = ak.index_component_sw(symbol="801001")
```

## index_analysis_daily_sw
描述: 申万宏源研究-指数分析-日报表
输入: symbol - 类型; start_date - 开始日期; end_date - 结束日期
输出: 指数代码, 指数名称, 发布日期, 收盘指数, 成交量, 涨跌幅, 换手率, 市盈率, 市净率, 均价, 成交额占比, 流通市值, 平均流通市值, 股息率

```python
df = ak.index_analysis_daily_sw(symbol="市场表征", start_date="20241025", end_date="20241025")
```

## index_analysis_weekly_sw
描述: 申万宏源研究-指数分析-周报表
输入: symbol - 类型; date - 日期
输出: 指数代码, 指数名称, 发布日期, 收盘指数, 成交量, 涨跌幅, 换手率, 市盈率, 市净率, 均价, 成交额占比, 流通市值, 平均流通市值, 股息率

```python
df = ak.index_analysis_weekly_sw(symbol="市场表征", date="20241025")
```

## index_analysis_monthly_sw
描述: 申万宏源研究-指数分析-月报表
输入: symbol - 类型; date - 日期
输出: 指数代码, 指数名称, 发布日期, 收盘指数, 成交量, 涨跌幅, 换手率, 市盈率, 市净率, 均价, 成交额占比, 流通市值, 平均流通市值, 股息率

```python
df = ak.index_analysis_monthly_sw(symbol="市场表征", date="20240930")
```

## index_news_sentiment_scope
描述: 数库-A股新闻情绪指数; 返回近一年数据
输入: 无
输出: 日期, 市场情绪指数, 沪深300指数

```python
df = ak.index_news_sentiment_scope()
```
