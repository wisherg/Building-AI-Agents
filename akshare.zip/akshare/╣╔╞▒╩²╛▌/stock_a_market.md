# A股市场数据

```python
import akshare as ak
```

## stock_sse_summary
描述: 上海证券交易所-股票数据总貌
输入: 无
输出: 项目, 股票, 科创板, 主板
```python
stock_sse_summary_df = ak.stock_sse_summary()
```

## stock_sse_deal_daily
描述: 上海证券交易所-每日股票成交概况(仅支持20211227之后)
输入: date - 交易日(如20250221)
输出: 单日情况, 股票, 主板A, 主板B, 科创板, 股票回购
```python
stock_sse_deal_daily_df = ak.stock_sse_deal_daily(date="20250221")
```

## stock_new_a_spot_em
描述: 东方财富网-新股-实时行情数据
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率, 上市时间, 总市值, 流通市值, 涨速, 5分钟涨跌, 60日涨跌幅, 年初至今涨跌幅
```python
stock_new_a_spot_em_df = ak.stock_new_a_spot_em()
```

## stock_kc_a_spot_em
描述: 东方财富网-科创板-实时行情
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率, 总市值, 流通市值, 涨速, 5分钟涨跌, 60日涨跌幅, 年初至今涨跌幅
```python
stock_kc_a_spot_em_df = ak.stock_kc_a_spot_em()
```

## stock_zh_a_cdr_daily
描述: 上海证券交易所-科创板-CDR历史行情
输入: symbol - CDR股票代码(如sh689009); start_date - 开始日期; end_date - 结束日期
输出: date, open, high, low, close, volume
```python
stock_zh_a_cdr_daily_df = ak.stock_zh_a_cdr_daily(symbol='sh689009', start_date='20201103', end_date='20201116')
```

## stock_zh_a_new
描述: 新浪财经-行情中心-沪深股市-次新股
输入: 无
输出: symbol, code, name, open, high, low, volume, amount, mktcap, turnoverratio
```python
stock_zh_a_new_df = ak.stock_zh_a_new()
```

## stock_gsrl_gsdt_em
描述: 东方财富网-数据中心-股市日历-公司动态
输入: date - 交易日(如20230808)
输出: 序号, 代码, 简称, 事件类型, 具体事项, 交易日
```python
stock_gsrl_gsdt_em_df = ak.stock_gsrl_gsdt_em(date="20230808")
```

## stock_zh_a_st_em
描述: 东方财富网-行情中心-沪深个股-风险警示板
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率
```python
stock_zh_a_st_em_df = ak.stock_zh_a_st_em()
```

## stock_zh_a_new_em
描述: 东方财富网-行情中心-沪深个股-新股
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率
```python
stock_zh_a_new_em_df = ak.stock_zh_a_new_em()
```

## stock_xgsr_ths
描述: 同花顺-数据中心-新股数据-新股上市首日
输入: 无
输出: 序号, 股票代码, 股票简称, 上市日期, 发行价, 最新价, 首日开盘价, 首日收盘价, 首日最高价, 首日最低价, 首日涨跌幅, 是否破发
```python
stock_xgsr_ths_df = ak.stock_xgsr_ths()
```

## stock_ipo_benefit_ths
描述: 同花顺-数据中心-新股数据-IPO受益股(每周更新)
输入: 无
输出: 序号, 股票代码, 股票简称, 收盘价, 涨跌幅, 市值, 参股家数, 投资总额, 投资占市值比, 参股对象
```python
stock_ipo_benefit_ths_df = ak.stock_ipo_benefit_ths()
```

## stock_zh_a_stop_em
描述: 东方财富网-行情中心-沪深个股-两网及退市
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率
```python
stock_zh_a_stop_em_df = ak.stock_zh_a_stop_em()
```

## stock_zh_kcb_spot
描述: 新浪财经-科创板股票实时行情数据(大量抓取易封IP)
输入: 无
输出: 代码, 名称, 最新价, 涨跌额, 涨跌幅, 买入, 卖出, 昨收, 今开, 最高, 最低, 成交量, 成交额, 时点, 市盈率, 市净率, 流通市值, 总市值, 换手率
```python
stock_zh_kcb_spot_df = ak.stock_zh_kcb_spot()
```

## stock_zh_kcb_daily
描述: 新浪财经-科创板股票历史行情数据; adjust可选qfq/hfq/qfq-factor/hfq-factor
输入: symbol - 带市场标识股票代码(如sh688008); adjust - 复权方式
输出: date, close, high, low, open, volume, after_volume, after_amount, outstanding_share, turnover
```python
stock_zh_kcb_daily_df = ak.stock_zh_kcb_daily(symbol="sh688399", adjust="hfq")
```

## stock_zh_kcb_report_em
描述: 东方财富-科创板报告数据
输入: from_page - 起始页码; to_page - 结束页码
输出: 代码, 名称, 公告标题, 公告类型, 公告日期, 公告代码
```python
stock_zh_kcb_report_em_df = ak.stock_zh_kcb_report_em(from_page=1, to_page=100)
```

## stock_sy_em
描述: 东方财富网-数据中心-特色数据-商誉-个股商誉明细
输入: date - 日期(如20240630)
输出: 序号, 股票代码, 股票简称, 商誉, 商誉占净资产比例, 净利润, 净利润同比, 上年商誉, 公告日期, 交易市场
```python
stock_sy_em_df = ak.stock_sy_em(date="20240630")
```

## stock_tfp_em
描述: 东方财富网-数据中心-特色数据-停复牌信息
输入: date - 日期(如20240426)
输出: 序号, 代码, 名称, 停牌时间, 停牌截止时间, 停牌期限, 停牌原因, 所属市场, 预计复牌时间
```python
stock_tfp_em_df = ak.stock_tfp_em(date="20240426")
```

## news_trade_notify_suspend_baidu
描述: 百度股市通-交易提醒-停复牌(含港股)
输入: date - 日期(如20241107)
输出: 股票代码, 股票简称, 交易所, 停牌时间, 复牌时间, 停牌事项说明
```python
news_trade_notify_suspend_baidu_df = ak.news_trade_notify_suspend_baidu(date="20241107")
```

## news_report_time_baidu
描述: 百度股市通-财报发行(含港股)
输入: date - 日期(如20241107)
输出: 股票代码, 交易所, 股票简称, 财报期
```python
news_report_time_baidu_df = ak.news_report_time_baidu(date="20241107")
```

## stock_dxsyl_em
描述: 东方财富网-数据中心-新股申购-打新收益率
输入: 无
输出: 股票代码, 股票简称, 发行价, 最新价, 网上发行中签率, 网上有效申购股数, 网上有效申购户数, 网上超额认购倍数, 网下配售中签率, 网下有效申购股数, 网下有效申购户数, 网下配售认购倍数, 总发行数量, 开盘溢价, 首日涨幅, 上市日期
```python
stock_dxsyl_em_df = ak.stock_dxsyl_em()
```

## stock_xgsglb_em
描述: 东方财富网-新股申购与中签查询
输入: symbol - 板块(全部股票/沪市主板/科创板/深市主板/创业板/北交所)
输出: 股票代码, 股票简称, 交易所, 板块, 申购代码, 发行总数, 网上发行, 顶格申购需配市值, 申购上限, 发行价格, 最新价, 首日收盘价, 申购日期, 中签号公布日, 中签缴款日期, 上市日期, 发行市盈率, 行业市盈率, 中签率, 询价累计报价倍数, 配售对象报价家数, 连续一字板数量, 涨幅, 每中一签获利
```python
stock_xgsglb_em_df = ak.stock_xgsglb_em(symbol="全部股票")
```

## stock_ipo_ths
描述: 同花顺-数据中心-新股申购与中签
输入: symbol - 板块(全部A股/沪市主板/深市主板/创业板/科创板/京市主板)
输出: 股票代码, 股票简称, 申购代码, 发行总数（万股）, 网上发行（万股）, 申购上限（万股）, 顶格申购需配市值（万元）, 发行价格, 发行市盈率, 行业市盈率, 申购日期, 中签率（%）, 中签号, 中签缴款日期, 上市日期, 打新收益（元）, 首日最高涨幅, 连板天数
```python
stock_ipo_ths_df = ak.stock_ipo_ths(symbol="全部A股")
```

## stock_ipo_hk_ths
描述: 同花顺-数据中心-新股申购与中签-港股
输入: 无
输出: 股票代码, 股票简称, 申购代码, 发行总数（万股）, 网上发行（万股）, 申购上限（万股）, 顶格申购需配市值（万元）, 发行价格, 发行市盈率, 行业市盈率, 申购日期, 中签率（%）, 中签号, 中签缴款日期, 上市日期, 打新收益（元）, 首日最高涨幅, 连板天数
```python
stock_ipo_hk_ths_df = ak.stock_ipo_hk_ths()
```

## stock_yysj_em
描述: 东方财富-数据中心-年报季报-预约披露时间
输入: symbol - 板块(沪深A股/沪市A股/科创板/深市A股/创业板/京市A股/ST板); date - 报告期(如20211231)
输出: 序号, 股票代码, 股票简称, 首次预约时间, 一次变更日期, 二次变更日期, 三次变更日期, 实际披露时间
```python
stock_yysj_em_df = ak.stock_yysj_em(symbol="沪深A股", date="20211231")
```

## stock_report_disclosure
描述: 巨潮资讯-数据-预约披露的数据
输入: market - 市场(沪深京/深市/深主板/创业板/沪市/沪主板/科创板/北交所); period - 报告期(如2022年报)
输出: 股票代码, 股票简称, 首次预约, 初次变更, 二次变更, 三次变更, 实际披露
```python
stock_report_disclosure_df = ak.stock_report_disclosure(market="沪深京", period="2022年报")
```

## stock_industry_category_cninfo
描述: 巨潮资讯-数据-行业分类数据
输入: symbol - 分类标准(证监会行业分类标准/巨潮行业分类标准/申银万国行业分类标准/新财富行业分类标准/国资委行业分类标准/巨潮产业细分标准/天相行业分类标准/全球行业分类标准)
输出: 类目编码, 类目名称, 终止日期, 行业类型, 行业类型编码, 类目名称英文, 父类编码, 分级
```python
stock_industry_category_cninfo_df = ak.stock_industry_category_cninfo(symbol="巨潮行业分类标准")
```

## stock_main_fund_flow
描述: 东方财富网-数据中心-资金流向-主力净流入排名
输入: symbol - 板块(全部股票/沪深A股/沪市A股/科创板/深市A股/创业板/沪市B股/深市B股)
输出: 序号, 代码, 名称, 最新价, 今日排行榜-主力净占比, 今日排行榜-今日排名, 今日排行榜-今日涨跌, 5日排行榜-主力净占比, 5日排行榜-5日排名, 5日排行榜-5日涨跌, 10日排行榜-主力净占比, 10日排行榜-10日排名, 10日排行榜-10日涨跌, 所属板块
```python
stock_main_fund_flow_df = ak.stock_main_fund_flow(symbol="全部股票")
```

## stock_shareholder_change_ths
描述: 同花顺-公司大事-股东持股变动
输入: symbol - 股票代码
输出: 公告日期, 变动股东, 变动数量, 交易均价, 剩余股份总数, 变动期间, 变动途径
```python
stock_shareholder_change_ths_df = ak.stock_shareholder_change_ths(symbol="688981")
```

## stock_history_dividend_detail
描述: 新浪财经-发行与分配-分红配股
输入: symbol - 股票代码; indicator - 类型(分红/配股); date - 分红配股具体日期(可选)
输出: 公告日期, 送股, 转增, 派息, 进度, 除权除息日, 股权登记日, 红股上市日(分红); 公告日期, 配股方案, 配股价格, 基准股本, 除权日, 股权登记日, 缴款起始日, 缴款终止日, 配股上市日, 募集资金合计(配股)
```python
stock_history_dividend_detail_df = ak.stock_history_dividend_detail(symbol="600012", indicator="分红")
```

## stock_ipo_info
描述: 新浪财经-发行与分配-新股发行
输入: stock - 股票代码
输出: item, value
```python
stock_ipo_info_df = ak.stock_ipo_info(stock="600004")
```

## stock_ipo_review_em
描述: 东方财富网-数据中心-新股申购-新股上会信息
输入: 无
输出: 序号, 企业名称, 股票简称, 股票代码, 上市板块, 上会日期, 审核状态, 发审委委员, 主承销商, 发行数量(股), 拟融资额(元), 公告日期, 上市日期
```python
stock_ipo_review_em_df = ak.stock_ipo_review_em()
```

## stock_ipo_tutor_em
描述: 东方财富网-数据中心-新股申购-IPO辅导信息
输入: 无
输出: 序号, 企业名称, 辅导机构, 辅导状态, 报告类型, 派出机构, 备案日期
```python
stock_ipo_tutor_em_df = ak.stock_ipo_tutor_em()
```

## stock_restricted_release_summary_em
描述: 东方财富网-数据中心-特色数据-限售股解禁
输入: symbol - 板块(全部股票/沪市A股/科创板/深市A股/创业板/京市A股); start_date - 开始日期; end_date - 结束日期
输出: 序号, 解禁时间, 当日解禁股票家数, 解禁数量, 实际解禁数量, 实际解禁市值, 沪深300指数, 沪深300指数涨跌幅
```python
stock_restricted_release_summary_em_df = ak.stock_restricted_release_summary_em(symbol="全部股票", start_date="20221108", end_date="20221209")
```

## stock_info_a_code_name
描述: 沪深京A股股票代码和股票简称数据
输入: 无
输出: code, name
```python
stock_info_a_code_name_df = ak.stock_info_a_code_name()
```

## stock_info_sh_name_code
描述: 上海证券交易所股票代码和简称数据
输入: symbol - 板块(主板A股/主板B股/科创板)
输出: 证券代码, 证券简称, 公司全称, 上市日期
```python
stock_info_sh_name_code_df = ak.stock_info_sh_name_code(symbol="主板A股")
```

## stock_info_sz_name_code
描述: 深证证券交易所股票代码和股票简称数据
输入: symbol - 列表(A股列表/B股列表/CDR列表/AB股列表)
输出: 板块, A股代码, A股简称, A股上市日期, A股总股本, A股流通股本, 所属行业
```python
stock_info_sz_name_code_df = ak.stock_info_sz_name_code(symbol="A股列表")
```

## stock_info_bj_name_code
描述: 北京证券交易所股票代码和简称数据
输入: 无
输出: 证券代码, 证券简称, 总股本, 流通股本, 上市日期, 所属行业, 地区, 报告日期
```python
stock_info_bj_name_code_df = ak.stock_info_bj_name_code()
```

## stock_info_sz_delist
描述: 深证证券交易所终止/暂停上市股票
输入: symbol - 类型(暂停上市公司/终止上市公司)
输出: 证券代码, 证券简称, 上市日期, 终止上市日期
```python
stock_info_sz_delist_df = ak.stock_info_sz_delist(symbol="终止上市公司")
```

## stock_staq_net_stop
描述: 东方财富网-行情中心-沪深个股-两网及退市
输入: 无
输出: 序号, 代码, 名称
```python
stock_staq_net_stop_df = ak.stock_staq_net_stop()
```

## stock_info_sh_delist
描述: 上海证券交易所暂停/终止上市股票
输入: symbol - 类型(全部/沪市/科创板)
输出: 公司代码, 公司简称, 上市日期, 暂停上市日期
```python
stock_info_sh_delist_df = ak.stock_info_sh_delist(symbol="全部")
```

## stock_info_change_name
描述: 新浪财经-股票曾用名
输入: symbol - 股票代码
输出: index, name
```python
stock_info_change_name_list = ak.stock_info_change_name(symbol="000503")
```

## stock_info_sz_change_name
描述: 深证证券交易所-市场数据-股票数据-名称变更
输入: symbol - 类型(全称变更/简称变更)
输出: 变更日期, 证券代码, 证券简称, 变更前全称, 变更后全称
```python
stock_info_sz_change_name_df = ak.stock_info_sz_change_name(symbol="全称变更")
```

## stock_new_gh_cninfo
描述: 巨潮资讯-数据中心-新股数据-新股过会
输入: 无
输出: 公司名称, 上会日期, 审核类型, 审议内容, 审核结果, 审核公告日
```python
stock_new_gh_cninfo_df = ak.stock_new_gh_cninfo()
```

## stock_new_ipo_cninfo
描述: 巨潮资讯-数据中心-新股数据-新股发行
输入: 无
输出: 证劵代码, 证券简称, 上市日期, 申购日期, 发行价, 总发行数量, 发行市盈率, 上网发行中签率, 摇号结果公告日, 中签公告日, 中签缴款日, 网上申购上限, 上网发行数量
```python
stock_new_ipo_cninfo_df = ak.stock_new_ipo_cninfo()
```

## stock_hold_change_cninfo
描述: 巨潮资讯-数据中心-专题统计-股东股本-股本变动
输入: symbol - 板块(深市主板/沪市/创业板/科创板/北交所/全部)
输出: 证券代码, 证券简称, 交易市场, 公告日期, 变动日期, 变动原因, 总股本, 已流通股份, 已流通比例, 流通受限股份
```python
stock_hold_change_cninfo_df = ak.stock_hold_change_cninfo(symbol="全部")
```

## stock_cg_guarantee_cninfo
描述: 巨潮资讯-数据中心-专题统计-公司治理-对外担保
输入: symbol - 板块(全部/深市主板/沪市/创业板/科创板); start_date - 开始日期; end_date - 结束日期
输出: 证劵代码, 证券简称, 公告统计区间, 担保笔数, 担保金额, 归属于母公司所有者权益, 担保金融占净资产比例
```python
stock_cg_guarantee_cninfo_df = ak.stock_cg_guarantee_cninfo(symbol="全部", start_date="20180630", end_date="20210927")
```

## stock_cg_lawsuit_cninfo
描述: 巨潮资讯-数据中心-专题统计-公司治理-公司诉讼
输入: symbol - 板块(全部/深市主板/沪市/创业板/科创板); start_date - 开始日期; end_date - 结束日期
输出: 证劵代码, 证券简称, 公告统计区间, 诉讼次数, 诉讼金额
```python
stock_cg_lawsuit_cninfo_df = ak.stock_cg_lawsuit_cninfo(symbol="全部", start_date="20180630", end_date="20210927")
```

## stock_a_gxl_lg
描述: 乐咕乐股-股息率-A股股息率
输入: symbol - 指数(上证A股/深证A股/创业板/科创板)
输出: 日期, 股息率
```python
stock_a_gxl_lg_df = ak.stock_a_gxl_lg(symbol="上证A股")
```

## stock_ipo_declare_em
描述: 东方财富网-数据中心-新股申购-首发申报企业信息
输入: 无
输出: 序号, 企业名称, 最新状态, 注册地, 保荐机构, 律师事务所, 会计师事务所, 拟上市地点, 更新日期, 招股说明书
```python
stock_ipo_declare_em_df = ak.stock_ipo_declare_em()
```

## stock_register_all_em
描述: 东方财富网-数据中心-新股数据-IPO审核信息-全部
输入: 无
输出: 序号, 企业名称, 最新状态, 注册地, 行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书
```python
stock_register_all_em_df = ak.stock_register_all_em()
```

## stock_register_kcb
描述: 东方财富网-数据中心-新股数据-IPO审核信息-科创板
输入: 无
输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书
```python
stock_register_kcb_df = ak.stock_register_kcb()
```

## stock_register_cyb
描述: 东方财富网-数据中心-新股数据-IPO审核信息-创业板
输入: 无
输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书
```python
stock_register_cyb_df = ak.stock_register_cyb()
```

## stock_register_sh
描述: 东方财富网-数据中心-新股数据-IPO审核信息-上海主板
输入: 无
输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书
```python
stock_register_sh_df = ak.stock_register_sh()
```

## stock_register_sz
描述: 东方财富网-数据中心-新股数据-IPO审核信息-深圳主板
输入: 无
输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书
```python
stock_register_sz_df = ak.stock_register_sz()
```

## stock_register_bj
描述: 东方财富网-数据中心-新股数据-IPO审核信息-北交所
输入: 无
输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书
```python
stock_register_bj_df = ak.stock_register_bj()
```

## stock_register_db
描述: 东方财富网-数据中心-新股数据-注册制审核-达标企业
输入: 无
输出: 序号, 企业名称, 经营范围, 近三年营业收入-2019, 近三年净利润-2019, 近三年研发费用-2019, 近三年营业收入-2018, 近三年净利润-2018, 近三年研发费用-2018, 近三年营业收入-2017, 近三年净利润-2017, 近三年研发费用-2017, 近两年累计净利润
```python
stock_register_db_df = ak.stock_register_db()
```

## stock_qbzf_em
描述: 东方财富网-数据中心-新股数据-增发-全部增发
输入: 无
输出: 股票代码, 股票简称, 增发代码, 发行方式, 发行总数, 网上发行, 发行价格, 最新价, 发行日期, 增发上市日期, 锁定期
```python
stock_qbzf_em_df = ak.stock_qbzf_em()
```

## stock_pg_em
描述: 东方财富网-数据中心-新股数据-配股
输入: 无
输出: 股票代码, 股票简称, 配售代码, 配股数量, 配股比例, 配股价, 最新价, 配股前总股本, 配股后总股本, 股权登记日, 缴款起始日期, 缴款截止日期, 上市日
```python
stock_pg_em_df = ak.stock_pg_em()
```

## stock_zt_pool_sub_new_em
描述: 东方财富网-行情中心-涨停板行情-次新股池(只能获取近期数据)
输入: date - 日期(如20241231)
输出: 序号, 代码, 名称, 涨跌幅, 最新价, 涨停价, 成交额, 流通市值, 总市值, 转手率, 开板几日, 开板日期, 上市日期, 是否新高, 涨停统计, 所属行业
```python
stock_zt_pool_sub_new_em_df = ak.stock_zt_pool_sub_new_em(date='20241231')
```
