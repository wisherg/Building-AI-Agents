# 股票板块与概念数据

> 本文档包含 21 个接口

```python
import akshare as ak
```

## 主营介绍-同花顺

描述: 同花顺-主营介绍
输入: symbol - 股票代码
输出: 股票代码, 主营业务, 产品类型, 产品名称, 经营范围

```python
ak.stock_zyjs_ths(symbol="000066")
```

## 主营构成-东财

描述: 东方财富网-个股-主营构成
输入: symbol - 如"SH688041"
输出: 股票代码, 报告日期, 分类类型, 主营构成, 主营收入, 收入比例, 主营成本, 成本比例, 主营利润, 利润比例, 毛利率

```python
ak.stock_zygc_em(symbol="SH688041")
```

## 板块排行-沪深港通

描述: 东方财富网-沪深港通持股-板块排行
输入: symbol - "北向资金增持行业板块排行"/"北向资金增持概念板块排行"/"北向资金增持地域板块排行"; indicator - "今日"/"3日"/"5日"/"10日"/"1月"/"1季"/"1年"
输出: 序号, 名称, 最新涨跌幅, 北向资金今日持股-股票只数, 北向资金今日持股-市值, 北向资金今日持股-占板块比, 北向资金今日持股-占北向资金比, 北向资金今日增持估计-股票只数, 北向资金今日增持估计-市值, 北向资金今日增持估计-市值增幅, 北向资金今日增持估计-占板块比, 北向资金今日增持估计-占北向资金比, 今日增持最大股-市值, 今日增持最大股-占股本比, 今日减持最大股-占股本比, 今日减持最大股-市值, 报告时间

```python
ak.stock_hsgt_board_rank_em(symbol="北向资金增持行业板块排行", indicator="今日")
```

## 板块行情-新浪

描述: 新浪行业-板块行情
输入: indicator - "新浪行业"/"启明星行业"/"概念"/"地域"/"行业"
输出: label, 板块, 公司家数, 平均价格, 涨跌额, 涨跌幅, 总成交量, 总成交额, 股票代码, 个股-涨跌幅, 个股-当前价, 个股-涨跌额, 股票名称

```python
ak.stock_sector_spot(indicator="新浪行业")
```

## 板块详情-新浪

描述: 新浪行业-板块行情-成份详情
输入: sector - 通过ak.stock_sector_spot返回数据的label字段选择
输出: symbol, code, name, trade, pricechange, changepercent, buy, sell, settlement, open, high, low, volume, amount, ticktime, per, pb, mktcap, nmc, turnoverratio

```python
ak.stock_sector_detail(sector="hangye_ZL01")
```

## 盈利预测-东财

描述: 东方财富网-研究报告-盈利预测
输入: symbol - 行业名称或空字符串(全部); 行业板块可通过ak.stock_board_industry_name_em()获取
输出: 序号, 代码, 名称, 研报数, 机构投资评级(近六个月)-买入, 机构投资评级(近六个月)-增持, 机构投资评级(近六个月)-中性, 机构投资评级(近六个月)-减持, 机构投资评级(近六个月)-卖出, 预测每股收益(多年)

```python
ak.stock_profit_forecast_em()
```

## 盈利预测-同花顺

描述: 同花顺-盈利预测
输入: symbol - 股票代码; indicator - "预测年报每股收益"/"预测年报净利润"/"业绩预测详表-机构"/"业绩预测详表-详细指标预测"
输出(每股收益/净利润): 年度, 预测机构数, 最小值, 均值, 最大值, 行业平均数
输出(机构): 机构名称, 研究员, 预测年报每股收益(多年), 预测年报净利润(多年), 报告日期
输出(详细指标): 预测指标, 实际值(多年), 预测平均(多年)

```python
ak.stock_profit_forecast_ths(symbol="600519", indicator="预测年报每股收益")
```

## 概念板块指数-同花顺

描述: 同花顺-概念板块-指数日频率数据
输入: symbol - 概念名称, 通过ak.stock_board_concept_name_ths()查看; start_date - 开始时间; end_date - 结束时间
输出: 日期, 开盘价, 最高价, 最低价, 收盘价, 成交量, 成交额

```python
ak.stock_board_concept_index_ths(symbol="阿里巴巴概念", start_date="20200101", end_date="20250321")
```

## 概念板块简介-同花顺

描述: 同花顺-概念板块-板块简介
输入: symbol - 概念名称, 通过ak.stock_board_concept_name_ths()查看
输出: 项目, 值

```python
ak.stock_board_concept_info_ths(symbol="阿里巴巴概念")
```

## 概念板块-东财

描述: 东方财富网-沪深京板块-概念板块实时行情
输入: 无
输出: 排名, 板块名称, 板块代码, 最新价, 涨跌额, 涨跌幅, 总市值, 换手率, 上涨家数, 下跌家数, 领涨股票, 领涨股票-涨跌幅

```python
ak.stock_board_concept_name_em()
```

## 概念板块实时行情-东财

描述: 东方财富网-概念板块-实时行情
输入: symbol - 概念名称
输出: item, value

```python
ak.stock_board_concept_spot_em(symbol="可燃冰")
```

## 概念板块成份股-东财

描述: 东方财富-概念板块-板块成份
输入: symbol - 概念名称或板块代码, 如"融资融券"/"BK0655"
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 换手率, 市盈率-动态, 市净率

```python
ak.stock_board_concept_cons_em(symbol="融资融券")
```

## 概念板块历史行情-东财

描述: 东方财富-概念板块-历史行情数据
输入: symbol - 概念名称或代码; period - "daily"/"weekly"/"monthly"; start_date; end_date; adjust - ""/"qfq"/"hfq"
输出: 日期, 开盘, 收盘, 最高, 最低, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 换手率

```python
ak.stock_board_concept_hist_em(symbol="绿色电力", period="daily", start_date="20220101", end_date="20250227", adjust="")
```

## 概念板块分时行情-东财

描述: 东方财富-概念板块-分时历史行情数据
输入: symbol - 概念名称或代码; period - "1"/"5"/"15"/"30"/"60"
输出(1分钟): 日期时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 最新价
输出(其他): 日期时间, 开盘, 收盘, 最高, 最低, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 换手率

```python
ak.stock_board_concept_hist_min_em(symbol="长寿药", period="5")
```

## 美股概念成分股-富途

描述: 富途牛牛-主题投资-概念板块-成分股
输入: symbol - "巴菲特持仓"/"佩洛西持仓"/"特朗普概念股"
输出: 代码, 股票名称, 最新价, 涨跌额, 涨跌幅, 成交量, 成交额

```python
ak.stock_concept_cons_futu(symbol="特朗普概念股")
```

## 行业板块指数-同花顺

描述: 同花顺-行业板块-指数日频率数据
输入: symbol - 行业名称, 通过ak.stock_board_industry_name_ths()查看; start_date; end_date
输出: 日期, 开盘价, 最高价, 最低价, 收盘价, 成交量, 成交额

```python
ak.stock_board_industry_index_ths(symbol="元件", start_date="20240101", end_date="20240718")
```

## 行业板块-东财

描述: 东方财富-沪深京板块-行业板块实时行情
输入: 无
输出: 排名, 板块名称, 板块代码, 最新价, 涨跌额, 涨跌幅, 总市值, 换手率, 上涨家数, 下跌家数, 领涨股票, 领涨股票-涨跌幅

```python
ak.stock_board_industry_name_em()
```

## 行业板块实时行情-东财

描述: 东方财富网-行业板块-实时行情
输入: symbol - 行业名称
输出: item, value

```python
ak.stock_board_industry_spot_em(symbol="小金属")
```

## 行业板块成份股-东财

描述: 东方财富-行业板块-板块成份
输入: symbol - 行业名称或板块代码, 如"小金属"/"BK1027"
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 换手率, 市盈率-动态, 市净率

```python
ak.stock_board_industry_cons_em(symbol="小金属")
```

## 行业板块历史行情-东财

描述: 东方财富-行业板块-历史行情数据
输入: symbol - 行业名称或代码; start_date; end_date; period - "日k"/"周k"/"月k"; adjust - ""/"qfq"/"hfq"
输出: 日期, 开盘, 收盘, 最高, 最低, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 换手率

```python
ak.stock_board_industry_hist_em(symbol="小金属", start_date="20211201", end_date="20240222", period="日k", adjust="")
```

## 行业板块分时行情-东财

描述: 东方财富-行业板块-分时历史行情数据
输入: symbol - 行业名称或代码; period - "1"/"5"/"15"/"30"/"60"
输出(1分钟): 日期时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 最新价
输出(其他): 日期时间, 开盘, 收盘, 最高, 最低, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 换手率

```python
ak.stock_board_industry_hist_min_em(symbol="小金属", period="5")
```
