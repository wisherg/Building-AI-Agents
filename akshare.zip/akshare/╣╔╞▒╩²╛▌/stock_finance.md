# 股票财务数据

```python
import akshare as ak
```

## stock_individual_basic_info_xq

描述: 雪球财经-个股-公司概况-公司简介

输入: symbol - 股票代码如SH601127; token - 默认None; timeout - 默认不设置超时

输出: item, value

```python
df = ak.stock_individual_basic_info_xq(symbol="SH601127")
```

## stock_individual_basic_info_us_xq

描述: 雪球-美股个股-公司概况-公司简介

输入: symbol - 美股代码如NVDA; token - 默认None; timeout - 默认不设置超时

输出: item, value

```python
df = ak.stock_individual_basic_info_us_xq(symbol="NVDA")
```

## stock_individual_basic_info_hk_xq

描述: 雪球-港股个股-公司概况-公司简介

输入: symbol - 港股代码如02097; token - 默认None; timeout - 默认不设置超时

输出: item, value

```python
df = ak.stock_individual_basic_info_hk_xq(symbol="02097")
```

## stock_hk_financial_indicator_em

描述: 东方财富-港股-核心必读-最新指标

输入: symbol - 港股代码如03900

输出: 基本每股收益, 每股净资产, 法定股本, 每手股, 每股股息TTM, 派息比率, 已发行股本, 每股经营现金流, 股息率TTM, 总市值, 港股市值, 营业总收入, 净利润, 股东权益回报率, 市盈率, 市净率, 总资产回报率

```python
df = ak.stock_hk_financial_indicator_em(symbol="03900")
```

## stock_sgt_settlement_exchange_rate_sse

描述: 沪港通-港股通信息披露-结算汇兑

输入: 无

输出: 适用日期, 买入结算汇兑比率, 卖出结算汇兑比率, 货币种类

```python
df = ak.stock_sgt_settlement_exchange_rate_sse()
```

## stock_sgt_reference_exchange_rate_sse

描述: 沪港通-港股通信息披露-参考汇率

输入: 无

输出: 适用日期, 参考汇率买入价, 参考汇率卖出价, 货币种类

```python
df = ak.stock_sgt_reference_exchange_rate_sse()
```

## stock_ipo_hk_ths

描述: 同花顺-数据中心-新股申购与中签-港股

输入: 无

输出: 股票代码, 股票简称, 申购代码, 发行总数, 网上发行, 申购上限, 顶格申购需配市值, 发行价格, 发行市盈率, 行业市盈率, 申购日期, 中签率, 中签号, 中签缴款日期, 上市日期, 打新收益, 首日最高涨幅, 连板天数

```python
df = ak.stock_ipo_hk_ths()
```

## stock_yjbb_em

描述: 东方财富-数据中心-年报季报-业绩报表

输入: date - 报告期如20200331, 可选XXXX0331/XXXX0630/XXXX0930/XXXX1231, 从20100331开始

输出: 序号, 股票代码, 股票简称, 每股收益, 营业总收入, 营业总收入同比增长, 营业总收入季度环比增长, 净利润, 净利润同比增长, 净利润季度环比增长, 每股净资产, 净资产收益率, 每股经营现金流量, 销售毛利率, 所处行业, 最新公告日期

```python
df = ak.stock_yjbb_em(date="20220331")
```

## stock_yjkb_em

描述: 东方财富-数据中心-年报季报-业绩快报

输入: date - 报告期如20200331, 可选XXXX0331/XXXX0630/XXXX0930/XXXX1231, 从20100331开始

输出: 序号, 股票代码, 股票简称, 每股收益, 营业收入, 营业收入去年同期, 营业收入同比增长, 营业收入季度环比增长, 净利润, 净利润去年同期, 净利润同比增长, 净利润季度环比增长, 每股净资产, 净资产收益率, 所处行业, 公告日期, 市场板块, 证券类型

```python
df = ak.stock_yjkb_em(date="20200331")
```

## stock_yjyg_em

描述: 东方财富-数据中心-年报季报-业绩预告

输入: date - 报告期如20200331, 可选XXXX0331/XXXX0630/XXXX0930/XXXX1231, 从20081231开始

输出: 序号, 股票代码, 股票简称, 预测指标, 业绩变动, 预测数值, 业绩变动幅度, 业绩变动原因, 预告类型, 上年同期值, 公告日期

```python
df = ak.stock_yjyg_em(date="20190331")
```

## stock_yysj_em

描述: 东方财富-数据中心-年报季报-预约披露时间

输入: symbol - 板块如沪深A股, 可选沪深A股/沪市A股/科创板/深市A股/创业板/京市A股/ST板; date - 报告期如20200331

输出: 序号, 股票代码, 股票简称, 首次预约时间, 一次变更日期, 二次变更日期, 三次变更日期, 实际披露时间

```python
df = ak.stock_yysj_em(symbol="沪深A股", date="20211231")
```

## stock_report_disclosure

描述: 巨潮资讯-数据-预约披露的数据

输入: market - 市场如沪深京, 可选沪深京/深市/深主板/创业板/沪市/沪主板/科创板/北交所; period - 报告期如2021年报

输出: 股票代码, 股票简称, 首次预约, 初次变更, 二次变更, 三次变更, 实际披露

```python
df = ak.stock_report_disclosure(market="沪深京", period="2022年报")
```

## stock_zh_a_disclosure_report_cninfo

描述: 巨潮资讯-首页-公告查询-信息披露公告-沪深京

输入: symbol - 股票代码如000001; market - 市场如沪深京, 可选沪深京/港股/三板/基金/债券/监管/预披露; keyword - 关键词; category - 分类如年报/半年报/一季报/三季报等; start_date - 起始日期如20230618; end_date - 结束日期如20231219

输出: 代码, 简称, 公告标题, 公告时间, 公告链接

```python
df = ak.stock_zh_a_disclosure_report_cninfo(symbol="000001", market="沪深京", category="公司治理", start_date="20230619", end_date="20231220")
```

## stock_zh_a_disclosure_relation_cninfo

描述: 巨潮资讯-首页-公告查询-信息披露调研-沪深京

输入: symbol - 股票代码如000001; market - 市场如沪深京; start_date - 起始日期如20230618; end_date - 结束日期如20231219

输出: 代码, 简称, 公告标题, 公告时间, 公告链接

```python
df = ak.stock_zh_a_disclosure_relation_cninfo(symbol="000001", market="沪深京", start_date="20230619", end_date="20231220")
```

## stock_industry_category_cninfo

描述: 巨潮资讯-数据-行业分类数据

输入: symbol - 分类标准如巨潮行业分类标准, 可选证监会行业分类标准/巨潮行业分类标准/申银万国行业分类标准/新财富行业分类标准/国资委行业分类标准/巨潮产业细分标准/天相行业分类标准/全球行业分类标准

输出: 类目编码, 类目名称, 终止日期, 行业类型, 行业类型编码, 类目名称英文, 父类编码, 分级

```python
df = ak.stock_industry_category_cninfo(symbol="巨潮行业分类标准")
```

## stock_industry_change_cninfo

描述: 巨潮资讯-数据-上市公司行业归属的变动情况

输入: symbol - 股票代码如002594; start_date - 起始日期如20091227; end_date - 结束日期如20220708

输出: 新证券简称, 行业中类, 行业大类, 行业次类, 行业门类, 机构名称, 行业编码, 分类标准, 分类标准编码, 证券代码, 变更日期

```python
df = ak.stock_industry_change_cninfo(symbol="002594", start_date="20091227", end_date="20220708")
```

## stock_share_change_cninfo

描述: 巨潮资讯-数据-公司股本变动

输入: symbol - 股票代码如002594; start_date - 起始日期; end_date - 结束日期

输出: 证券简称, 机构名称, 境外法人持股, 证券投资基金持股, 国家持股受限, 国有法人持股, 未流通股份, 人民币普通股, 总股本, 变动原因, 公告日期, 证券代码, 变动日期, 已流通股份, 流通受限股份, 优先股, 高管股 等

```python
df = ak.stock_share_change_cninfo(symbol="002594", start_date="20091227", end_date="20241021")
```

## stock_allotment_cninfo

描述: 巨潮资讯-个股-配股实施方案

输入: symbol - 股票代码如600030; start_date - 起始日期; end_date - 结束日期

输出: 记录标识, 证券简称, 停牌起始日, 上市公告日期, 配股缴款起始日, 可转配股数量, 实际配股数量, 配股价格, 配股比例, 配股前总股本, 实际募资净额, 发行方式, 除权基准日, 配股上市日, 配股缴款截止日, 实际募资总额, 预计募集资金, 配股后总股本, 公告日期 等

```python
df = ak.stock_allotment_cninfo(symbol="600030", start_date="19900101", end_date="20241022")
```

## stock_profile_cninfo

描述: 巨潮资讯-个股-公司概况

输入: symbol - 股票代码如600030

输出: 公司名称, 英文名称, 曾用简称, A股代码, A股简称, B股代码, B股简称, H股代码, H股简称, 入选指数, 所属市场, 所属行业, 法人代表, 注册资金, 成立日期, 上市日期, 官方网站, 电子邮箱, 联系电话, 传真, 注册地址, 办公地址, 邮政编码, 主营业务, 经营范围, 机构简介

```python
df = ak.stock_profile_cninfo(symbol="600030")
```

## stock_ipo_summary_cninfo

描述: 巨潮资讯-个股-上市相关

输入: symbol - 股票代码如600030

输出: 股票代码, 招股公告日期, 中签率公告日, 每股面值, 总发行数量, 发行前每股净资产, 摊薄发行市盈率, 募集资金净额, 上网发行日期, 上市日期, 发行价格, 发行费用总额, 发行后每股净资产, 上网发行中签率, 主承销商

```python
df = ak.stock_ipo_summary_cninfo(symbol="600030")
```

## stock_zcfz_em

描述: 东方财富-数据中心-年报季报-资产负债表-沪深

输入: date - 报告期如20240331, 可选XXXX0331/XXXX0630/XXXX0930/XXXX1231, 从20081231开始

输出: 序号, 股票代码, 股票简称, 资产-货币资金, 资产-应收账款, 资产-存货, 资产-总资产, 资产-总资产同比, 负债-应付账款, 负债-总负债, 负债-预收账款, 负债-总负债同比, 资产负债率, 股东权益合计, 公告日期

```python
df = ak.stock_zcfz_em(date="20240331")
```

## stock_zcfz_bj_em

描述: 东方财富-数据中心-年报季报-资产负债表-北交所

输入: date - 报告期如20240331, 可选XXXX0331/XXXX0630/XXXX0930/XXXX1231, 从20081231开始

输出: 序号, 股票代码, 股票简称, 资产-货币资金, 资产-应收账款, 资产-存货, 资产-总资产, 资产-总资产同比, 负债-应付账款, 负债-总负债, 负债-预收账款, 负债-总负债同比, 资产负债率, 股东权益合计, 公告日期

```python
df = ak.stock_zcfz_bj_em(date="20240331")
```

## stock_lrb_em

描述: 东方财富-数据中心-年报季报-利润表

输入: date - 报告期如20240331, 可选XXXX0331/XXXX0630/XXXX0930/XXXX1231, 从20120331开始

输出: 序号, 股票代码, 股票简称, 净利润, 净利润同比, 营业总收入, 营业总收入同比, 营业总支出-营业支出, 营业总支出-销售费用, 营业总支出-管理费用, 营业总支出-财务费用, 营业总支出-营业总支出, 营业利润, 利润总额, 公告日期

```python
df = ak.stock_lrb_em(date="20240331")
```

## stock_xjll_em

描述: 东方财富-数据中心-年报季报-现金流量表

输入: date - 报告期如20200331, 可选XXXX0331/XXXX0630/XXXX0930/XXXX1231, 从20081231开始

输出: 序号, 股票代码, 股票简称, 净现金流-净现金流, 净现金流-同比增长, 经营性现金流-现金流量净额, 经营性现金流-净现金流占比, 投资性现金流-现金流量净额, 投资性现金流-净现金流占比, 融资性现金流-现金流量净额, 融资性现金流-净现金流占比, 公告日期

```python
df = ak.stock_xjll_em(date="20240331")
```

## stock_fhps_em

描述: 东方财富-数据中心-年报季报-分红配送

输入: date - 报告期如20231231, 可选XXXX0630/XXXX1231, 从19901231开始

输出: 代码, 名称, 送转股份-送转总比例, 送转股份-送转比例, 送转股份-转股比例, 现金分红-现金分红比例, 现金分红-股息率, 每股收益, 每股净资产, 每股公积金, 每股未分配利润, 净利润同比增长, 总股本, 预案公告日, 股权登记日, 除权除息日, 方案进度, 最新公告日期

```python
df = ak.stock_fhps_em(date="20231231")
```

## stock_zdhtmx_em

描述: 东方财富网-数据中心-重大合同-重大合同明细

输入: start_date - 起始日期如20200819; end_date - 结束日期如20230819

输出: 序号, 股票代码, 股票简称, 签署主体, 签署主体与上市公司关系, 其他签署方, 其他签署方与上市公司关系, 合同类型, 合同名称, 合同金额, 上年度营业收入, 占上年度营业收入比例, 最新财务报表的营业收入, 签署日期, 公告日期

```python
df = ak.stock_zdhtmx_em(start_date="20220819", end_date="20230819")
```

## stock_financial_report_sina

描述: 新浪财经-财务报表-三大报表

输入: stock - 带市场标识的股票代码如sh600600; symbol - 报表类型, 可选资产负债表/利润表/现金流量表

输出: 报告日, 流动资产, ... , 类型, 更新日期

```python
df = ak.stock_financial_report_sina(stock="sh600600", symbol="资产负债表")
```

## stock_balance_sheet_by_report_em

描述: 东方财富-股票-财务分析-资产负债表-按报告期

输入: symbol - 股票代码如SH600519

输出: 319项字段(含SECUCODE, SECURITY_CODE等)

```python
df = ak.stock_balance_sheet_by_report_em(symbol="SH600519")
```

## stock_balance_sheet_by_yearly_em

描述: 东方财富-股票-财务分析-资产负债表-按年度

输入: symbol - 股票代码如SH600519

输出: 319项字段(含SECUCODE, SECURITY_CODE等)

```python
df = ak.stock_balance_sheet_by_yearly_em(symbol="SH600519")
```

## stock_profit_sheet_by_report_em

描述: 东方财富-股票-财务分析-利润表-按报告期

输入: symbol - 股票代码如SH600519

输出: 203项字段(含SECUCODE, SECURITY_CODE等)

```python
df = ak.stock_profit_sheet_by_report_em(symbol="SH600519")
```

## stock_profit_sheet_by_yearly_em

描述: 东方财富-股票-财务分析-利润表-按年度

输入: symbol - 股票代码如SH600519

输出: 203项字段(含SECUCODE, SECURITY_CODE等)

```python
df = ak.stock_profit_sheet_by_yearly_em(symbol="SH600519")
```

## stock_profit_sheet_by_quarterly_em

描述: 东方财富-股票-财务分析-利润表-按单季度

输入: symbol - 股票代码如SH600519

输出: 204项字段(含SECUCODE, SECURITY_CODE等)

```python
df = ak.stock_profit_sheet_by_quarterly_em(symbol="SH600519")
```

## stock_cash_flow_sheet_by_report_em

描述: 东方财富-股票-财务分析-现金流量表-按报告期

输入: symbol - 股票代码如SH600519

输出: 252项字段(含SECUCODE, SECURITY_CODE等)

```python
df = ak.stock_cash_flow_sheet_by_report_em(symbol="SH600519")
```

## stock_cash_flow_sheet_by_yearly_em

描述: 东方财富-股票-财务分析-现金流量表-按年度

输入: symbol - 股票代码如SH600519

输出: 314项字段(含SECUCODE, SECURITY_CODE等)

```python
df = ak.stock_cash_flow_sheet_by_yearly_em(symbol="SH600519")
```

## stock_cash_flow_sheet_by_quarterly_em

描述: 东方财富-股票-财务分析-现金流量表-按单季度

输入: symbol - 股票代码如SH600519

输出: 315项字段(含SECUCODE, SECURITY_CODE等)

```python
df = ak.stock_cash_flow_sheet_by_quarterly_em(symbol="SH600519")
```

## stock_financial_debt_new_ths

描述: 同花顺-财务指标-资产负债表

输入: symbol - 股票代码如000063; indicator - 按报告期/按年度

输出: report_date, report_name, report_period, quarter_name, metric_name, value, single, yoy, mom, single_yoy

```python
df = ak.stock_financial_debt_new_ths(symbol="000063", indicator="按年度")
```

## stock_financial_benefit_new_ths

描述: 同花顺-财务指标-利润表

输入: symbol - 股票代码如000063; indicator - 按报告期/一季度/二季度/三季度/四季度/按年度

输出: report_date, report_name, report_period, quarter_name, metric_name, value, single, yoy, mom, single_yoy

```python
df = ak.stock_financial_benefit_new_ths(symbol="000063", indicator="按报告期")
```

## stock_financial_cash_new_ths

描述: 同花顺-财务指标-现金流量表

输入: symbol - 股票代码如000063; indicator - 按报告期/一季度/二季度/三季度/四季度/按年度

输出: report_date, report_name, report_period, quarter_name, metric_name, value, single, yoy, mom, single_yoy

```python
df = ak.stock_financial_cash_new_ths(symbol="000063", indicator="按年度")
```

## stock_balance_sheet_by_report_delisted_em

描述: 东方财富-股票-财务分析-资产负债表-已退市股票-按报告期

输入: symbol - 带市场标识的已退市股票代码如SZ000013

输出: 319项字段(含SECUCODE, SECURITY_CODE等)

```python
df = ak.stock_balance_sheet_by_report_delisted_em(symbol="SZ000013")
```

## stock_profit_sheet_by_report_delisted_em

描述: 东方财富-股票-财务分析-利润表-已退市股票-按报告期

输入: symbol - 带市场标识的已退市股票代码如SZ000013

输出: 203项字段(含SECUCODE, SECURITY_CODE等)

```python
df = ak.stock_profit_sheet_by_report_delisted_em(symbol="SZ000013")
```

## stock_cash_flow_sheet_by_report_delisted_em

描述: 东方财富-股票-财务分析-现金流量表-已退市股票-按报告期

输入: symbol - 带市场标识的已退市股票代码如SZ000013

输出: 252项字段(含SECUCODE, SECURITY_CODE等)

```python
df = ak.stock_cash_flow_sheet_by_report_delisted_em(symbol="SZ000013")
```

## stock_financial_hk_report_em

描述: 东方财富-港股-财务报表-三大报表

输入: stock - 港股代码如00700; symbol - 报表类型, 可选资产负债表/利润表/现金流量表; indicator - 年度/报告期

输出: SECUCODE, SECURITY_CODE, SECURITY_NAME_ABBR, ORG_CODE, REPORT_DATE, DATE_TYPE_CODE, FISCAL_YEAR, STD_ITEM_CODE, STD_ITEM_NAME, AMOUNT, STD_REPORT_DATE

```python
df = ak.stock_financial_hk_report_em(stock="00700", symbol="资产负债表", indicator="年度")
```

## stock_financial_us_report_em

描述: 东方财富-美股-财务分析-三大报表

输入: stock - 美股代码如TSLA(BRK.A需改为BRK_A); symbol - 报表类型, 可选资产负债表/综合损益表/现金流量表; indicator - 年报/单季报/累计季报

输出: SECUCODE, SECURITY_CODE, SECURITY_NAME_ABBR, REPORT_DATE, REPORT_TYPE, REPORT, STD_ITEM_CODE, AMOUNT, ITEM_NAME

```python
df = ak.stock_financial_us_report_em(stock="TSLA", symbol="资产负债表", indicator="年报")
```

## stock_financial_abstract

描述: 新浪财经-财务报表-关键指标

输入: symbol - 股票代码如600004

输出: 选项, 指标, 各报告期数据

```python
df = ak.stock_financial_abstract(symbol="600004")
```

## stock_financial_abstract_new_ths

描述: 同花顺-财务指标-重要指标

输入: symbol - 股票代码如000063; indicator - 按报告期/一季度/二季度/三季度/四季度/按年度

输出: report_date, report_name, report_period, quarter_name, metric_name, value, single, yoy, mom, single_yoy

```python
df = ak.stock_financial_abstract_new_ths(symbol="000063", indicator="按报告期")
```

## stock_financial_analysis_indicator_em

描述: 东方财富-A股-财务分析-主要指标

输入: symbol - 股票代码如301389.SZ; indicator - 按报告期/按单季度

输出: SECUCODE, SECURITY_CODE, SECURITY_NAME_ABBR, REPORT_DATE, REPORT_TYPE, 基本每股收益, 扣非每股收益, 稀释每股收益, 每股净资产, 每股公积金, 每股未分配利润, 每股经营现金流, 营业总收入, 毛利润, 归属净利润, 扣非净利润, 营业总收入同比增长, 归属净利润同比增长, 净资产收益率, 毛利率, 净利率, 资产负债率, 流动比率, 速动比率, 存货周转率, 应收账款周转率, 总资产周转率 等

```python
df = ak.stock_financial_analysis_indicator_em(symbol="301389.SZ", indicator="按报告期")
```

## stock_financial_analysis_indicator

描述: 新浪财经-财务分析-财务指标

输入: symbol - 股票代码如600004; start_year - 开始查询年份如2020

输出: 日期, 摊薄每股收益, 加权每股收益, 每股净资产, 每股经营性现金流, 每股资本公积金, 每股未分配利润, 总资产利润率, 主营业务利润率, 销售净利率, 净资产收益率, 加权净资产收益率, 主营业务收入增长率, 净利润增长率, 净资产增长率, 总资产增长率, 应收账款周转率, 存货周转率, 总资产周转率, 流动比率, 速动比率, 资产负债率, 产权比率 等

```python
df = ak.stock_financial_analysis_indicator(symbol="600004", start_year="2020")
```

## stock_financial_hk_analysis_indicator_em

描述: 东方财富-港股-财务分析-主要指标

输入: symbol - 港股代码如00700; indicator - 年度/报告期

输出: SECUCODE, SECURITY_CODE, SECURITY_NAME_ABBR, REPORT_DATE, 每股经营现金流, 每股营业收入, 每股净资产, 基本每股收益, 稀释每股收益, 营业总收入, 营业总收入同比增长, 毛利润, 归母净利润, 归母净利润同比增长, 毛利率, TTM每股收益, 净利率, 平均净资产收益率, 总资产净利率, 年化净资产收益率, 年化投资回报率, 资产负债率, 流动比率 等

```python
df = ak.stock_financial_hk_analysis_indicator_em(symbol="00700", indicator="年度")
```

## stock_financial_us_analysis_indicator_em

描述: 东方财富-美股-财务分析-主要指标

输入: symbol - 美股代码如TSLA; indicator - 年报/单季报/累计季报

输出: SECUCODE, SECURITY_CODE, SECURITY_NAME_ABBR, REPORT_DATE, OPERATE_INCOME, OPERATE_INCOME_YOY, GROSS_PROFIT, PARENT_HOLDER_NETPROFIT, BASIC_EPS, DILUTED_EPS, GROSS_PROFIT_RATIO, NET_PROFIT_RATIO, ACCOUNTS_RECE_TR, INVENTORY_TR, TOTAL_ASSETS_TR, ROE_AVG, ROA, CURRENT_RATIO, SPEED_RATIO, DEBT_ASSET_RATIO, EQUITY_RATIO 等

```python
df = ak.stock_financial_us_analysis_indicator_em(symbol="TSLA", indicator="年报")
```

## stock_share_hold_change_szse

描述: 深圳证券交易所-信息披露-监管信息公开-董监高人员股份变动

输入: symbol - 股票代码如001308, 可选全部或具体股票代码

输出: 证券代码, 证券简称, 董监高姓名, 变动日期, 变动股份数量, 成交均价, 变动原因, 变动比例, 当日结存股数, 股份变动人姓名, 职务, 变动人与董监高的关系

```python
df = ak.stock_share_hold_change_szse(symbol="001308")
```

## stock_share_hold_change_bse

描述: 北京证券交易所-信息披露-监管信息-董监高及相关人员持股变动

输入: symbol - 股票代码如430489, 可选全部或具体股票代码

输出: 代码, 简称, 姓名, 职务, 变动日期, 变动股数, 变动前持股数, 变动后持股数, 变动均价, 变动原因

```python
df = ak.stock_share_hold_change_bse(symbol="430489")
```

## stock_zh_valuation_baidu

描述: 百度股市通-A股-财务报表-估值数据

输入: symbol - A股代码如002044; indicator - 总市值/市盈率(TTM)/市盈率(静)/市净率/市现率; period - 近一年/近三年/近五年/近十年/全部

输出: date, value

```python
df = ak.stock_zh_valuation_baidu(symbol="002044", indicator="总市值", period="近一年")
```

## stock_hk_valuation_baidu

描述: 百度股市通-港股-财务报表-估值数据

输入: symbol - 港股代码如02358; indicator - 总市值/市盈率(TTM)/市盈率(静)/市净率/市现率; period - 近一年/近三年/全部

输出: date, value

```python
df = ak.stock_hk_valuation_baidu(symbol="06969", indicator="总市值", period="近一年")
```

## stock_us_valuation_baidu

描述: 百度股市通-美股-财务报表-估值数据

输入: symbol - 美股代码如NVDA; indicator - 总市值/市盈率(TTM)/市盈率(静)/市净率/市现率; period - 近一年/近三年/全部

输出: date, value

```python
df = ak.stock_us_valuation_baidu(symbol="NVDA", indicator="总市值", period="近一年")
```
