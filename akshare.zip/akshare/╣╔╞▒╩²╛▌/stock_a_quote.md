# A股行情数据

```python
import akshare as ak
```

## stock_sse_summary
描述: 上海证券交易所-股票数据总貌
输入: 无
输出: 项目, 股票, 科创板, 主板
```python
stock_sse_summary_df = ak.stock_sse_summary()
```

## stock_individual_info_em
描述: 东方财富-个股-股票信息
输入: symbol - 股票代码; timeout - 超时参数
输出: item, value
```python
stock_individual_info_em_df = ak.stock_individual_info_em(symbol="000001")
```

## stock_individual_basic_info_xq
描述: 雪球财经-个股-公司概况-公司简介
输入: symbol - 股票代码(如SH601127); token - 默认None; timeout - 超时参数
输出: item, value
```python
stock_individual_basic_info_xq_df = ak.stock_individual_basic_info_xq(symbol="SH601127")
```

## stock_bid_ask_em
描述: 东方财富-行情报价
输入: symbol - 股票代码
输出: item, value
```python
stock_bid_ask_em_df = ak.stock_bid_ask_em(symbol="000001")
```

## stock_zh_a_spot_em
描述: 东方财富网-沪深京A股-实时行情数据
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率, 总市值, 流通市值, 涨速, 5分钟涨跌, 60日涨跌幅, 年初至今涨跌幅
```python
stock_zh_a_spot_em_df = ak.stock_zh_a_spot_em()
```

## stock_sh_a_spot_em
描述: 东方财富网-沪A股-实时行情数据
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率, 总市值, 流通市值, 涨速, 5分钟涨跌, 60日涨跌幅, 年初至今涨跌幅
```python
stock_sh_a_spot_em_df = ak.stock_sh_a_spot_em()
```

## stock_sz_a_spot_em
描述: 东方财富网-深A股-实时行情数据
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率, 总市值, 流通市值, 涨速, 5分钟涨跌, 60日涨跌幅, 年初至今涨跌幅
```python
stock_sz_a_spot_em_df = ak.stock_sz_a_spot_em()
```

## stock_bj_a_spot_em
描述: 东方财富网-京A股-实时行情数据
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率, 总市值, 流通市值, 涨速, 5分钟涨跌, 60日涨跌幅, 年初至今涨跌幅
```python
stock_bj_a_spot_em_df = ak.stock_bj_a_spot_em()
```

## stock_new_a_spot_em
描述: 东方财富网-新股-实时行情数据
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率, 上市时间, 总市值, 流通市值, 涨速, 5分钟涨跌, 60日涨跌幅, 年初至今涨跌幅
```python
stock_new_a_spot_em_df = ak.stock_new_a_spot_em()
```

## stock_cy_a_spot_em
描述: 东方财富网-创业板-实时行情
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率, 总市值, 流通市值, 涨速, 5分钟涨跌, 60日涨跌幅, 年初至今涨跌幅
```python
stock_cy_a_spot_em_df = ak.stock_cy_a_spot_em()
```

## stock_kc_a_spot_em
描述: 东方财富网-科创板-实时行情
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率, 总市值, 流通市值, 涨速, 5分钟涨跌, 60日涨跌幅, 年初至今涨跌幅
```python
stock_kc_a_spot_em_df = ak.stock_kc_a_spot_em()
```

## stock_zh_ab_comparison_em
描述: 东方财富网-沪深京个股-AB股比价
输入: 无
输出: 序号, B股代码, B股名称, 最新价B, 涨跌幅B, A股代码, A股名称, 最新价A, 涨跌幅A, 比价
```python
stock_zh_ab_comparison_em_df = ak.stock_zh_ab_comparison_em()
```

## stock_zh_a_spot
描述: 新浪财经-沪深京A股数据(重复调用易封IP)
输入: 无
输出: 代码, 名称, 最新价, 涨跌额, 涨跌幅, 买入, 卖出, 昨收, 今开, 最高, 最低, 成交量, 成交额, 时间戳
```python
stock_zh_a_spot_df = ak.stock_zh_a_spot()
```

## stock_individual_spot_xq
描述: 雪球-行情中心-个股
输入: symbol - 证券代码(如SH600000); token - 默认None; timeout - 超时参数
输出: item, value
```python
stock_individual_spot_xq_df = ak.stock_individual_spot_xq(symbol="SH600000")
```

## stock_zh_a_hist
描述: 东方财富-沪深京A股日频率历史数据; adjust可选qfq(前复权)/hfq(后复权)/空(不复权)
输入: symbol - 股票代码; period - 周期(daily/weekly/monthly); start_date - 开始日期; end_date - 结束日期; adjust - 复权方式; timeout - 超时参数
输出: 日期, 股票代码, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 振幅, 涨跌幅, 涨跌额, 换手率
```python
stock_zh_a_hist_df = ak.stock_zh_a_hist(symbol="000001", period="daily", start_date="20170301", end_date="20240528", adjust="")
```

## stock_zh_a_daily
描述: 新浪财经-沪深京A股历史数据(建议切换为stock_zh_a_hist); adjust可选qfq/hfq/qfq-factor/hfq-factor
输入: symbol - 带市场标识股票代码(如sh600000); start_date - 开始日期; end_date - 结束日期; adjust - 复权方式
输出: date, open, high, low, close, volume, amount, outstanding_share, turnover
```python
stock_zh_a_daily_df = ak.stock_zh_a_daily(symbol="sz000001", start_date="19910403", end_date="20231027", adjust="qfq")
```

## stock_zh_a_hist_tx
描述: 腾讯证券-日频-股票历史数据
输入: symbol - 带市场标识股票代码(如sz000001); start_date - 开始日期; end_date - 结束日期; adjust - 复权方式; timeout - 超时参数
输出: date, open, close, high, low, amount
```python
stock_zh_a_hist_tx_df = ak.stock_zh_a_hist_tx(symbol="sz000001", start_date="20200101", end_date="20231027", adjust="")
```

## stock_zh_a_minute
描述: 新浪财经-沪深京A股分时数据(1/5/15/30/60分钟)
输入: symbol - 带市场标识股票代码(如sh600751); period - 频率(1/5/15/30/60); adjust - 复权方式
输出: day, open, high, low, close, volume, amount
```python
stock_zh_a_minute_df = ak.stock_zh_a_minute(symbol='sh600751', period='1', adjust="qfq")
```

## stock_zh_a_hist_min_em
描述: 东方财富网-沪深京A股-每日分时行情; 1分钟数据只返回近5个交易日且不复权
输入: symbol - 股票代码; start_date - 开始日期时间; end_date - 结束日期时间; period - 频率(1/5/15/30/60); adjust - 复权方式
输出: 时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 均价(1分钟); 涨跌幅, 涨跌额, 振幅, 换手率(其他)
```python
stock_zh_a_hist_min_em_df = ak.stock_zh_a_hist_min_em(symbol="000001", start_date="2024-03-20 09:30:00", end_date="2024-03-20 15:00:00", period="5", adjust="hfq")
```

## stock_intraday_em
描述: 东方财富-分时数据(最近一个交易日,包含盘前数据)
输入: symbol - 股票代码
输出: 时间, 成交价, 手数, 买卖盘性质
```python
stock_intraday_em_df = ak.stock_intraday_em(symbol="000001")
```

## stock_intraday_sina
描述: 新浪财经-日内分时数据(仅返回大单数据>=400手)
输入: symbol - 带市场标识股票代码(如sz000001); date - 交易日
输出: symbol, name, ticktime, price, volume, prev_price, kind
```python
stock_intraday_sina_df = ak.stock_intraday_sina(symbol="sz000001", date="20240321")
```

## stock_zh_a_hist_pre_min_em
描述: 东方财富-股票行情-盘前数据(包含盘前分钟数据)
输入: symbol - 股票代码; start_time - 开始时间; end_time - 结束时间
输出: 时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 最新价
```python
stock_zh_a_hist_pre_min_em_df = ak.stock_zh_a_hist_pre_min_em(symbol="000001", start_time="09:00:00", end_time="15:40:00")
```

## stock_zh_a_tick_tx_js
描述: 腾讯财经-历史分笔数据(每个交易日16:00后提供)
输入: symbol - 带市场标识股票代码(如sz000001)
输出: 成交时间, 成交价格, 价格变动, 成交量, 成交额, 性质
```python
stock_zh_a_tick_tx_js_df = ak.stock_zh_a_tick_tx_js(symbol="sz000001")
```

## stock_zh_a_cdr_daily
描述: 上海证券交易所-科创板-CDR历史行情
输入: symbol - CDR股票代码(如sh689009); start_date - 开始日期; end_date - 结束日期
输出: date, open, high, low, close, volume
```python
stock_zh_a_cdr_daily_df = ak.stock_zh_a_cdr_daily(symbol='sh689009', start_date='20201103', end_date='20201116')
```

## stock_zh_b_spot_em
描述: 东方财富网-B股实时行情数据
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 最高, 最低, 今开, 昨收, 量比, 换手率, 市盈率-动态, 市净率, 总市值, 流通市值, 涨速, 5分钟涨跌, 60日涨跌幅, 年初至今涨跌幅
```python
stock_zh_b_spot_em_df = ak.stock_zh_b_spot_em()
```

## stock_zh_b_spot
描述: 新浪财经-B股实时行情数据(重复调用易封IP)
输入: 无
输出: 代码, 名称, 最新价, 涨跌额, 涨跌幅, 买入, 卖出, 昨收, 今开, 最高, 最低, 成交量, 成交额
```python
stock_zh_b_spot_df = ak.stock_zh_b_spot()
```

## stock_zh_b_daily
描述: 新浪财经-B股历史行情数据; adjust可选qfq/hfq/qfq-factor/hfq-factor
输入: symbol - 带市场标识B股代码(如sh900901); start_date - 开始日期; end_date - 结束日期; adjust - 复权方式
输出: date, open, high, low, close, volume, outstanding_share, turnover
```python
stock_zh_b_daily_df = ak.stock_zh_b_daily(symbol="sh900901", start_date="19900103", end_date="20240722", adjust="qfq")
```

## stock_zh_b_minute
描述: 新浪财经-B股分时数据(1/5/15/30/60分钟)
输入: symbol - 带市场标识B股代码(如sh900901); period - 频率(1/5/15/30/60); adjust - 复权方式
输出: day, open, high, low, close, volume
```python
stock_zh_b_minute_df = ak.stock_zh_b_minute(symbol='sh900901', period='1', adjust="qfq")
```

## stock_zh_kcb_spot
描述: 新浪财经-科创板股票实时行情数据(大量抓取易封IP)
输入: 无
输出: 代码, 名称, 最新价, 涨跌额, 涨跌幅, 买入, 卖出, 昨收, 今开, 最高, 最低, 成交量, 成交额, 时点, 市盈率, 市净率, 流通市值, 总市值, 换手率
```python
stock_zh_kcb_spot_df = ak.stock_zh_kcb_spot()
```

## stock_zh_kcb_daily
描述: 新浪财经-科创板股票历史行情数据; adjust可选qfq/hfq/qfq-factor/hfq-factor
输入: symbol - 带市场标识股票代码(如sh688008); adjust - 复权方式
输出: date, close, high, low, open, volume, after_volume, after_amount, outstanding_share, turnover
```python
stock_zh_kcb_daily_df = ak.stock_zh_kcb_daily(symbol="sh688399", adjust="hfq")
```

## stock_zh_ah_spot_em
描述: 东方财富网-沪深港通-AH股比价-实时行情(延迟15分钟)
输入: 无
输出: 序号, 名称, H股代码, 最新价-HKD, H股-涨跌幅, A股代码, 最新价-RMB, A股-涨跌幅, 比价, 溢价
```python
stock_zh_ah_spot_em_df = ak.stock_zh_ah_spot_em()
```

## stock_zh_ah_spot
描述: 腾讯财经-A+H股实时行情数据(延迟15分钟)
输入: 无
输出: 代码, 名称, 最新价, 涨跌幅, 涨跌额, 买入, 卖出, 成交量, 成交额, 今开, 昨收, 最高, 最低
```python
stock_zh_ah_spot_df = ak.stock_zh_ah_spot()
```

## stock_zh_ah_daily
描述: 腾讯财经-A+H股历史行情数据
输入: symbol - 港股股票代码(如02318); start_year - 开始年份; end_year - 结束年份; adjust - 复权方式
输出: 日期, 开盘, 收盘, 最高, 最低, 成交量
```python
stock_zh_ah_daily_df = ak.stock_zh_ah_daily(symbol="02318", start_year="2022", end_year="2024", adjust="")
```

## stock_us_spot_em
描述: 东方财富网-美股-实时行情
输入: 无
输出: 序号, 名称, 最新价, 涨跌额, 涨跌幅, 开盘价, 最高价, 最低价, 昨收价, 总市值, 市盈率, 成交量, 成交额, 振幅, 换手率, 代码
```python
stock_us_spot_em_df = ak.stock_us_spot_em()
```

## stock_us_spot
描述: 新浪财经-美股实时行情(15分钟延迟; 建议用stock_us_spot_em)
输入: 无
输出: 新浪默认字段
```python
us_stock_current_df = ak.stock_us_spot()
```

## stock_us_hist
描述: 东方财富网-美股-每日行情
输入: symbol - 美股代码(如106.TTE); period - 周期(daily/weekly/monthly); start_date - 开始日期; end_date - 结束日期; adjust - 复权方式
输出: 日期, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 振幅, 涨跌幅, 涨跌额, 换手率
```python
stock_us_hist_df = ak.stock_us_hist(symbol='106.TTE', period="daily", start_date="20200101", end_date="20240214", adjust="qfq")
```

## stock_individual_basic_info_us_xq
描述: 雪球-美股个股-公司概况-公司简介
输入: symbol - 股票代码(如NVDA); token - 默认None; timeout - 超时参数
输出: item, value
```python
stock_individual_basic_info_us_xq_df = ak.stock_individual_basic_info_us_xq(symbol="NVDA")
```

## stock_us_hist_min_em
描述: 东方财富网-美股-每日分时行情(最近5个交易日)
输入: symbol - 美股代码(如105.ATER); start_date - 开始日期时间; end_date - 结束日期时间
输出: 时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 最新价
```python
stock_us_hist_min_em_df = ak.stock_us_hist_min_em(symbol="105.ATER")
```

## stock_us_daily
描述: 新浪财经-美股历史行情数据; adjust可选qfq/qfq-factor
输入: symbol - 美股代码(如AAPL); adjust - 复权方式
输出: date, open, high, low, close, volume
```python
stock_us_daily_df = ak.stock_us_daily(symbol="AAPL", adjust="")
```

## stock_us_pink_spot_em
描述: 美股粉单市场实时行情数据
输入: 无
输出: 序号, 名称, 最新价, 涨跌额, 涨跌幅, 开盘价, 最高价, 最低价, 昨收价, 总市值, 市盈率, 代码
```python
stock_us_pink_spot_em_df = ak.stock_us_pink_spot_em()
```

## stock_us_famous_spot_em
描述: 美股-知名美股实时行情数据
输入: symbol - 分类(科技类/金融类/医药食品类/媒体类/汽车能源类/制造零售类)
输出: 序号, 名称, 最新价, 涨跌额, 涨跌幅, 开盘价, 最高价, 最低价, 昨收价, 总市值, 市盈率, 代码
```python
stock_us_famous_spot_em_df = ak.stock_us_famous_spot_em(symbol='科技类')
```

## stock_hk_spot_em
描述: 东方财富网-港股实时行情数据(15分钟延时)
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 今开, 最高, 最低, 昨收, 成交量, 成交额
```python
stock_hk_spot_em_df = ak.stock_hk_spot_em()
```

## stock_hk_main_board_spot_em
描述: 东方财富网-港股主板实时行情数据(15分钟延时)
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 今开, 最高, 最低, 昨收, 成交量, 成交额
```python
stock_hk_main_board_spot_em_df = ak.stock_hk_main_board_spot_em()
```

## stock_hk_spot
描述: 新浪财经-港股实时行情数据(15分钟延时)
输入: 无
输出: 日期时间, 代码, 中文名称, 英文名称, 交易类型, 最新价, 涨跌额, 涨跌幅, 昨收, 今开, 最高, 最低, 成交量, 成交额, 买一, 卖一
```python
stock_hk_spot_df = ak.stock_hk_spot()
```

## stock_individual_basic_info_hk_xq
描述: 雪球-港股个股-公司概况-公司简介
输入: symbol - 港股代码(如02097); token - 默认None; timeout - 超时参数
输出: item, value
```python
stock_individual_basic_info_hk_xq_df = ak.stock_individual_basic_info_hk_xq(symbol="02097")
```

## stock_hk_hist_min_em
描述: 东方财富网-港股-每日分时行情(最近5个交易日); 1分钟数据不复权
输入: symbol - 港股代码; period - 频率(1/5/15/30/60); adjust - 复权方式; start_date - 开始日期时间; end_date - 结束日期时间
输出: 时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 最新价(1分钟); 涨跌幅, 涨跌额, 振幅, 换手率(其他)
```python
stock_hk_hist_min_em_df = ak.stock_hk_hist_min_em(symbol="01611", period='5', adjust='hfq', start_date="2021-09-01 09:32:00", end_date="2021-09-07 18:32:00")
```

## stock_hk_hist
描述: 东方财富网-港股-历史行情数据
输入: symbol - 港股代码; period - 周期(daily/weekly/monthly); start_date - 开始日期; end_date - 结束日期; adjust - 复权方式
输出: 日期, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 振幅, 涨跌幅, 涨跌额, 换手率
```python
stock_hk_hist_df = ak.stock_hk_hist(symbol="00593", period="daily", start_date="19700101", end_date="22220101", adjust="")
```

## stock_hk_daily
描述: 新浪财经-港股-历史行情数据; adjust可选qfq/hfq/qfq-factor/hfq-factor
输入: symbol - 港股代码; adjust - 复权方式
输出: date, open, high, low, close, volume
```python
stock_hk_daily_df = ak.stock_hk_daily(symbol="00700", adjust="hfq")
```

## stock_hk_famous_spot_em
描述: 东方财富网-港股市场-知名港股实时行情数据
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 今开, 最高, 最低, 昨收, 成交量, 成交额
```python
stock_hk_famous_spot_em_df = ak.stock_hk_famous_spot_em()
```

## stock_hsgt_fund_min_em
描述: 东方财富-沪深港通-市场概括-分时数据(20240513起数据源不再提供)
输入: symbol - 北向资金/南向资金
输出: 日期, 时间, 沪股通, 深股通, 北向资金(北向); 港股通(沪), 港股通(深), 南向资金(南向)
```python
stock_hsgt_fund_min_em_df = ak.stock_hsgt_fund_min_em(symbol="北向资金")
```

## stock_board_concept_name_em
描述: 东方财富网-沪深京板块-概念板块
输入: 无
输出: 排名, 板块名称, 板块代码, 最新价, 涨跌额, 涨跌幅, 总市值, 换手率, 上涨家数, 下跌家数, 领涨股票, 领涨股票-涨跌幅
```python
stock_board_concept_name_em_df = ak.stock_board_concept_name_em()
```

## stock_board_concept_spot_em
描述: 东方财富网-概念板块-实时行情
输入: symbol - 概念板块名称(如可燃冰)
输出: item, value
```python
stock_board_concept_spot_em_df = ak.stock_board_concept_spot_em(symbol="可燃冰")
```

## stock_board_concept_hist_em
描述: 东方财富-概念板块-历史行情数据
输入: symbol - 概念板块名称(如绿色电力); period - 周期(daily/weekly/monthly); start_date - 开始日期; end_date - 结束日期; adjust - 复权方式
输出: 日期, 开盘, 收盘, 最高, 最低, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 换手率
```python
stock_board_concept_hist_em_df = ak.stock_board_concept_hist_em(symbol="绿色电力", period="daily", start_date="20220101", end_date="20250227", adjust="")
```

## stock_board_concept_hist_min_em
描述: 东方财富-概念板块-分时历史行情数据
输入: symbol - 概念板块名称(如长寿药); period - 频率(1/5/15/30/60)
输出: 日期时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 最新价(1分钟); 涨跌幅, 涨跌额, 振幅, 换手率(其他)
```python
stock_board_concept_hist_min_em_df = ak.stock_board_concept_hist_min_em(symbol="长寿药", period="5")
```

## stock_board_industry_name_em
描述: 东方财富-沪深京板块-行业板块
输入: 无
输出: 排名, 板块名称, 板块代码, 最新价, 涨跌额, 涨跌幅, 总市值, 换手率, 上涨家数, 下跌家数, 领涨股票, 领涨股票-涨跌幅
```python
stock_board_industry_name_em_df = ak.stock_board_industry_name_em()
```

## stock_board_industry_spot_em
描述: 东方财富网-行业板块-实时行情
输入: symbol - 行业板块名称(如小金属)
输出: item, value
```python
stock_board_industry_spot_em_df = ak.stock_board_industry_spot_em(symbol="小金属")
```

## stock_board_industry_hist_em
描述: 东方财富-行业板块-历史行情数据
输入: symbol - 行业板块名称(如小金属); start_date - 开始日期; end_date - 结束日期; period - 周期(日k/周k/月k); adjust - 复权方式
输出: 日期, 开盘, 收盘, 最高, 最低, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 换手率
```python
stock_board_industry_hist_em_df = ak.stock_board_industry_hist_em(symbol="小金属", start_date="20211201", end_date="20240222", period="日k", adjust="")
```

## stock_board_industry_hist_min_em
描述: 东方财富-行业板块-分时历史行情数据
输入: symbol - 行业板块名称(如小金属); period - 频率(1/5/15/30/60)
输出: 日期时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 最新价(1分钟); 涨跌幅, 涨跌额, 振幅, 换手率(其他)
```python
stock_board_industry_hist_min_em_df = ak.stock_board_industry_hist_min_em(symbol="小金属", period="5")
```
