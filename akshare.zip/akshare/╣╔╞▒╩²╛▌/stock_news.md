# 股票资讯与手续费数据

```python
import akshare as ak
```

## stock_xgsr_ths
描述: 同花顺-新股上市首日数据
输入: 无
输出: 序号, 股票代码, 股票简称, 上市日期, 发行价, 最新价, 首日开盘价, 首日收盘价, 首日最高价, 首日最低价, 首日涨跌幅, 是否破发
```python
stock_xgsr_ths_df = ak.stock_xgsr_ths()
```

## stock_ipo_benefit_ths
描述: 同花顺-IPO受益股
输入: 无
输出: 序号, 股票代码, 股票简称, 收盘价, 涨跌幅, 市值, 参股家数, 投资总额, 投资占市值比, 参股对象
```python
stock_ipo_benefit_ths_df = ak.stock_ipo_benefit_ths()
```

## stock_news_em
描述: 东方财富指定个股的新闻资讯数据
输入: symbol - 股票代码或关键词如"603777"
输出: 关键词, 新闻标题, 新闻内容, 发布时间, 文章来源, 新闻链接
```python
stock_news_em_df = ak.stock_news_em(symbol="603777")
```

## stock_news_main_cx
描述: 财新网-财新数据通-最新新闻
输入: 无
输出: tag, summary, url
```python
stock_news_main_cx_df = ak.stock_news_main_cx()
```

## news_report_time_baidu
描述: 百度股市通-财报发行(含港股)
输入: date - 日期如"20241107"
输出: 股票代码, 交易所, 股票简称, 财报期
```python
news_report_time_baidu_df = ak.news_report_time_baidu(date="20241107")
```

## stock_dxsyl_em
描述: 东方财富网-打新收益率
输入: 无
输出: 股票代码, 股票简称, 发行价, 最新价, 网上发行中签率, 网上有效申购股数, 网上有效申购户数, 网上超额认购倍数, 网下配售中签率, 网下有效申购股数, 网下有效申购户数, 网下配售认购倍数, 总发行数量, 开盘溢价, 首日涨幅, 上市日期
```python
stock_dxsyl_em_df = ak.stock_dxsyl_em()
```

## stock_xgsglb_em
描述: 东方财富网-新股申购与中签查询
输入: symbol - "全部股票"/"沪市主板"/"科创板"/"深市主板"/"创业板"/"北交所"
输出: 股票代码, 股票简称, 交易所, 板块, 申购代码, 发行总数, 网上发行, 顶格申购需配市值, 申购上限, 发行价格, 最新价, 首日收盘价, 申购日期, 中签号公布日, 中签缴款日期, 上市日期, 发行市盈率, 行业市盈率, 中签率, 询价累计报价倍数, 配售对象报价家数, 连续一字板数量, 涨幅, 每中一签获利
```python
stock_xgsglb_em_df = ak.stock_xgsglb_em(symbol="全部股票")
```

## stock_ipo_ths
描述: 同花顺-新股申购与中签
输入: symbol - "全部A股"/"沪市主板"/"深市主板"/"创业板"/"科创板"/"京市主板"
输出: 股票代码, 股票简称, 申购代码, 发行总数（万股）, 网上发行（万股）, 申购上限（万股）, 顶格申购需配市值（万元）, 发行价格, 发行市盈率, 行业市盈率, 申购日期, 中签率（%）, 中签号, 中签缴款日期, 上市日期, 打新收益（元）, 首日最高涨幅, 连板天数
```python
stock_ipo_ths_df = ak.stock_ipo_ths(symbol="全部A股")
```

## stock_ipo_hk_ths
描述: 同花顺-港股新股申购与中签
输入: 无
输出: 股票代码, 股票简称, 申购代码, 发行总数（万股）, 网上发行（万股）, 申购上限（万股）, 顶格申购需配市值（万元）, 发行价格, 发行市盈率, 行业市盈率, 申购日期, 中签率（%）, 中签号, 中签缴款日期, 上市日期, 打新收益（元）, 首日最高涨幅, 连板天数
```python
stock_ipo_hk_ths_df = ak.stock_ipo_hk_ths()
```

## stock_new_gh_cninfo
描述: 巨潮资讯-新股过会
输入: 无
输出: 公司名称, 上会日期, 审核类型, 审议内容, 审核结果, 审核公告日
```python
stock_new_gh_cninfo_df = ak.stock_new_gh_cninfo()
```

## stock_new_ipo_cninfo
描述: 巨潮资讯-新股发行
输入: 无
输出: 证劵代码, 证券简称, 上市日期, 申购日期, 发行价, 总发行数量, 发行市盈率, 上网发行中签率, 摇号结果公告日, 中签公告日, 中签缴款日, 网上申购上限, 上网发行数量
```python
stock_new_ipo_cninfo_df = ak.stock_new_ipo_cninfo()
```

## stock_register_all_em
描述: 东方财富网-IPO审核信息-全部
输入: 无
输出: 序号, 企业名称, 最新状态, 注册地, 行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书
```python
stock_register_all_em_df = ak.stock_register_all_em()
```

## stock_register_kcb
描述: 东方财富网-IPO审核信息-科创板
输入: 无
输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书
```python
stock_register_kcb_df = ak.stock_register_kcb()
```

## stock_register_cyb
描述: 东方财富网-IPO审核信息-创业板
输入: 无
输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书
```python
stock_register_cyb_df = ak.stock_register_cyb()
```

## stock_register_sh
描述: 东方财富网-IPO审核信息-上海主板
输入: 无
输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书
```python
stock_register_sh_df = ak.stock_register_sh()
```

## stock_register_sz
描述: 东方财富网-IPO审核信息-深圳主板
输入: 无
输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书
```python
stock_register_sz_df = ak.stock_register_sz()
```

## stock_register_bj
描述: 东方财富网-IPO审核信息-北交所
输入: 无
输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书
```python
stock_register_bj_df = ak.stock_register_bj()
```

## stock_register_db
描述: 东方财富网-注册制审核-达标企业
输入: 无
输出: 序号, 企业名称, 经营范围, 近三年营业收入, 近三年净利润, 近三年研发费用, 近两年累计净利润
```python
stock_register_db_df = ak.stock_register_db()
```

## stock_qbzf_em
描述: 东方财富网-全部增发
输入: 无
输出: 股票代码, 股票简称, 增发代码, 发行方式, 发行总数, 网上发行, 发行价格, 最新价, 发行日期, 增发上市日期, 锁定期
```python
stock_qbzf_em_df = ak.stock_qbzf_em()
```

## stock_pg_em
描述: 东方财富网-配股
输入: 无
输出: 股票代码, 股票简称, 配售代码, 配股数量, 配股比例, 配股价, 最新价, 配股前总股本, 配股后总股本, 股权登记日, 缴款起始日期, 缴款截止日期, 上市日
```python
stock_pg_em_df = ak.stock_pg_em()
```

## stock_market_activity_legu
描述: 乐咕乐股网-赚钱效应分析
输入: 无
输出: item, value
```python
stock_market_activity_legu_df = ak.stock_market_activity_legu()
```

## stock_info_global_cls
描述: 财联社-电报
输入: symbol - "全部"或"重点"
输出: 标题, 内容, 发布日期, 发布时间
```python
stock_info_global_cls_df = ak.stock_info_global_cls(symbol="全部")
```
