# 股票分红与融资数据

```python
import akshare as ak
```

## stock_sse_deal_daily

描述: 上海证券交易所-每日股票成交概况; 仅支持20211227之后数据

输入: date - 日期, 如"20250221"

输出: 单日情况, 股票, 主板A, 主板B, 科创板, 股票回购

```python
df = ak.stock_sse_deal_daily(date="20250221")
```

## stock_zh_a_hist

描述: 东方财富-沪深京A股日/周/月频率历史行情数据

输入: symbol - 股票代码, 如"000001"; period - 周期, daily/weekly/monthly; start_date - 开始日期; end_date - 结束日期; adjust - 复权方式, ""/qfq/hfq; timeout - 超时

输出: 日期, 股票代码, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 振幅, 涨跌幅, 涨跌额, 换手率

```python
df = ak.stock_zh_a_hist(symbol="000001", period="daily", start_date="20170301", end_date="20240528", adjust="")
```

## stock_zh_a_daily

描述: 新浪财经-沪深京A股历史行情数据; 建议使用stock_zh_a_hist替代

输入: symbol - 带市场标识代码, 如"sh600000"; start_date - 开始日期; end_date - 结束日期; adjust - 复权方式, ""/qfq/hfq/qfq-factor/hfq-factor

输出: date, open, high, low, close, volume, amount, outstanding_share, turnover

```python
df = ak.stock_zh_a_daily(symbol="sz000001", start_date="19910403", end_date="20231027", adjust="qfq")
```

## stock_zh_a_hist_tx

描述: 腾讯证券-沪深京A股日频历史行情数据

输入: symbol - 带市场标识代码, 如"sz000001"; start_date - 开始日期; end_date - 结束日期; adjust - 复权方式, ""/qfq/hfq; timeout - 超时

输出: date, open, close, high, low, amount

```python
df = ak.stock_zh_a_hist_tx(symbol="sz000001", start_date="20200101", end_date="20231027", adjust="")
```

## stock_zh_b_daily

描述: 新浪财经-B股历史行情数据

输入: symbol - 带市场标识代码, 如"sh900901"; start_date - 开始日期; end_date - 结束日期; adjust - 复权方式, ""/qfq/hfq/qfq-factor/hfq-factor

输出: date, close, high, low, open, volume, outstanding_share, turnover

```python
df = ak.stock_zh_b_daily(symbol="sh900901", start_date="19900103", end_date="20240722", adjust="qfq")
```

## stock_hk_dividend_payout_em

描述: 东方财富-港股核心必读-分红派息

输入: symbol - 港股代码, 如"03900"

输出: 最新公告日期, 财政年度, 分红方案, 分配类型, 除净日, 截至过户日, 发放日

```python
df = ak.stock_hk_dividend_payout_em(symbol="03900")
```

## news_trade_notify_dividend_baidu

描述: 百度股市通-交易提醒-分红派息; 含港股数据

输入: date - 日期, 如"20241107"; cookie - 可选cookie

输出: 股票代码, 除权日, 分红, 送股, 转增, 实物, 交易所, 股票简称, 报告期

```python
df = ak.news_trade_notify_dividend_baidu(date="20251126")
```

## stock_zh_a_disclosure_report_cninfo

描述: 巨潮资讯-信息披露公告-沪深京

输入: symbol - 股票代码; market - 市场, 沪深京/港股/三板/基金/债券/监管/预披露; keyword - 关键词; category - 公告类别, 如年报/半年报/权益分派等; start_date - 开始日期; end_date - 结束日期

输出: 代码, 简称, 公告标题, 公告时间, 公告链接

```python
df = ak.stock_zh_a_disclosure_report_cninfo(symbol="000001", market="沪深京", category="公司治理", start_date="20230619", end_date="20231220")
```

## stock_share_change_cninfo

描述: 巨潮资讯-公司股本变动

输入: symbol - 股票代码, 如"002594"; start_date - 开始日期; end_date - 结束日期

输出: 证券简称, 机构名称, 总股本, 流通受限股份, 已流通股份, 未流通股份, 变动原因, 公告日期, 变动日期 等

```python
df = ak.stock_share_change_cninfo(symbol="002594", start_date="20091227", end_date="20241021")
```

## stock_allotment_cninfo

描述: 巨潮资讯-个股配股实施方案

输入: symbol - 股票代码, 如"600030"; start_date - 开始日期; end_date - 结束日期

输出: 证券简称, 配股价格, 配股比例, 实际配股数量, 实际募资总额, 股权登记日, 配股上市日, 公告日期 等

```python
df = ak.stock_allotment_cninfo(symbol="600030", start_date="19900101", end_date="20241022")
```

## stock_ggcg_em

描述: 东方财富网-高管持股-股东增减持

输入: symbol - 类型, 全部/股东增持/股东减持

输出: 代码, 名称, 最新价, 涨跌幅, 股东名称, 持股变动信息-增减, 持股变动信息-变动数量, 持股变动信息-占总股本比例, 变动开始日, 变动截止日, 公告日

```python
df = ak.stock_ggcg_em(symbol="全部")
```

## stock_fhps_em

描述: 东方财富-分红配送

输入: date - 报告期, 如"20231231"; 仅支持XXXX0630或XXXX1231格式

输出: 代码, 名称, 送转股份-送转总比例, 送转股份-送转比例, 送转股份-转股比例, 现金分红-现金分红比例, 现金分红-股息率, 每股收益, 每股净资产, 每股公积金, 每股未分配利润, 净利润同比增长, 总股本, 预案公告日, 股权登记日, 除权除息日, 方案进度, 最新公告日期

```python
df = ak.stock_fhps_em(date="20231231")
```

## stock_fhps_detail_em

描述: 东方财富-分红送配详情

输入: symbol - 股票代码, 如"300073"

输出: 报告期, 业绩披露日期, 送转股份-送转总比例, 送转股份-送股比例, 送转股份-转股比例, 现金分红-现金分红比例, 现金分红-股息率, 每股收益, 每股净资产, 每股公积金, 每股未分配利润, 净利润同比增长, 总股本, 预案公告日, 股权登记日, 除权除息日, 方案进度, 最新公告日期

```python
df = ak.stock_fhps_detail_em(symbol="300073")
```

## stock_hk_fhpx_detail_ths

描述: 同花顺-港股分红派息

输入: symbol - 港股代码, 如"0700"

输出: 公告日期, 方案, 除净日, 派息日, 过户日期起止日-起始, 过户日期起止日-截止, 类型, 进度, 以股代息

```python
df = ak.stock_hk_fhpx_detail_ths(symbol="0700")
```

## stock_history_dividend

描述: 新浪财经-所有股票历史分红汇总

输入: 无

输出: 代码, 名称, 上市日期, 累计股息, 年均股息, 分红次数, 融资总额, 融资次数

```python
df = ak.stock_history_dividend()
```

## stock_history_dividend_detail

描述: 新浪财经-个股分红配股详情

输入: symbol - 股票代码, 如"600012"; indicator - 类型, 分红/配股; date - 可选, 指定日期获取详情

输出(分红): 公告日期, 送股, 转增, 派息, 进度, 除权除息日, 股权登记日, 红股上市日

输出(配股): 公告日期, 配股方案, 配股价格, 基准股本, 除权日, 股权登记日, 缴款起始日, 缴款终止日, 配股上市日, 募集资金合计

输出(指定日期): item, value

```python
df = ak.stock_history_dividend_detail(symbol="600012", indicator="分红")
df = ak.stock_history_dividend_detail(symbol="000002", indicator="配股")
df = ak.stock_history_dividend_detail(symbol="600012", indicator="分红", date="2019-07-08")
```

## stock_dividend_cninfo

描述: 巨潮资讯-个股历史分红

输入: symbol - 股票代码, 如"600009"

输出: 实施方案公告日期, 送股比例, 转增比例, 派息比例, 股权登记日, 除权日, 派息日, 股份到账日, 实施方案分红说明, 分红类型, 报告时间

```python
df = ak.stock_dividend_cninfo(symbol="600009")
```

## stock_ipo_info

描述: 新浪财经-新股发行基本信息

输入: stock - 股票代码, 如"600004"

输出: item, value

```python
df = ak.stock_ipo_info(stock="600004")
```

## stock_ipo_review_em

描述: 东方财富网-新股上会信息

输入: 无

输出: 序号, 企业名称, 股票简称, 股票代码, 上市板块, 上会日期, 审核状态, 发审委委员, 主承销商, 发行数量(股), 拟融资额(元), 公告日期, 上市日期

```python
df = ak.stock_ipo_review_em()
```

## stock_ipo_tutor_em

描述: 东方财富网-IPO辅导信息

输入: 无

输出: 序号, 企业名称, 辅导机构, 辅导状态, 报告类型, 派出机构, 备案日期

```python
df = ak.stock_ipo_tutor_em()
```

## stock_add_stock

描述: 新浪财经-股票增发详情

输入: symbol - 股票代码, 如"600004"

输出: 公告日期, 发行方式, 发行价格, 实际公司募集资金总额, 发行费用总额, 实际发行数量

```python
df = ak.stock_add_stock(symbol="600004")
```

## stock_restricted_release_queue_sina

描述: 新浪财经-个股限售解禁

输入: symbol - 股票代码, 如"600000"

输出: 代码, 名称, 解禁日期, 解禁数量, 解禁股流通市值, 上市批次, 公告日期

```python
df = ak.stock_restricted_release_queue_sina(symbol="600000")
```

## stock_restricted_release_queue_em

描述: 东方财富网-个股限售解禁-解禁批次

输入: symbol - 股票代码, 如"600000"

输出: 序号, 解禁时间, 解禁股东数, 解禁数量, 实际解禁数量, 未解禁数量, 实际解禁数量市值, 占总市值比例, 占流通市值比例, 解禁前一交易日收盘价, 限售股类型, 解禁前20日涨跌幅, 解禁后20日涨跌幅

```python
df = ak.stock_restricted_release_queue_em(symbol="600000")
```

## stock_restricted_release_stockholder_em

描述: 东方财富网-个股限售解禁-解禁股东

输入: symbol - 股票代码, 如"600000"; date - 解禁日期, 通过stock_restricted_release_queue_em获取

输出: 序号, 股东名称, 解禁数量, 实际解禁数量, 解禁市值, 锁定期, 剩余未解禁数量, 限售股类型, 进度

```python
df = ak.stock_restricted_release_stockholder_em(symbol="600000", date="20200904")
```

## stock_new_ipo_cninfo

描述: 巨潮资讯-新股发行数据(近三年)

输入: 无

输出: 证劵代码, 证券简称, 上市日期, 申购日期, 发行价, 总发行数量, 发行市盈率, 上网发行中签率, 摇号结果公告日, 中签公告日, 中签缴款日, 网上申购上限, 上网发行数量

```python
df = ak.stock_new_ipo_cninfo()
```

## stock_ipo_declare_em

描述: 东方财富网-首发申报企业信息

输入: 无

输出: 序号, 企业名称, 最新状态, 注册地, 保荐机构, 律师事务所, 会计师事务所, 拟上市地点, 更新日期, 招股说明书

```python
df = ak.stock_ipo_declare_em()
```

## stock_register_all_em

描述: 东方财富网-IPO审核信息-全部

输入: 无

输出: 序号, 企业名称, 最新状态, 注册地, 行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书

```python
df = ak.stock_register_all_em()
```

## stock_register_kcb

描述: 东方财富网-IPO审核信息-科创板

输入: 无

输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书

```python
df = ak.stock_register_kcb()
```

## stock_register_cyb

描述: 东方财富网-IPO审核信息-创业板

输入: 无

输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书

```python
df = ak.stock_register_cyb()
```

## stock_register_sh

描述: 东方财富网-IPO审核信息-上海主板

输入: 无

输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书

```python
df = ak.stock_register_sh()
```

## stock_register_sz

描述: 东方财富网-IPO审核信息-深圳主板

输入: 无

输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书

```python
df = ak.stock_register_sz()
```

## stock_register_bj

描述: 东方财富网-IPO审核信息-北交所

输入: 无

输出: 序号, 发行人全称, 审核状态, 注册地, 证监会行业, 保荐机构, 律师事务所, 会计师事务所, 更新日期, 受理日期, 拟上市地点, 招股说明书

```python
df = ak.stock_register_bj()
```

## stock_qbzf_em

描述: 东方财富网-全部增发数据

输入: 无

输出: 股票代码, 股票简称, 增发代码, 发行方式, 发行总数, 网上发行, 发行价格, 最新价, 发行日期, 增发上市日期, 锁定期

```python
df = ak.stock_qbzf_em()
```

## stock_pg_em

描述: 东方财富网-配股数据

输入: 无

输出: 股票代码, 股票简称, 配售代码, 配股数量, 配股比例, 配股价, 最新价, 配股前总股本, 配股后总股本, 股权登记日, 缴款起始日期, 缴款截止日期, 上市日

```python
df = ak.stock_pg_em()
```

## stock_repurchase_em

描述: 东方财富网-股票回购数据

输入: 无

输出: 序号, 股票代码, 股票简称, 最新价, 计划回购价格区间, 计划回购数量区间-下限, 计划回购数量区间-上限, 占公告前一日总股本比例-下限, 占公告前一日总股本比例-上限, 计划回购金额区间-下限, 计划回购金额区间-上限, 回购起始时间, 实施进度, 已回购股份数量, 已回购金额, 最新公告日期

```python
df = ak.stock_repurchase_em()
```

## stock_zh_a_gbjg_em

描述: 东方财富-A股股本结构

输入: symbol - 带后缀股票代码, 如"603392.SH"

输出: 变更日期, 总股本, 流通受限股份, 其他内资持股(受限), 境内法人持股(受限), 境内自然人持股(受限), 已流通股份, 已上市流通A股, 变动原因

```python
df = ak.stock_zh_a_gbjg_em(symbol="603392.SH")
```
