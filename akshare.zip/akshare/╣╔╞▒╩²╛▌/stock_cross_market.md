# 跨市场股票数据

```python
import akshare as ak
```

## stock_szse_summary

描述: 深圳证券交易所-市场总貌-证券类别统计
输入: date - 日期字符串，如"20200619"
输出: 证券类别, 数量, 成交金额, 总市值, 流通市值

```python
df = ak.stock_szse_summary(date="20200619")
```

## stock_zh_ab_comparison_em

描述: 东方财富网-AB股比价-全部AB股比价
输入: 无
输出: 序号, B股代码, B股名称, 最新价B, 涨跌幅B, A股代码, A股名称, 最新价A, 涨跌幅A, 比价

```python
df = ak.stock_zh_ab_comparison_em()
```

## stock_individual_spot_xq

描述: 雪球-行情中心-个股实时行情
输入: symbol - 证券代码如"SH600000"; token - 默认None; timeout - 默认None
输出: item, value

```python
df = ak.stock_individual_spot_xq(symbol="SH600000")
```

## stock_zh_scale_comparison_em

描述: 东方财富-同行比较-公司规模
输入: symbol - 股票代码如"SZ000895"
输出: 代码, 简称, 总市值, 总市值排名, 流通市值, 流通市值排名, 营业收入, 营业收入排名, 净利润, 净利润排名

```python
df = ak.stock_zh_scale_comparison_em(symbol="SZ000895")
```

## stock_zh_a_cdr_daily

描述: 上海证券交易所-科创板-CDR历史行情
输入: symbol - CDR代码如'sh689009'; start_date - 如'20201103'; end_date - 如'20201116'
输出: date, open, high, low, close, volume

```python
df = ak.stock_zh_a_cdr_daily(symbol='sh689009', start_date='20201103', end_date='20201116')
```

## stock_zh_b_spot

描述: 新浪财经-B股实时行情(频繁调用会被封IP)
输入: 无
输出: 代码, 名称, 最新价, 涨跌额, 涨跌幅, 买入, 卖出, 昨收, 今开, 最高, 最低, 成交量, 成交额

```python
df = ak.stock_zh_b_spot()
```

## stock_zh_kcb_report_em

描述: 东方财富-科创板公告报告数据
输入: from_page - 起始页码; to_page - 结束页码
输出: 代码, 名称, 公告标题, 公告类型, 公告日期, 公告代码

```python
df = ak.stock_zh_kcb_report_em(from_page=1, to_page=100)
```

## stock_zh_ah_spot

描述: 腾讯财经-A+H股实时行情(延迟15分钟)
输入: 无
输出: 代码, 名称, 最新价, 涨跌幅, 涨跌额, 买入, 卖出, 成交量, 成交额, 今开, 昨收, 最高, 最低

```python
df = ak.stock_zh_ah_spot()
```

## stock_zh_ah_daily

描述: 腾讯财经-A+H股历史行情
输入: symbol - 港股代码如"02318"; start_year - 开始年份; end_year - 结束年份; adjust - 复权方式: ""不复权,"qfq"前复权,"hfq"后复权
输出: 日期, 开盘, 收盘, 最高, 最低, 成交量

```python
df = ak.stock_zh_ah_daily(symbol="02318", start_year="2022", end_year="2024", adjust="")
```

## stock_zh_ah_name

描述: A+H股代码和名称字典
输入: 无
输出: 代码, 名称

```python
df = ak.stock_zh_ah_name()
```

## stock_us_spot_em

描述: 东方财富网-美股实时行情
输入: 无
输出: 序号, 名称, 最新价, 涨跌额, 涨跌幅, 开盘价, 最高价, 最低价, 昨收价, 总市值, 市盈率, 成交量, 成交额, 振幅, 换手率, 代码

```python
df = ak.stock_us_spot_em()
```

## stock_us_spot

描述: 新浪财经-美股实时行情(15分钟延迟,建议用stock_us_spot_em)
输入: 无
输出: 新浪默认字段(name, cname, symbol, price, diff, chg等)

```python
df = ak.stock_us_spot()
```

## stock_us_hist

描述: 东方财富网-美股每日历史行情
输入: symbol - 美股代码如'106.TTE'; period - 'daily'/'weekly'/'monthly'; start_date - 如"20210101"; end_date - 如"20210601"; adjust - ""/"qfq"/"hfq"
输出: 日期, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 振幅, 涨跌幅, 涨跌额, 换手率

```python
df = ak.stock_us_hist(symbol='106.TTE', period="daily", start_date="20200101", end_date="20240214", adjust="qfq")
```

## stock_us_hist_min_em

描述: 东方财富网-美股每日分时行情(最近5个交易日)
输入: symbol - 美股代码如"105.ATER"; start_date - 日期时间; end_date - 日期时间
输出: 时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 最新价

```python
df = ak.stock_us_hist_min_em(symbol="105.ATER")
```

## stock_us_daily

描述: 新浪财经-美股历史行情(含复权因子)
输入: symbol - 美股代码如"AAPL"; adjust - ""不复权/"qfq"前复权/"qfq-factor"前复权因子
输出: date, open, high, low, close, volume(复权因子模式: date, qfq_factor, adjust)

```python
df = ak.stock_us_daily(symbol="AAPL", adjust="")
```

## stock_us_pink_spot_em

描述: 美股粉单市场实时行情
输入: 无
输出: 序号, 名称, 最新价, 涨跌额, 涨跌幅, 开盘价, 最高价, 最低价, 昨收价, 总市值, 市盈率, 代码

```python
df = ak.stock_us_pink_spot_em()
```

## stock_us_famous_spot_em

描述: 美股知名美股实时行情
输入: symbol - '科技类'/'金融类'/'医药食品类'/'媒体类'/'汽车能源类'/'制造零售类'
输出: 序号, 名称, 最新价, 涨跌额, 涨跌幅, 开盘价, 最高价, 最低价, 昨收价, 总市值, 市盈率, 代码

```python
df = ak.stock_us_famous_spot_em(symbol='科技类')
```

## stock_hk_spot_em

描述: 东方财富网-所有港股实时行情(15分钟延时)
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 今开, 最高, 最低, 昨收, 成交量, 成交额

```python
df = ak.stock_hk_spot_em()
```

## stock_hk_main_board_spot_em

描述: 东方财富网-港股主板实时行情(15分钟延时)
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 今开, 最高, 最低, 昨收, 成交量, 成交额

```python
df = ak.stock_hk_main_board_spot_em()
```

## stock_hk_spot

描述: 新浪财经-港股实时行情(15分钟延时)
输入: 无
输出: 日期时间, 代码, 中文名称, 英文名称, 交易类型, 最新价, 涨跌额, 涨跌幅, 昨收, 今开, 最高, 最低, 成交量, 成交额, 买一, 卖一

```python
df = ak.stock_hk_spot()
```

## stock_hk_hist_min_em

描述: 东方财富网-港股分时行情(最近5个交易日)
输入: symbol - 港股代码如"01611"; period - '1'/'5'/'15'/'30'/'60'; adjust - ''/'qfq'/'hfq'; start_date - 日期时间; end_date - 日期时间
输出: 1分钟: 时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 最新价; 其他: 时间, 开盘, 收盘, 最高, 最低, 涨跌幅, 涨跌额, 成交量, 成交额, 振幅, 换手率

```python
df = ak.stock_hk_hist_min_em(symbol="01611", period='5', adjust='hfq', start_date="2021-09-01 09:32:00", end_date="2021-09-07 18:32:00")
```

## stock_hk_hist

描述: 东方财富网-港股历史行情(支持复权)
输入: symbol - 港股代码如"00593"; period - 'daily'/'weekly'/'monthly'; start_date - 如"19700101"; end_date - 如"22220101"; adjust - ""/"qfq"/"hfq"
输出: 日期, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 振幅, 涨跌幅, 涨跌额, 换手率

```python
df = ak.stock_hk_hist(symbol="00593", period="daily", start_date="19700101", end_date="22220101", adjust="")
```

## stock_hk_daily

描述: 新浪财经-港股历史行情(含复权因子)
输入: symbol - 港股代码如"00700"; adjust - ""/"qfq"/"hfq"/"qfq-factor"/"hfq-factor"
输出: date, open, high, low, close, volume(复权因子模式: date, hfq_factor/qfq_factor, cash/adjust)

```python
df = ak.stock_hk_daily(symbol="00700", adjust="hfq")
```

## stock_hk_famous_spot_em

描述: 东方财富网-知名港股实时行情
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 今开, 最高, 最低, 昨收, 成交量, 成交额

```python
df = ak.stock_hk_famous_spot_em()
```

## stock_hk_security_profile_em

描述: 东方财富-港股-证券资料
输入: symbol - 港股代码如"03900"
输出: 证券代码, 证券简称, 上市日期, 证券类型, 发行价, 发行量(股), 每手股数, 每股面值, 交易所, 板块, 年结日, ISIN, 是否沪港通标的, 是否深港通标的

```python
df = ak.stock_hk_security_profile_em(symbol="03900")
```

## stock_hk_company_profile_em

描述: 东方财富-港股-公司资料
输入: symbol - 港股代码如"03900"
输出: 公司名称, 英文名称, 注册地, 公司成立日期, 所属行业, 董事长, 公司秘书, 员工人数, 办公地址, 公司网址, E-MAIL, 年结日, 联系电话, 核数师, 传真, 公司介绍

```python
df = ak.stock_hk_company_profile_em(symbol="03900")
```

## stock_hk_financial_indicator_em

描述: 东方财富-港股-核心必读-最新指标
输入: symbol - 港股代码如"03900"
输出: 基本每股收益, 每股净资产, 法定股本, 每手股, 每股股息TTM, 派息比率, 已发行股本, 已发行股本-H股, 每股经营现金流, 股息率TTM, 总市值, 港股市值, 营业总收入, 营业总收入滚动环比增长, 销售净利率, 净利润, 净利润滚动环比增长, 股东权益回报率, 市盈率, 市净率, 总资产回报率

```python
df = ak.stock_hk_financial_indicator_em(symbol="03900")
```

## stock_hk_dividend_payout_em

描述: 东方财富-港股-核心必读-分红派息
输入: symbol - 港股代码如"03900"
输出: 最新公告日期, 财政年度, 分红方案, 分配类型, 除净日, 截至过户日, 发放日

```python
df = ak.stock_hk_dividend_payout_em(symbol="03900")
```

## stock_hk_growth_comparison_em

描述: 东方财富-港股-行业对比-成长性对比
输入: symbol - 港股代码如"03900"
输出: 代码, 简称, 基本每股收益同比增长率, 基本每股收益同比增长率排名, 营业收入同比增长率, 营业收入同比增长率排名, 营业利润率同比增长率, 营业利润率同比增长率排名, 总资产同比增长率, 总资产同比增长率排名

```python
df = ak.stock_hk_growth_comparison_em(symbol="03900")
```

## stock_hk_valuation_comparison_em

描述: 东方财富-港股-行业对比-估值对比
输入: symbol - 港股代码如"03900"
输出: 代码, 简称, 市盈率-TTM, 市盈率-TTM排名, 市盈率-LYR, 市盈率-LYR排名, 市净率-MRQ, 市净率-MRQ排名, 市净率-LYR, 市净率-LYR排名, 市销率-TTM, 市销率-TTM排名, 市销率-LYR, 市销率-LYR排名, 市现率-TTM, 市现率-TTM排名, 市现率-LYR, 市现率-LYR排名

```python
df = ak.stock_hk_valuation_comparison_em(symbol="03900")
```

## stock_hk_scale_comparison_em

描述: 东方财富-港股-行业对比-规模对比
输入: symbol - 港股代码如"03900"
输出: 代码, 简称, 总市值, 总市值排名, 流通市值, 流通市值排名, 营业总收入, 营业总收入排名, 净利润, 净利润排名

```python
df = ak.stock_hk_scale_comparison_em(symbol="03900")
```

## stock_account_statistics_em

描述: 东方财富网-股票账户统计月度数据
输入: 无
输出: 数据日期, 新增投资者-数量, 新增投资者-环比, 新增投资者-同比, 期末投资者-总量, 期末投资者-A股账户, 期末投资者-B股账户, 沪深总市值, 沪深户均市值, 上证指数-收盘, 上证指数-涨跌幅

```python
df = ak.stock_account_statistics_em()
```

## stock_hsgt_fund_flow_summary_em

描述: 东方财富网-沪深港通资金流向汇总
输入: 无
输出: 交易日, 类型, 板块, 资金方向, 交易状态, 成交净买额, 资金净流入, 当日资金余额, 上涨数, 持平数, 下跌数, 相关指数, 指数涨跌幅

```python
df = ak.stock_hsgt_fund_flow_summary_em()
```

## stock_sgt_settlement_exchange_rate_szse

描述: 深港通-港股通业务信息-结算汇率
输入: 无
输出: 适用日期, 买入结算汇兑比率, 卖出结算汇兑比率, 货币种类

```python
df = ak.stock_sgt_settlement_exchange_rate_szse()
```

## stock_sgt_settlement_exchange_rate_sse

描述: 沪港通-港股通信息披露-结算汇兑比率
输入: 无
输出: 适用日期, 买入结算汇兑比率, 卖出结算汇兑比率, 货币种类

```python
df = ak.stock_sgt_settlement_exchange_rate_sse()
```

## stock_sgt_reference_exchange_rate_szse

描述: 深港通-港股通业务信息-参考汇率
输入: 无
输出: 适用日期, 参考汇率买入价, 参考汇率卖出价, 货币种类

```python
df = ak.stock_sgt_reference_exchange_rate_szse()
```

## stock_sgt_reference_exchange_rate_sse

描述: 沪港通-港股通信息披露-参考汇率
输入: 无
输出: 适用日期, 参考汇率买入价, 参考汇率卖出价, 货币种类

```python
df = ak.stock_sgt_reference_exchange_rate_sse()
```

## stock_hk_ggt_components_em

描述: 东方财富网-港股通成份股
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 今开, 最高, 最低, 昨收, 成交量, 成交额

```python
df = ak.stock_hk_ggt_components_em()
```

## stock_hsgt_fund_min_em

描述: 东方财富-沪深港通市场概括-分时数据(20240513起数据源不再提供)
输入: symbol - "北向资金"/"南向资金"
输出: 北向: 日期, 时间, 沪股通, 深股通, 北向资金; 南向: 日期, 时间, 港股通(沪), 港股通(深), 南向资金

```python
df = ak.stock_hsgt_fund_min_em(symbol="北向资金")
```

## stock_hsgt_sh_hk_spot_em

描述: 东方财富网-沪深港通-港股通(沪>港)实时行情
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 今开, 最高, 最低, 昨收, 成交量, 成交额

```python
df = ak.stock_hsgt_sh_hk_spot_em()
```

## stock_hsgt_hist_em

描述: 东方财富网-沪深港通历史数据
输入: symbol - "北向资金"/"沪股通"/"深股通"/"南向资金"/"港股通沪"/"港股通深"
输出: 日期, 当日成交净买额, 买入成交额, 卖出成交额, 历史累计净买额, 当日资金流入, 当日余额, 持股市值, 领涨股, 领涨股-涨跌幅, 相关指数, 相关指数-涨跌幅, 领涨股-代码

```python
df = ak.stock_hsgt_hist_em(symbol="北向资金")
```

## stock_hsgt_individual_em

描述: 东方财富网-沪深港通持股-具体股票(截至20240816)
输入: symbol - 股票代码如"002008"(支持港股和A股)
输出: A股: 持股日期, 当日收盘价, 当日涨跌幅, 持股数量, 持股市值, 持股数量占A股百分比, 今日增持股数, 今日增持资金, 今日持股市值变化; 港股: 持股日期, 当日收盘价, 当日涨跌幅, 持股数量, 持股市值, 持股数量占A股百分比, 持股市值变化-1日/5日/10日

```python
df = ak.stock_hsgt_individual_em(symbol="002008")
```

## news_trade_notify_suspend_baidu

描述: 百度股市通-交易提醒-停复牌(含港股)
输入: date - 日期如"20241107"
输出: 股票代码, 股票简称, 交易所, 停牌时间, 复牌时间, 停牌事项说明

```python
df = ak.news_trade_notify_suspend_baidu(date="20241107")
```

## news_trade_notify_dividend_baidu

描述: 百度股市通-交易提醒-分红派息(含港股)
输入: date - 日期如"20241107"; cookie - 可选cookie
输出: 股票代码, 除权日, 分红, 送股, 转增, 实物, 交易所, 股票简称, 报告期

```python
df = ak.news_trade_notify_dividend_baidu(date="20251126")
```

## news_report_time_baidu

描述: 百度股市通-财报发行(含港股)
输入: date - 日期如"20241107"
输出: 股票代码, 交易所, 股票简称, 财报期

```python
df = ak.news_report_time_baidu(date="20241107")
```

## stock_ipo_hk_ths

描述: 同花顺-新股申购与中签-港股
输入: 无
输出: 股票代码, 股票简称, 申购代码, 发行总数(万股), 网上发行(万股), 申购上限(万股), 顶格申购需配市值(万元), 发行价格, 发行市盈率, 行业市盈率, 申购日期, 中签率(%), 中签号, 中签缴款日期, 上市日期, 打新收益(元), 首日最高涨幅, 连板天数

```python
df = ak.stock_ipo_hk_ths()
```

## stock_zh_a_disclosure_report_cninfo

描述: 巨潮资讯-信息披露公告-沪深京
输入: symbol - 股票代码如"000001"; market - "沪深京"/"港股"/"三板"/"基金"/"债券"/"监管"/"预披露"; keyword - 关键词; category - 公告类别如"年报"/"半年报"等; start_date - 如"20230618"; end_date - 如"20231219"
输出: 代码, 简称, 公告标题, 公告时间, 公告链接

```python
df = ak.stock_zh_a_disclosure_report_cninfo(symbol="000001", market="沪深京", category="公司治理", start_date="20230619", end_date="20231220")
```

## stock_zh_a_disclosure_relation_cninfo

描述: 巨潮资讯-信息披露调研-沪深京
输入: symbol - 股票代码如"000001"; market - "沪深京"/"港股"/"三板"/"基金"/"债券"/"监管"/"预披露"; start_date - 如"20230618"; end_date - 如"20231219"
输出: 代码, 简称, 公告标题, 公告时间, 公告链接

```python
df = ak.stock_zh_a_disclosure_relation_cninfo(symbol="000001", market="沪深京", start_date="20230619", end_date="20231220")
```

## stock_share_change_cninfo

描述: 巨潮资讯-公司股本变动
输入: symbol - 股票代码如"002594"; start_date - 如"20091227"; end_date - 如"20241021"
输出: 证券简称, 机构名称, 境外法人持股, 证券投资基金持股, 国家持股-受限, 国有法人持股, 总股本, 变动原因, 公告日期, 证券代码, 变动日期等

```python
df = ak.stock_share_change_cninfo(symbol="002594", start_date="20091227", end_date="20241021")
```

## stock_profile_cninfo

描述: 巨潮资讯-个股-公司概况
输入: symbol - 股票代码如"600030"
输出: 公司名称, 英文名称, 曾用简称, A股代码, A股简称, B股代码, B股简称, H股代码, H股简称, 入选指数, 所属市场, 所属行业, 法人代表, 注册资金, 成立日期, 上市日期, 官方网站, 电子邮箱, 联系电话, 传真, 注册地址, 办公地址, 邮政编码, 主营业务, 经营范围, 机构简介

```python
df = ak.stock_profile_cninfo(symbol="600030")
```

## stock_hk_fhpx_detail_ths

描述: 同花顺-港股-分红派息详情
输入: symbol - 港股代码如"0700"
输出: 公告日期, 方案, 除净日, 派息日, 过户日期起止日-起始, 过户日期起止日-截止, 类型, 进度, 以股代息

```python
df = ak.stock_hk_fhpx_detail_ths(symbol="0700")
```

## stock_main_fund_flow

描述: 东方财富网-主力净流入排名
输入: symbol - "全部股票"/"沪深A股"/"沪市A股"/"科创板"/"深市A股"/"创业板"/"沪市B股"/"深市B股"
输出: 序号, 代码, 名称, 最新价, 今日排行榜-主力净占比, 今日排行榜-今日排名, 今日排行榜-今日涨跌, 5日排行榜-主力净占比, 5日排行榜-5日排名, 5日排行榜-5日涨跌, 10日排行榜-主力净占比, 10日排行榜-10日排名, 10日排行榜-10日涨跌, 所属板块

```python
df = ak.stock_main_fund_flow(symbol="全部股票")
```

## stock_financial_hk_report_em

描述: 东方财富-港股-财务报表-三大报表
输入: stock - 港股代码如"00700"; symbol - "资产负债表"/"利润表"/"现金流量表"; indicator - "年度"/"报告期"
输出: SECUCODE, SECURITY_CODE, SECURITY_NAME_ABBR, ORG_CODE, REPORT_DATE, DATE_TYPE_CODE, FISCAL_YEAR, STD_ITEM_CODE, STD_ITEM_NAME, AMOUNT, STD_REPORT_DATE

```python
df = ak.stock_financial_hk_report_em(stock="00700", symbol="资产负债表", indicator="年度")
```

## stock_financial_us_report_em

描述: 东方财富-美股-财务分析-三大报表
输入: stock - 美股代码如"TSLA"(BRK.A需用BRK_A); symbol - "资产负债表"/"综合损益表"/"现金流量表"; indicator - "年报"/"单季报"/"累计季报"
输出: SECUCODE, SECURITY_CODE, SECURITY_NAME_ABBR, REPORT_DATE, REPORT_TYPE, REPORT, STD_ITEM_CODE, AMOUNT, ITEM_NAME

```python
df = ak.stock_financial_us_report_em(stock="TSLA", symbol="资产负债表", indicator="年报")
```

## stock_financial_hk_analysis_indicator_em

描述: 东方财富-港股-财务分析-主要指标
输入: symbol - 港股代码如"00700"; indicator - "年度"/"报告期"
输出: SECUCODE, SECURITY_CODE, SECURITY_NAME_ABBR, REPORT_DATE, PER_NETCASH_OPERATE, PER_OI, BPS, BASIC_EPS, DILUTED_EPS, OPERATE_INCOME, OPERATE_INCOME_YOY, GROSS_PROFIT, GROSS_PROFIT_YOY, HOLDER_PROFIT, HOLDER_PROFIT_YOY, GROSS_PROFIT_RATIO, EPS_TTM, NET_PROFIT_RATIO, ROE_AVG, ROA, DEBT_ASSET_RATIO, CURRENT_RATIO等

```python
df = ak.stock_financial_hk_analysis_indicator_em(symbol="00700", indicator="年度")
```

## stock_financial_us_analysis_indicator_em

描述: 东方财富-美股-财务分析-主要指标
输入: symbol - 美股代码如"TSLA"; indicator - "年报"/"单季报"/"累计季报"
输出: SECUCODE, SECURITY_CODE, SECURITY_NAME_ABBR, REPORT_DATE, OPERATE_INCOME, OPERATE_INCOME_YOY, GROSS_PROFIT, GROSS_PROFIT_YOY, PARENT_HOLDER_NETPROFIT, PARENT_HOLDER_NETPROFIT_YOY, BASIC_EPS, DILUTED_EPS, GROSS_PROFIT_RATIO, NET_PROFIT_RATIO, ROE_AVG, ROA, CURRENT_RATIO, SPEED_RATIO, DEBT_ASSET_RATIO, EQUITY_RATIO等

```python
df = ak.stock_financial_us_analysis_indicator_em(symbol="TSLA", indicator="年报")
```

## stock_info_sh_name_code

描述: 上海证券交易所股票代码和简称
输入: symbol - "主板A股"/"主板B股"/"科创板"
输出: 证券代码, 证券简称, 公司全称, 上市日期

```python
df = ak.stock_info_sh_name_code(symbol="主板A股")
```

## stock_info_sz_name_code

描述: 深证证券交易所股票代码和简称
输入: symbol - "A股列表"/"B股列表"/"CDR列表"/"AB股列表"
输出: 板块, A股代码, A股简称, A股上市日期, A股总股本, A股流通股本, 所属行业

```python
df = ak.stock_info_sz_name_code(symbol="A股列表")
```

## stock_buffett_index_lg

描述: 乐估乐股-巴菲特指标
输入: 无
输出: 日期, 收盘价, 总市值, GDP

```python
df = ak.stock_buffett_index_lg()
```

## stock_hk_indicator_eniu

描述: 亿牛网-港股个股指标: 市盈率/市净率/股息率/ROE/市值(数据源暂未更新)
输入: symbol - 港股代码如"hk01093"; indicator - "港股"/"市盈率"/"市净率"/"股息率"/"ROE"/"市值"
输出: 根据indicator而异(通常含date和对应指标值)

```python
df = ak.stock_hk_indicator_eniu(symbol="hk01093", indicator="市净率")
```

## stock_hk_valuation_baidu

描述: 百度股市通-港股-估值数据
输入: symbol - 港股代码如"02358"; indicator - "总市值"/"市盈率(TTM)"/"市盈率(静)"/"市净率"/"市现率"; period - "近一年"/"近三年"/"全部"
输出: date, value

```python
df = ak.stock_hk_valuation_baidu(symbol="06969", indicator="总市值", period="近一年")
```

## stock_us_valuation_baidu

描述: 百度股市通-美股-估值数据
输入: symbol - 美股代码如"NVDA"; indicator - "总市值"/"市盈率(TTM)"/"市盈率(静)"/"市净率"/"市现率"; period - "近一年"/"近三年"/"全部"
输出: date, value

```python
df = ak.stock_us_valuation_baidu(symbol="NVDA", indicator="总市值", period="近一年")
```

## stock_dzjy_mrmx

描述: 东方财富网-大宗交易-每日明细
输入: symbol - 'A股'/'B股'/'基金'/'债券'; start_date - 如'20220104'; end_date - 如'20220104'
输出: A股: 序号, 交易日期, 证券代码, 证券简称, 涨跌幅, 收盘价, 成交价, 折溢率, 成交量, 成交额, 成交额/流通市值, 买方营业部, 卖方营业部; 其他: 序号, 交易日期, 证券代码, 证券简称, 成交价, 成交量, 成交额, 买方营业部, 卖方营业部

```python
df = ak.stock_dzjy_mrmx(symbol='A股', start_date='20220104', end_date='20220104')
```

## stock_dzjy_hyyybtj

描述: 东方财富网-大宗交易-活跃营业部统计
输入: symbol - '当前交易日'/'近3日'/'近5日'/'近10日'/'近30日'
输出: 序号, 营业部名称, 最近上榜日, 次数总计-买入, 次数总计-卖出, 成交金额统计-买入, 成交金额统计-卖出, 成交金额统计-净买入额, 买入的股票

```python
df = ak.stock_dzjy_hyyybtj(symbol='近3日')
```

## stock_hk_profit_forecast_et

描述: 经济通-公司资料-盈利预测
输入: symbol - 港股代码如"09999"; indicator - "评级总览"/"去年度业绩表现"/"综合盈利预测"/"盈利预测概览"
输出: 盈利预测概览: 财政年度, 纯利/亏损, 每股盈利, 每股派息, 证券商, 评级, 目标价, 更新日期

```python
df = ak.stock_hk_profit_forecast_et(symbol="09999", indicator="盈利预测概览")
```

## stock_concept_cons_futu

描述: 富途牛牛-主题投资-概念板块-成分股
输入: symbol - "巴菲特持仓"/"佩洛西持仓"/"特朗普概念股"
输出: 代码, 股票名称, 最新价, 涨跌额, 涨跌幅, 成交量, 成交额

```python
df = ak.stock_concept_cons_futu(symbol="特朗普概念股")
```

## stock_hk_hot_rank_em

描述: 东方财富-个股人气榜-港股市场(前100名)
输入: 无
输出: 当前排名, 代码, 股票名称, 最新价, 涨跌幅

```python
df = ak.stock_hk_hot_rank_em()
```

## stock_hk_hot_rank_detail_em

描述: 东方财富网-港股股票热度-历史趋势
输入: symbol - 港股代码如"00700"
输出: 时间, 排名, 证券代码

```python
df = ak.stock_hk_hot_rank_detail_em(symbol="00700")
```

## stock_hk_hot_rank_detail_realtime_em

描述: 东方财富网-个股人气榜-实时变动(港股)
输入: symbol - 港股代码如"00700"
输出: 时间, 排名

```python
df = ak.stock_hk_hot_rank_detail_realtime_em(symbol="00700")
```

## stock_hk_hot_rank_latest_em

描述: 东方财富-个股人气榜-最新排名(港股)
输入: symbol - 港股代码如"00700"
输出: item, value

```python
df = ak.stock_hk_hot_rank_latest_em(symbol="00700")
```

## stock_hot_search_baidu

描述: 百度股市通-热搜股票
输入: symbol - "全部"/"A股"/"港股"/"美股"; date - 日期如"20250616"; time - "今日"/"1小时"
输出: 名称/代码, 涨跌幅, 综合热度

```python
df = ak.stock_hot_search_baidu(symbol="A股", date="20250616", time="今日")
```

## stock_info_global_ths

描述: 同花顺财经-全球财经直播(最近20条)
输入: 无
输出: 标题, 内容, 发布时间, 链接

```python
df = ak.stock_info_global_ths()
```
