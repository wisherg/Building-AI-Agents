# 期权数据

```python
import akshare as ak
```

## option_contract_info_ctp
描述: openctp 期权合约信息
输入: 无
输出: 交易所ID, 合约ID, 合约名称, 商品类别, 品种ID, 合约乘数, 最小变动价位, 做多保证金率, 做空保证金率, 做多保证金/手, 做空保证金/手, 开仓手续费率, 开仓手续费/手, 平仓手续费率, 平仓手续费/手, 平今手续费率, 平今手续费/手, 交割年份, 交割月份, 上市日期, 最后交易日, 交割日, 标的合约ID, 标的合约乘数, 期权类型, 行权价, 合约状态
```python
option_contract_info_ctp_df = ak.option_contract_info_ctp()
```

## option_finance_board
描述: 上交所/深交所/中金所金融期权行情数据
输入: symbol - 合约名称如"华夏上证50ETF期权"; end_month - 合约到期月份如"2212"
输出: 日期, 合约交易代码, 当前价, 涨跌幅, 前结价, 行权价, 数量
```python
option_finance_board_df = ak.option_finance_board(symbol="华夏上证50ETF期权", end_month="2212")
```

## option_risk_indicator_sse
描述: 上海证券交易所-期权风险指标数据
输入: date - 交易日如"20240626"
输出: TRADE_DATE, SECURITY_ID, CONTRACT_ID, CONTRACT_SYMBOL, DELTA_VALUE, THETA_VALUE, GAMMA_VALUE, VEGA_VALUE, RHO_VALUE, IMPLC_VOLATLTY
```python
option_risk_indicator_sse_df = ak.option_risk_indicator_sse(date="20240626")
```

## option_current_day_sse
描述: 上海证券交易所-当日合约信息
输入: 无
输出: 合约编码, 合约交易代码, 合约简称, 标的券名称及代码, 类型, 行权价, 合约单位, 期权行权日, 行权交收日, 到期日, 开始日期
```python
option_current_day_sse_df = ak.option_current_day_sse()
```

## option_current_day_szse
描述: 深圳证券交易所-当日合约信息
输入: 无
输出: 序号, 合约编码, 合约代码, 合约简称, 标的证券简称(代码), 合约类型, 行权价, 合约单位, 最后交易日, 行权日, 到期日, 交收日, 新挂, 涨停价格, 跌停价格, 前结算价, 合约调整, 停牌, 合约总持仓, 挂牌原因, 原合约代码, 原合约简称, 原行权价格, 原合约单位, 合约到期剩余交易天数, 合约到期剩余自然天数, 下次合约调整剩余交易天数, 下次合约调整剩余自然天数, 交易日期
```python
option_current_day_szse_df = ak.option_current_day_szse()
```

## option_daily_stats_sse
描述: 上海证券交易所-股票期权每日统计
输入: date - 交易日如"20240626"
输出: 合约标的代码, 合约标的名称, 合约数量, 总成交额, 总成交量, 认购成交量, 认沽成交量, 认沽/认购, 未平仓合约总数, 未平仓认购合约数, 未平仓认沽合约数
```python
option_daily_stats_sse_df = ak.option_daily_stats_sse(date="20240626")
```

## option_daily_stats_szse
描述: 深圳证券交易所-期权日度概况
输入: date - 交易日如"20240626"
输出: 合约标的代码, 合约标的名称, 成交量, 认购成交量, 认沽成交量, 认沽/认购持仓比, 未平仓合约总数, 未平仓认购合约数, 未平仓认沽合约数, 交易日
```python
option_daily_stats_szse_df = ak.option_daily_stats_szse(date="20240626")
```

## option_cffex_sz50_list_sina
描述: 中金所-上证50指数-所有合约列表
输入: 无
输出: 合约列表(dict)
```python
option_cffex_sz50_list_sina_df = ak.option_cffex_sz50_list_sina()
```

## option_cffex_hs300_list_sina
描述: 中金所-沪深300指数-所有合约列表
输入: 无
输出: 合约列表(dict)
```python
option_cffex_hs300_list_sina_df = ak.option_cffex_hs300_list_sina()
```

## option_cffex_zz1000_list_sina
描述: 中金所-中证1000指数-所有合约列表
输入: 无
输出: 合约列表(dict)
```python
option_cffex_zz1000_list_sina_df = ak.option_cffex_zz1000_list_sina()
```

## option_cffex_sz50_spot_sina
描述: 新浪财经-中金所-上证50指数-指定合约实时行情
输入: symbol - 合约代码如"ho2303"
输出: 看涨合约-买量, 看涨合约-买价, 看涨合约-最新价, 看涨合约-卖价, 看涨合约-卖量, 看涨合约-持仓量, 看涨合约-涨跌, 行权价, 看涨合约-标识, 看跌合约-买量, 看跌合约-买价, 看跌合约-最新价, 看跌合约-卖价, 看跌合约-卖量, 看跌合约-持仓量, 看跌合约-涨跌, 看跌合约-标识
```python
option_cffex_sz50_spot_sina_df = ak.option_cffex_sz50_spot_sina(symbol="ho2303")
```

## option_cffex_hs300_spot_sina
描述: 新浪财经-中金所-沪深300指数-指定合约实时行情
输入: symbol - 合约代码如"io2104"
输出: 看涨合约-买量, 看涨合约-买价, 看涨合约-最新价, 看涨合约-卖价, 看涨合约-卖量, 看涨合约-持仓量, 看涨合约-涨跌, 行权价, 看涨合约-标识, 看跌合约-买量, 看跌合约-买价, 看跌合约-最新价, 看跌合约-卖价, 看跌合约-卖量, 看跌合约-持仓量, 看跌合约-涨跌, 看跌合约-标识
```python
option_cffex_hs300_spot_sina_df = ak.option_cffex_hs300_spot_sina(symbol="io2104")
```

## option_cffex_zz1000_spot_sina
描述: 新浪财经-中金所-中证1000指数-指定合约实时行情
输入: symbol - 合约代码如"mo2208"
输出: 看涨合约-买量, 看涨合约-买价, 看涨合约-最新价, 看涨合约-卖价, 看涨合约-卖量, 看涨合约-持仓量, 看涨合约-涨跌, 行权价, 看涨合约-标识, 看跌合约-买量, 看跌合约-买价, 看跌合约-最新价, 看跌合约-卖价, 看跌合约-卖量, 看跌合约-持仓量, 看跌合约-涨跌, 看跌合约-标识
```python
option_cffex_zz1000_spot_sina_df = ak.option_cffex_zz1000_spot_sina(symbol="mo2208")
```

## option_cffex_sz50_daily_sina
描述: 中金所-上证50指数-指定合约日频行情
输入: symbol - 合约代码如"ho2303P2350"
输出: date, open, high, low, close, volume
```python
option_cffex_sz50_daily_sina_df = ak.option_cffex_sz50_daily_sina(symbol="ho2303P2350")
```

## option_cffex_hs300_daily_sina
描述: 中金所-沪深300指数-指定合约日频行情
输入: symbol - 合约代码如"io2202P4350"
输出: date, open, high, low, close, volume
```python
option_cffex_hs300_daily_sina_df = ak.option_cffex_hs300_daily_sina(symbol="io2004C4450")
```

## option_cffex_zz1000_daily_sina
描述: 中金所-中证1000指数-指定合约日频行情
输入: symbol - 合约代码如"mo2208P6200"
输出: date, open, high, low, close, volume
```python
option_cffex_zz1000_daily_sina_df = ak.option_cffex_zz1000_daily_sina(symbol="mo2208P6200")
```

## option_sse_list_sina
描述: 上交所-50ETF/300ETF-合约到期月份列表
输入: symbol - "50ETF"或"300ETF"; exchange - "null"
输出: 到期月份列表
```python
option_sse_list_sina_df = ak.option_sse_list_sina(symbol="50ETF", exchange="null")
```

## option_sse_expire_day_sina
描述: 指定到期月份品种的剩余到期时间
输入: trade_date - 到期月份如"202002"; symbol - "50ETF"或"300ETF"; exchange - "null"
输出: 到期日期, 剩余天数
```python
option_sse_expire_day_sina_df = ak.option_sse_expire_day_sina(trade_date="202002", symbol="50ETF", exchange="null")
```

## option_sse_codes_sina
描述: 新浪期权-看涨看跌合约代码
输入: symbol - "看涨期权"或"看跌期权"; trade_date - 到期月份如"202002"; underlying - 标的代码如"510300"
输出: 序号, 期权代码
```python
option_sse_codes_sina_df = ak.option_sse_codes_sina(trade_date="202002", underlying="510300")
```

## option_sse_spot_price_sina
描述: 期权实时数据
输入: symbol - 期权代码如"10002273"
输出: 字段, 值
```python
option_sse_spot_price_sina_df = ak.option_sse_spot_price_sina(symbol="10002273")
```

## option_sse_underlying_spot_price_sina
描述: 期权标的物实时数据
输入: symbol - 标的代码如"sh510300"
输出: 字段, 值
```python
option_sse_underlying_spot_price_sina_df = ak.option_sse_underlying_spot_price_sina(symbol="sh510300")
```

## option_sse_greeks_sina
描述: 新浪财经-期权希腊字母信息表
输入: symbol - 期权代码如"10002273"
输出: 字段, 值
```python
option_sse_greeks_sina_df = ak.option_sse_greeks_sina(symbol="10002273")
```

## option_sse_minute_sina
描述: 期权行情分钟数据(当天)
输入: symbol - 期权代码如"10003720"
输出: 日期, 时间, 价格, 成交, 持仓, 均价
```python
option_sse_minute_sina_df = ak.option_sse_minute_sina(symbol="10003720")
```

## option_sse_daily_sina
描述: 期权行情日数据
输入: symbol - 期权代码如"10002273"
输出: 时间, 开盘, 最高, 最低, 收盘, 成交
```python
option_sse_daily_sina_df = ak.option_sse_daily_sina(symbol="10002273")
```

## option_finance_minute_sina
描述: 新浪财经-金融期权-股票期权分时行情
输入: symbol - 期权代码如"10002415"
输出: date, time, price, average_price, volume
```python
option_finance_minute_sina_df = ak.option_finance_minute_sina(symbol="10002415")
```

## option_minute_em
描述: 东方财富网-期权市场-分时行情
输入: symbol - 合约代码如"MO2402-C-5400"
输出: time, close, high, low, volume, amount
```python
option_minute_em_df = ak.option_minute_em(symbol="MO2402-C-5400")
```

## option_current_em
描述: 东方财富网-期权市场-全部合约实时行情
输入: 无
输出: 代码, 名称, 最新价, 涨跌额, 涨跌幅, 成交量, 成交额, 持仓量, 行权价, 剩余日, 日增, 昨结, 今开, 市场标识
```python
option_current_em_df = ak.option_current_em()
```

## option_lhb_em
描述: 东方财富网-期权龙虎榜-金融期权
输入: symbol - "510050"/"510300"/"159919"; indicator - 交易/持仓情况; trade_date - 日期如"20220121"
输出: 交易类型, 交易日期, 证券代码, 标的名称, 名次, 机构, XX量, 增减, 净XX量, 占总交易量比例
```python
option_lhb_em_df = ak.option_lhb_em(symbol="510300", indicator="期权持仓情况-认沽持仓量", trade_date="20220121")
```

## option_value_analysis_em
描述: 东方财富网-期权价值分析
输入: 无
输出: 期权代码, 期权名称, 最新价, 时间价值, 内在价值, 隐含波动率, 理论价格, 标的名称, 标的最新价, 标的近一年波动率, 到期日
```python
option_value_analysis_em_df = ak.option_value_analysis_em()
```

## option_risk_analysis_em
描述: 东方财富网-期权风险分析
输入: 无
输出: 期权代码, 期权名称, 最新价, 涨跌幅, 杠杆比率, 实际杠杆比率, Delta, Gamma, Vega, Rho, Theta, 到期日
```python
option_risk_analysis_em_df = ak.option_risk_analysis_em()
```

## option_premium_analysis_em
描述: 东方财富网-期权折溢价
输入: 无
输出: 期权代码, 期权名称, 最新价, 涨跌幅, 行权价, 折溢价率, 标的名称, 标的最新价, 标的涨跌幅, 盈亏平衡价, 到期日
```python
option_premium_analysis_em_df = ak.option_premium_analysis_em()
```

## option_commodity_contract_sina
描述: 新浪财经-商品期权当前在交易的合约
输入: symbol - 品种如"黄金期权"
输出: 序号, 合约
```python
option_commodity_contract_sina_df = ak.option_commodity_contract_sina(symbol="黄金期权")
```

## option_commodity_contract_table_sina
描述: 新浪财经-商品期权T型报价表
输入: symbol - 品种如"动力煤期权"; contract - 合约如"zc2103"
输出: 看涨合约-买量, 看涨合约-买价, 看涨合约-最新价, 看涨合约-卖价, 看涨合约-卖量, 看涨合约-持仓量, 看涨合约-涨跌, 行权价, 看涨合约-看涨期权合约, 看跌合约-买量, 看跌合约-买价, 看跌合约-最新价, 看跌合约-卖价, 看跌合约-卖量, 看跌合约-持仓量, 看跌合约-涨跌, 看跌合约-看跌期权合约
```python
option_commodity_contract_table_sina_df = ak.option_commodity_contract_table_sina(symbol="动力煤期权", contract="zc2103")
```

## option_commodity_hist_sina
描述: 新浪财经-商品期权历史行情-日频率
输入: symbol - 合约代码如"au2012C328"
输出: date, open, high, low, close, volume
```python
option_commodity_hist_sina_df = ak.option_commodity_hist_sina(symbol="au2012C328")
```

## option_comm_info
描述: 九期网-商品期权手续费数据
输入: symbol - 品种如"工业硅期权"
输出: 期权品种, 现价, 涨/跌停板, 成交量, 类型, 权利金, 开仓, 平昨, 平今, 行权, 每跳毛利/元, 手续费(开+平), 每跳净利/元, 备注, 交易所, 手续费更新时间, 价格更新时间
```python
option_comm_info_df = ak.option_comm_info(symbol="工业硅期权")
```

## option_margin
描述: 唯爱期货-期权保证金
输入: symbol - 品种如"原油期权"
输出: 合约标的, 合约代码, 结算价, 交易乘数, 买方权利金, 卖方保证金, 手续费单位, 开仓手续费, 平今手续费, 平昨手续费, 手续费(开+平今), 更新时间
```python
option_margin_df = ak.option_margin(symbol="原油期权")
```

## option_hist_shfe
描述: 上海期货交易所-商品期权数据
输入: symbol - 品种如"铜期权"; trade_date - 交易日如"20191017"
输出: 合约代码, 开盘价, 最高价, 最低价, 收盘价, 前结算价, 结算价, 涨跌1, 涨跌2, 成交量, 持仓量, 持仓量变化, 成交额, 德尔塔, 行权量
```python
option_hist_shfe_df = ak.option_hist_shfe(symbol="铝期权", trade_date="20200827")
```

## option_hist_dce
描述: 大连商品交易所-商品期权数据
输入: symbol - 品种如"聚丙烯期权"; trade_date - 交易日如"20251016"
输出: 品种名称, 合约, 开盘价, 最高价, 最低价, 收盘价, 前结算价, 结算价, 涨跌, 涨跌1, Delta, 隐含波动率(%), 成交量, 持仓量, 持仓量变化, 成交额, 行权量
```python
option_hist_dce_df = ak.option_hist_dce(symbol="聚丙烯期权", trade_date="20251016")
```

## option_hist_czce
描述: 郑州商品交易所-商品期权数据
输入: symbol - 品种如"白糖期权"; trade_date - 交易日如"20240711"
输出: 品种代码, 昨结算, 今开盘, 最高价, 最低价, 今收盘, 今结算, 涨跌1, 涨跌2, 成交量(手), 空盘量, 增减量, 成交额(万元), DELTA, 隐含波动率, 行权量
```python
option_hist_czce_df = ak.option_hist_czce(symbol="白糖期权", trade_date="20240711")
```

## option_hist_gfex
描述: 广州期货交易所-商品期权数据
输入: symbol - "工业硅"或"碳酸锂"; trade_date - 交易日如"20230724"
输出: 商品名称, 合约名称, 开盘价, 最高价, 最低价, 收盘价, 前结算价, 结算价, 涨跌, 涨跌1, Delta, 成交量, 持仓量, 持仓量变化, 成交额, 行权量, 隐含波动率
```python
option_hist_gfex_df = ak.option_hist_gfex(symbol="工业硅", trade_date="20230418")
```

## option_vol_gfex
描述: 广州期货交易所-商品期权隐含波动参考值
输入: symbol - "工业硅"或"碳酸锂"; trade_date - 交易日如"20230724"
输出: 合约系列, 隐含波动率
```python
option_vol_gfex_df = ak.option_vol_gfex(symbol="工业硅", trade_date="20230418")
```

## option_czce_hist
描述: 郑州商品交易所-商品期权历史行情数据(按年份)
输入: year - 年份如"2019"; symbol - 品种代码如"SR"
输出: 交易日期, 品种代码, 昨结算, 今开盘, 最高价, 最低价, 今收盘, 今结算, 涨跌1, 涨跌2, 成交量(手), 空盘量, 增减量, 成交额(万元), DELTA, 隐含波动率, 行权量
```python
option_hist_yearly_czce_df = ak.option_hist_yearly_czce(symbol="RM", year="2025")
```
