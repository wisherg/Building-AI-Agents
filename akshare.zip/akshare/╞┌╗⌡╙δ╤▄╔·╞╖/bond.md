# 债券数据

```python
import akshare as ak
```

## bond_info_cm
描述: 中国外汇交易中心-债券信息查询
输入: bond_name - 债券名称; bond_code - 债券代码; bond_issue - 发行人; bond_type - 债券类型; coupon_type - 息票类型; issue_year - 发行年份; underwriter - 承销商; grade - 评级
输出: 债券简称, 债券代码, 发行人/受托机构, 债券类型, 发行日期, 最新债项评级, 查询代码
```python
bond_info_cm_df = ak.bond_info_cm(bond_type="短期融资券", coupon_type="零息式", issue_year="2019", grade="A-1")
```

## bond_info_detail_cm
描述: 中国外汇交易中心-债券详情
输入: symbol - 债券简称
输出: name, value
```python
bond_info_detail_cm_df = ak.bond_info_detail_cm(symbol="19万林投资CP001")
```

## bond_cash_summary_sse
描述: 上登债券信息网-债券现券市场概览
输入: date - 日期(如'20210111')
输出: 债券现货, 托管只数, 托管市值, 托管面值, 数据日期
```python
bond_cash_summary_sse_df = ak.bond_cash_summary_sse(date='20210111')
```

## bond_deal_summary_sse
描述: 上登债券信息网-债券成交概览
输入: date - 日期(如'20210104')
输出: 债券类型, 当日成交笔数, 当日成交金额, 当年成交笔数, 当年成交金额, 数据日期
```python
bond_deal_summary_sse_df = ak.bond_deal_summary_sse(date='20210104')
```

## bond_debt_nafmii
描述: 中国银行间市场交易商协会-非金融企业债务融资工具
输入: page - 页码
输出: 债券名称, 品种, 注册或备案, 金额, 注册通知书文号, 更新日期, 项目状态
```python
bond_debt_nafmii_df = ak.bond_debt_nafmii(page="2")
```

## bond_spot_quote
描述: 中国外汇交易中心-现券市场做市报价
输入: 无
输出: 报价机构, 债券简称, 买入净价, 卖出净价, 买入收益率, 卖出收益率
```python
bond_spot_quote_df = ak.bond_spot_quote()
```

## bond_spot_deal
描述: 中国外汇交易中心-现券市场成交行情
输入: 无
输出: 债券简称, 成交净价, 最新收益率, 涨跌, 加权收益率, 交易量
```python
bond_spot_deal_df = ak.bond_spot_deal()
```

## bond_china_yield
描述: 中国债券信息网-国债及其他债券收益率曲线
输入: start_date - 开始日期; end_date - 结束日期(间隔不超过一年)
输出: 曲线名称, 日期, 3月, 6月, 1年, 3年, 5年, 7年, 10年, 30年
```python
bond_china_yield_df = ak.bond_china_yield(start_date="20210201", end_date="20220201")
```

## bond_zh_hs_spot
描述: 新浪财经-沪深债券实时行情数据
输入: start_page - 开始页; end_page - 结束页(每页80条)
输出: 代码, 名称, 最新价, 涨跌额, 涨跌幅, 买入, 卖出, 昨收, 今开, 最高, 最低, 成交量, 成交额
```python
bond_zh_hs_spot_df = ak.bond_zh_hs_spot(start_page="1", end_page="5")
```

## bond_zh_hs_daily
描述: 新浪财经-沪深债券历史行情数据
输入: symbol - 债券代码(如"sh010107")
输出: date, open, high, low, close, volume
```python
bond_zh_hs_daily_df = ak.bond_zh_hs_daily(symbol="sh010107")
```

## bond_cb_profile_sina
描述: 新浪财经-可转债详情资料
输入: symbol - 带市场标识的转债代码(如"sz128039")
输出: item, value
```python
bond_cb_profile_sina_df = ak.bond_cb_profile_sina(symbol="sz128039")
```

## bond_cb_summary_sina
描述: 新浪财经-可转债债券概况
输入: symbol - 带市场标识的转债代码(如"sh155255")
输出: item, value
```python
bond_cb_summary_sina_df = ak.bond_cb_summary_sina(symbol="sh155255")
```

## bond_zh_hs_cov_spot
描述: 新浪财经-沪深可转债实时行情数据
输入: 无
输出: symbol, name, trade, pricechange等
```python
bond_zh_hs_cov_spot_df = ak.bond_zh_hs_cov_spot()
```

## bond_zh_hs_cov_daily
描述: 新浪财经-沪深可转债历史行情数据(日频)
输入: symbol - 可转债代码(如"sz128039")
输出: date, open, high, low, close, volume
```python
bond_zh_hs_cov_daily_df = ak.bond_zh_hs_cov_daily(symbol="sz128039")
```

## bond_zh_hs_cov_min
描述: 东方财富网-可转债分时行情
输入: symbol - 转债代码(如'sz123106'); period - 周期(1/5/15/30/60); adjust - 复权(''/qfq/hfq); start_date - 开始时间; end_date - 结束时间
输出: 时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 最新价/涨跌幅/振幅/换手率
```python
bond_zh_hs_cov_min_df = ak.bond_zh_hs_cov_min(symbol="sz123124", period='5', adjust='hfq')
```

## bond_zh_hs_cov_pre_min
描述: 东方财富网-可转债盘前分时数据
输入: symbol - 转债代码(如"sh113570")
输出: 时间, 开盘, 收盘, 最高, 最低, 成交量, 成交额, 最新价
```python
bond_zh_hs_cov_pre_min_df = ak.bond_zh_hs_cov_pre_min(symbol="sh113570")
```

## bond_zh_cov
描述: 东方财富网-可转债数据一览表
输入: 无
输出: 债券代码, 债券简称, 申购日期, 申购代码, 正股代码, 正股简称, 正股价, 转股价, 转股价值, 债现价, 转股溢价率, 发行规模, 中签率, 上市时间, 信用评级
```python
bond_zh_cov_df = ak.bond_zh_cov()
```

## bond_zh_cov_info
描述: 东方财富网-可转债详情
输入: symbol - 可转债代码; indicator - 指标(基本信息/中签号/筹资用途/重要日期)
输出: 债券代码等67个字段
```python
bond_zh_cov_info_df = ak.bond_zh_cov_info(symbol="123121", indicator="基本信息")
```

## bond_zh_cov_info_ths
描述: 同花顺-数据中心-可转债
输入: 无
输出: 债券代码, 债券简称, 申购日期, 申购代码, 原股东配售码, 计划发行量, 实际发行量, 中签公布日, 上市日期, 正股代码, 正股简称, 转股价格, 到期时间, 中签率
```python
bond_zh_cov_info_ths_df = ak.bond_zh_cov_info_ths()
```

## bond_cov_comparison
描述: 东方财富网-可转债比价表
输入: 无
输出: 序号, 转债代码, 转债名称, 转债最新价, 转债涨跌幅, 正股代码, 正股名称, 正股最新价, 正股涨跌幅, 转股价, 转股价值, 转股溢价率, 纯债溢价率, 回售触发价, 强赎触发价, 到期赎回价, 纯债价值, 开始转股日, 上市日期, 申购日期
```python
bond_cov_comparison_df = ak.bond_cov_comparison()
```

## bond_zh_cov_value_analysis
描述: 东方财富网-可转债价值分析/溢价率分析
输入: symbol - 可转债代码(如"113527")
输出: 日期, 收盘价, 纯债价值, 转股价值, 纯债溢价率, 转股溢价率
```python
bond_zh_cov_value_analysis_df = ak.bond_zh_cov_value_analysis(symbol="113527")
```

## bond_sh_buy_back_em
描述: 东方财富网-上证质押式回购
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 今开, 最高, 最低, 昨收, 成交量, 成交额
```python
bond_sh_buy_back_em_df = ak.bond_sh_buy_back_em()
```

## bond_sz_buy_back_em
描述: 东方财富网-深证质押式回购
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 今开, 最高, 最低, 昨收, 成交量, 成交额
```python
bond_sz_buy_back_em_df = ak.bond_sz_buy_back_em()
```

## bond_buy_back_hist_em
描述: 东方财富网-质押式回购历史数据
输入: symbol - 质押式回购代码(如"204001")
输出: 日期, 开盘, 收盘, 最高, 最低, 成交量, 成交额
```python
bond_buy_back_hist_em_df = ak.bond_buy_back_hist_em(symbol="204001")
```

## bond_cb_jsl
描述: 集思录可转债实时数据(含cookie可获取完整数据)
输入: cookie - 集思录cookie(空则返回前30条)
输出: 代码, 转债名称, 现价, 涨跌幅, 正股代码, 正股名称, 正股价, 正股涨跌, 正股PB, 转股价, 转股价值, 转股溢价率, 债券评级, 回售触发价, 强赎触发价, 转债占比, 到期时间, 剩余年限, 剩余规模, 成交额, 换手率, 到期税前收益, 双低
```python
bond_cb_jsl_df = ak.bond_cb_jsl(cookie="您的集思录cookie")
```

## bond_cb_redeem_jsl
描述: 集思录可转债-强赎
输入: 无
输出: 代码, 名称, 现价, 正股代码, 正股名称, 规模, 剩余规模, 转股起始日, 最后交易日, 到期日, 转股价, 强赎触发比, 强赎触发价, 正股价, 强赎价, 强赎天计数, 强赎条款, 强赎状态
```python
bond_cb_redeem_jsl_df = ak.bond_cb_redeem_jsl()
```

## bond_cb_index_jsl
描述: 集思录可转债等权指数
输入: 无
输出: price_dt, price, amount, volume, count, increase_val, increase_rt, avg_price, mid_price, avg_dblow, avg_premium_rt, mid_premium_rt, avg_ytm_rt, turnover_rt等
```python
bond_cb_index_jsl_df = ak.bond_cb_index_jsl()
```

## bond_cb_adj_logs_jsl
描述: 集思录-可转债转股价格调整记录
输入: symbol - 可转债代码(如"128013")
输出: 转债名称, 股东大会日, 下修前转股价, 下修后转股价, 新转股价生效日期, 下修底价
```python
bond_convert_adj_logs_jsl_df = ak.bond_cb_adj_logs_jsl(symbol="128013")
```

## bond_china_close_return
描述: 收盘收益率曲线历史数据(近3个月, 每次不超过1个月)
输入: symbol - 曲线名称(如"国债"); period - 期限间隔(0.1/0.5/1); start_date - 开始日期; end_date - 结束日期
输出: 日期, 期限, 到期收益率, 即期收益率, 远期收益率
```python
bond_china_close_return_df = ak.bond_china_close_return(symbol="国债", period="1", start_date="20231101", end_date="20231101")
```

## bond_zh_us_rate
描述: 东方财富网-中美国债收益率历史数据
输入: start_date - 开始日期(如"19901219")
输出: 日期, 中国国债收益率2/5/10/30年, 中国国债收益率10年-2年, 中国GDP年增率, 美国国债收益率2/5/10/30年, 美国国债收益率10年-2年, 美国GDP年增率
```python
bond_zh_us_rate_df = ak.bond_zh_us_rate(start_date="19901219")
```

## bond_gb_zh_sina
描述: 新浪财经-中国国债收益率行情(近1000个交易日)
输入: symbol - 期限(中国1/2/3/5/7/10/15/20/30年期国债)
输出: date, open, high, low, close, volume
```python
bond_gb_zh_sina_df = ak.bond_gb_zh_sina(symbol="中国10年期国债")
```

## bond_gb_us_sina
描述: 新浪财经-美国国债收益率行情(近1000个交易日)
输入: symbol - 期限(美国1月期~30年期国债)
输出: date, open, high, low, close, volume
```python
bond_gb_us_sina_df = ak.bond_gb_us_sina(symbol="美国10年期国债")
```

## bond_treasure_issue_cninfo
描述: 巨潮资讯-国债发行
输入: start_date - 开始日期; end_date - 结束日期
输出: 债券代码, 债券简称, 发行起始日, 发行终止日, 计划发行总量, 实际发行总量, 发行价格, 单位面值, 缴款日, 增发次数, 交易市场, 发行方式, 公告日期, 债券名称
```python
bond_treasure_issue_cninfo_df = ak.bond_treasure_issue_cninfo(start_date="20210910", end_date="20211109")
```

## bond_local_government_issue_cninfo
描述: 巨潮资讯-地方债发行
输入: start_date - 开始日期; end_date - 结束日期
输出: 债券代码, 债券简称, 发行起始日, 发行终止日, 计划发行总量, 实际发行总量, 发行价格, 单位面值, 缴款日, 增发次数, 交易市场, 发行方式, 公告日期, 债券名称
```python
bond_local_government_issue_cninfo_df = ak.bond_local_government_issue_cninfo(start_date="20210911", end_date="20211110")
```

## bond_corporate_issue_cninfo
描述: 巨潮资讯-企业债发行
输入: start_date - 开始日期; end_date - 结束日期
输出: 债券代码, 债券简称, 公告日期, 交易所网上发行起始日/终止日, 计划发行总量, 实际发行总量, 发行面值, 发行价格, 发行方式, 承销方式, 募资用途说明, 债券名称
```python
bond_corporate_issue_cninfo_df = ak.bond_corporate_issue_cninfo(start_date="20210911", end_date="20211110")
```

## bond_cov_issue_cninfo
描述: 巨潮资讯-可转债发行
输入: start_date - 开始日期; end_date - 结束日期
输出: 债券代码, 债券简称, 公告日期, 发行起始日, 发行终止日, 计划/实际发行总量, 初始转股价格, 转股开始/终止日期, 网上申购日期/代码, 交易市场, 债券名称
```python
bond_cov_issue_cninfo_df = ak.bond_cov_issue_cninfo(start_date="20210913", end_date="20211112")
```

## bond_cov_stock_issue_cninfo
描述: 巨潮资讯-可转债转股
输入: 无
输出: 债券代码, 债券简称, 公告日期, 转股代码, 转股简称, 转股价格, 自愿转换期起始日/终止日, 标的股票, 债券名称
```python
bond_cov_stock_issue_cninfo_df = ak.bond_cov_stock_issue_cninfo()
```

## bond_new_composite_index_cbond
描述: 中国债券信息网-中债新综合指数
输入: indicator - 指标(全价/净价/财富/久期/凸性/到期收益率等); period - 期限(总值/1年以下/1-3年/3-5年等)
输出: date, value
```python
bond_new_composite_index_cbond_df = ak.bond_new_composite_index_cbond(indicator="财富", period="总值")
```

## bond_composite_index_cbond
描述: 中国债券信息网-中债综合指数(按待偿期限)
输入: indicator - 指标(全价/净价/财富等); period - 期限(总值/1年以下/1-3年等)
输出: date, value
```python
bond_composite_index_cbond_df = ak.bond_composite_index_cbond(indicator="财富", period="总值")
```

## bond_treasury_index_cbond
描述: 中国债券信息网-中债国债指数
输入: indicator - 指标(全价/净价/财富); period - 期限(0-1Y/0-3Y/5Y/7Y/10Y/30Y等)
输出: date, value
```python
bond_treasury_index_cbond_df = ak.bond_treasury_index_cbond(indicator="财富", period="5Y")
```

## bond_available_index_cbond
描述: 中国债券信息网-中债可选指数列表
输入: 无
输出: index, value
```python
bond_available_index_cbond_df = ak.bond_available_index_cbond()
```

## bond_index_general_cbond
描述: 中国债券信息网-中债指数族系查询
输入: index_category - 指数名称(参考bond_available_index_cbond); indicator - 指标; period - 期限
输出: date, value
```python
bond_index_general_cbond_df = ak.bond_index_general_cbond(index_category="新综合指数", indicator="全价", period="总值")
```
