# 奇货可查数据

> 所有接口使用 pro_api 模式，需提供 token

```python
from akshare import pro_api
pro = pro_api(token="在此处输入您的 token")
```

## broker_positions
描述: 席位持仓数据
输入: broker - 席位如"永安期货"; date - 查询日期如"2018-08-08"
输出: code, long, short, long_chge, short_chge, symbol
```python
broker_positions_df = pro.broker_positions(broker="永安期货", date="2018-08-08")
```

## broker_calendar
描述: 席位盈亏数据
输入: broker - 席位如"永安期货"; start_date - 开始日期; end_date - 结束日期
输出: trans_date, profit
```python
broker_calendar_df = pro.broker_calendar(broker="永安期货", start_date="2018-07-08", end_date="2018-08-08")
```

## broker_flow
描述: 席位每日大资金流动数据
输入: broker - 席位; date - 查询日期; offset - 阈值如"1000000"
输出: variety, money
```python
broker_flow_df = pro.broker_flow(broker="永安期货", date="2018-08-08", offset="1000000")
```

## broker_bbr
描述: 席位多空比数据
输入: broker - 席位; date - 查询日期
输出: bbr
```python
broker_bbr_df = pro.broker_bbr(broker="永安期货", date="2018-08-08")
```

## broker_net_money_chge
描述: 席位净持仓保证金变化数据
输入: broker - 席位; date - 查询日期
输出: symbol, value
```python
broker_net_money_chge_df = pro.broker_net_money_chge(broker="永安期货", date="2018-08-08")
```

## broker_net_money
描述: 席位净持仓保证金数据
输入: broker - 席位; date - 查询日期
输出: symbol, value
```python
broker_net_money_df = pro.broker_net_money(broker="永安期货", date="2018-08-08")
```

## broker_total_money
描述: 席位总持仓保证金数据
输入: broker - 席位; date - 查询日期
输出: symbol, value
```python
broker_total_money_df = pro.broker_total_money(broker="永安期货", date="2018-08-08")
```

## broker_profit
描述: 席位盈亏排行数据
输入: broker - 席位; start_date - 开始日期; end_date - 结束日期
输出: symbol, total_profit
```python
broker_profit_df = pro.broker_profit(broker="永安期货", start_date="2018-02-08", end_date="2018-08-08")
```

## broker_in_profit_list
描述: 席位盈利品种列表
输入: broker - 席位; date - 查询日期
输出: symbol, profit
```python
broker_in_profit_list_df = pro.broker_in_profit_list(broker="永安期货", date="2018-08-08")
```

## broker_in_loss_list
描述: 席位亏损品种列表
输入: broker - 席位; date - 查询日期
输出: symbol, profit
```python
broker_in_loss_list_df = pro.broker_in_loss_list(broker="永安期货", date="2018-08-08")
```

## broker_all
描述: 席位列表数据
输入: 无
输出: 席位名称列表
```python
broker_all_df = pro.broker_all()
```

## broker_positions_process
描述: 席位持仓数据处理
输入: broker - 席位; date - 查询日期
输出: 处理后的持仓数据
```python
broker_positions_process_df = pro.broker_positions_process(broker="永安期货", date="2018-08-08")
```

## broker_pk
描述: 席位对比数据
输入: broker1 - 席位1; broker2 - 席位2; date - 查询日期
输出: 对比数据
```python
broker_pk_df = pro.broker_pk(broker1="永安期货", broker2="中信期货", date="2018-08-08")
```

## variety_positions
描述: 合约持仓数据
输入: fields - "longs"或"shorts"; code - 合约代号如"rb1810"; date - 查询日期
输出: broker, long, long_chge, short, short_chge
```python
variety_positions_df = pro.variety_positions(fields="longs", code="rb1810", date="2018-08-08")
```

## variety_all_positions
描述: 商品持仓数据(按品种汇总)
输入: fields - "longs"或"shorts"; symbol - 品种编码如"RB"; date - 查询日期
输出: broker, long, long_chge, short, short_chge, code
```python
variety_all_positions_df = pro.variety_all_positions(fields="shorts", symbol="RB", date="2018-08-08")
```

## variety_net_positions
描述: 商品净持仓数据
输入: symbol - 品种编码; broker - 席位; date - 查询日期
输出: trans_date, net_position
```python
variety_net_positions_df = pro.variety_net_positions(symbol="RB", broker="永安期货", date="2018-08-08")
```

## variety_quotes
描述: 合约行情数据
输入: code - 合约代号如"rb1810"; date - 查询日期
输出: open, close, high, low, volume, openint
```python
variety_quotes_df = pro.variety_quotes(code="rb1810", date="2018-08-08")
```

## variety_money
描述: 商品沉淀资金数据
输入: symbol - 品种编码如"RB"; date - 查询日期
输出: trans_date, total_value
```python
variety_money_df = pro.variety_money(symbol="RB", date="2018-08-08")
```

## variety_bbr
描述: 合约多空比数据
输入: code - 合约代号如"rb1810"; date - 查询日期
输出: trans_date, bbr
```python
variety_bbr_df = pro.variety_bbr(code="rb1810", date="2018-08-08")
```

## variety_net_money_chge
描述: 合约净持仓保证金变化数据
输入: code - 合约代号如"rb1810"; date - 查询日期
输出: broker, value
```python
variety_net_money_chge_df = pro.variety_net_money_chge(code="rb1810", date="2018-08-08")
```

## variety_net_money
描述: 合约净持仓保证金数据
输入: code - 合约代号如"rb1810"; date - 查询日期
输出: broker, value
```python
variety_net_money_df = pro.variety_net_money(code="rb1810", date="2018-08-08")
```

## variety_total_money
描述: 合约总持仓保证金数据
输入: code - 合约代号如"rb1810"; date - 查询日期
输出: broker, value
```python
variety_total_money_df = pro.variety_total_money(code="rb1810", date="2018-08-08")
```

## variety_profit
描述: 商品的席位盈亏数据
输入: symbol - 品种编码如"RB"; start_date - 开始日期; end_date - 结束日期
输出: broker, total_profit
```python
variety_profit_df = pro.variety_profit(symbol="RB", start_date="2018-02-08", end_date="2018-08-08")
```

## variety_strategies
描述: 自研指标数据(龙虎比/牛熊线)
输入: code - 合约代号如"rb1810"; date - 查询日期
输出: trans_date, longhu, niuxiong
```python
variety_strategies_df = pro.variety_strategies(code="rb1810", date="2018-08-08")
```

## variety_longhu_top
描述: 龙虎比排行数据
输入: fields - "long"或"short"; date - 查询日期
输出: symbol, code, value
```python
variety_longhu_top_df = pro.variety_longhu_top(fields="long", date="2018-08-08")
```

## variety_niuxiong_top
描述: 牛熊线排行数据
输入: fields - "long"或"short"; date - 查询日期
输出: symbol, code, value
```python
variety_niuxiong_top_df = pro.variety_niuxiong_top(fields="long", date="2018-08-08")
```

## variety_reports
描述: 商品相关研报数据
输入: csymbolode - 品种编码如"RB"; date - 查询日期
输出: title, pub, time, url
```python
variety_reports_df = pro.variety_reports(csymbolode="RB", date="2018-08-08")
```

## variety_all
描述: 商品列表数据
输入: 无
输出: name, symbol, market
```python
variety_all_df = pro.variety_all()
```

## variety_list
描述: 合约索引数据
输入: date - 查询日期
输出: 合约列表
```python
variety_list_df = pro.variety_list(date="2018-08-08")
```

## variety_no_futures
描述: 非期货公司净持仓数据
输入: symbol - 品种编码如"RB"; date - 查询日期
输出: trans_date, net_value
```python
variety_no_futures_df = pro.variety_no_futures(symbol="RB", date="2018-08-08")
```

## commodity_flow_long
描述: 每日净流多列表(商品)
输入: date - 查询日期
输出: broker, money, variety
```python
commodity_flow_long_df = pro.commodity_flow_long(date="2018-08-08")
```

## commodity_flow_short
描述: 每日净流空列表(商品)
输入: date - 查询日期
输出: broker, money, variety
```python
commodity_flow_short_df = pro.commodity_flow_short(date="2018-08-08")
```

## stock_flow_long
描述: 每日净流多列表(指数)
输入: date - 查询日期
输出: broker, money, variety
```python
stock_flow_long_df = pro.stock_flow_long(date="2018-08-08")
```

## stock_flow_short
描述: 每日净流空列表(指数)
输入: date - 查询日期
输出: broker, money, variety
```python
stock_flow_short_df = pro.stock_flow_short(date="2018-08-08")
```

## money_in_out
描述: 每日商品保证金沉淀变化
输入: date - 查询日期
输出: symbol, chge
```python
money_in_out_df = pro.money_in_out(date="2018-08-08")
```

## term_structure
描述: 期限结构数据
输入: variety - 品种编码如"RB"; date - 查询日期
输出: code, close
```python
term_structure_df = pro.term_structure(variety="RB", date="2018-08-08")
```

## inventory
描述: 库存数据(参数类型一: 按日期查询)
输入: variety - 品种编码如"RB"; date - 查询日期
输出: trans_date, vol
```python
inventory_df = pro.inventory(variety="RB", date="2018-08-08")
```

## inventory(按年周查询)
描述: 库存数据(参数类型二: 按年份和周数查询)
输入: variety - 品种编码如"RB"; year - 年份如"2019"; week_number - 第几周如"10"
输出: trans_date, vol
```python
inventory_df = pro.inventory(variety="RB", year="2019", week_number="10")
```

## profit
描述: 利润数据
输入: variety - 品种编码如"RB"; date - 查询日期
输出: trans_date, profit, profit_rate
```python
profit_df = pro.profit(variety="RB", date="2019-12-12")
```

## trader_prices
描述: 现货贸易商报价
输入: variety - 品种编码如"RB"; date - 查询日期
输出: name, price, band, model, unit
```python
trader_prices_df = pro.trader_prices(variety="RB", date="2020-03-30")
```

## intertemporal_arbitrage
描述: 跨期套利数据
输入: variety - 品种编码; code1 - 合约月份1如"01"; code2 - 合约月份2如"05"; date - 查询日期
输出: trans_date, code1, code2, close1, close2, spread
```python
intertemporal_arbitrage_df = pro.intertemporal_arbitrage(variety="RB", code1="01", code2="05", date="2018-08-08")
```

## free_spread
描述: 自由价差数据
输入: variety1 - 品种编码1; code1 - 合约月份1; variety2 - 品种编码2; code2 - 合约月份2; date - 查询日期
输出: trans_date, code1, code2, code1_close, code2_close, spread
```python
free_spread_df = pro.free_spread(variety1="RB", code1="01", variety2="HC", code2="01", date="2018-08-08")
```

## free_ratio
描述: 自由价比数据
输入: variety1 - 品种编码1; code1 - 合约月份1; variety2 - 品种编码2; code2 - 合约月份2; date - 查询日期
输出: trans_date, code1, code2, code1_close, code2_close, ratio
```python
free_ratio_df = pro.free_ratio(variety1="RB", code1="01", variety2="HC", code2="01", date="2018-08-08")
```

## warehouse_receipt(按品种)
描述: 仓单数据(按品种查询)
输入: variety - 品种编码如"RB"; date - 查询日期
输出: trans_date, total_vol, total_chge
```python
warehouse_receipt_df = pro.warehouse_receipt(variety="RB", date="2018-08-08")
```

## warehouse_receipt(汇总)
描述: 仓单汇总数据(按日期查询全部品种)
输入: date - 查询日期
输出: symbol, total_vol, total_chge
```python
warehouse_receipt_sum_df = pro.warehouse_receipt(date="2018-08-08")
```

## virtual_real
描述: 虚实盘比数据
输入: variety - 品种编码; date - 查询日期
输出: 虚实盘比数据
```python
virtual_real_df = pro.virtual_real(variety="RB", date="2018-08-08")
```

## index_info
描述: 指数信息
输入: index_id - 指数id
输出: name, all_brokers, created_time, all_varieties, status, nickname, varieties, brokers
```python
index_info_df = pro.index_info(index_id="index0070c0eb-93ba-2da9-6633-fa70cb90e959")
```

## index_weights
描述: 指数权重数据
输入: index_id - 指数id; date - 查询日期
输出: variety, weight
```python
index_weights_df = pro.index_weights(index_id="index0070c0eb-93ba-2da9-6633-fa70cb90e959", date="2018-08-08")
```

## index_quotes
描述: 指数行情数据
输入: index_id - 指数id; date - 查询日期
输出: trans_date, volume, openint, price, bbr
```python
index_quotes_df = pro.index_quotes(index_id="index0070c0eb-93ba-2da9-6633-fa70cb90e959", date="2018-08-08")
```

## index_money
描述: 指数沉淀资金数据
输入: index_id - 指数id; date - 查询日期
输出: trans_date, total_value
```python
index_money_df = pro.index_money(index_id="index0070c0eb-93ba-2da9-6633-fa70cb90e959", date="2018-08-08")
```

## index_official
描述: 公共指数列表
输入: 无
输出: id, name
```python
index_official_df = pro.index_official()
```

## index_mine
描述: 个人指数列表
输入: 无
输出: id, name
```python
index_mine_df = pro.index_mine()
```

## index_trend
描述: 指数资金动向
输入: index_id - 指数id; date - 查询日期
输出: broker, variety, money
```python
index_trend_df = pro.index_trend(index_id="index0070c0eb-93ba-2da9-6633-fa70cb90e959", date="2018-08-08")
```

## index_profit
描述: 指数的席位盈亏数据
输入: index_id - 指数id; start_date - 开始日期; end_date - 结束日期
输出: broker, profit
```python
index_profit_df = pro.index_profit(index_id="index0070c0eb-93ba-2da9-6633-fa70cb90e959", start_date="2018-07-08", end_date="2018-08-08")
```

## long_pool
描述: 龙虎牛熊多头合约池
输入: date - 查询日期
输出: symbol, code
```python
long_pool_df = pro.long_pool(date="2018-08-08")
```

## short_pool
描述: 龙虎牛熊空头合约池
输入: date - 查询日期
输出: symbol, code
```python
short_pool_df = pro.short_pool(date="2018-08-08")
```
