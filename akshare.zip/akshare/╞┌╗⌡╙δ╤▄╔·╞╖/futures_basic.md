# 期货基础与行情数据

```python
import akshare as ak
```

## futures_fees_info
描述: openctp 期货交易费用参照表
输入: 无
输出: 交易所, 合约代码, 合约名称, 品种代码, 品种名称, 合约乘数, 最小跳动, 开仓费率, 开仓费用, 平仓费率, 平仓费用, 平今费率, 平今费用, 做多保证金率, 做多保证金, 做空保证金率, 做空保证金, 更新时间
```python
futures_fees_info_df = ak.futures_fees_info()
```

## futures_comm_info
描述: 九期网-期货手续费数据
输入: symbol - 交易所选择(所有/上海期货交易所/大连商品交易所/郑州商品交易所/上海国际能源交易中心/中国金融期货交易所/广州期货交易所)
输出: 交易所名称, 合约名称, 合约代码, 现价, 涨停板, 跌停板, 保证金-买开, 保证金-卖开, 保证金-每手, 手续费标准-开仓, 手续费标准-平昨, 手续费标准-平今, 每跳毛利, 手续费, 每跳净利, 备注
```python
futures_comm_info_df = ak.futures_comm_info(symbol="所有")
```

## futures_comm_js
描述: 金十财经-期货手续费数据
输入: date - 日期(YYYYMMDD格式)
输出: 日期, 合约品种, 合约代码, 手续费公布时间, 价格公布时间, 现价, 涨停板, 跌停板, 保证金/买开, 保证金/卖开, 保证金/每手, 开仓, 平今, 平昨, 每手跳数, 每跳毛利, 每跳净利, 交易所
```python
futures_comm_js_df = ak.futures_comm_js(date="20260213")
```

## futures_rule
描述: 国泰君安期货-交易日历数据表
输入: date - 交易日(近期日期)
输出: 交易所, 品种, 代码, 交易保证金比例, 涨跌停板幅度, 合约乘数, 最小变动价位, 限价单每笔最大下单手数, 特殊合约参数调整, 调整备注
```python
futures_rule_df = ak.futures_rule(date="20231205")
```

## futures_inventory_99
描述: 99期货网-大宗商品库存数据
输入: symbol - 品种中文名或英文代码(如"豆一")
输出: 日期, 收盘价, 库存
```python
futures_inventory_99_df = ak.futures_inventory_99(symbol='豆一')
```

## futures_inventory_em
描述: 东方财富网-期货库存数据(近60个交易日)
输入: symbol - 品种代码或中文名称(如"A")
输出: 日期, 库存, 增减
```python
futures_inventory_em_df = ak.futures_inventory_em(symbol="A")
```

## get_roll_yield_bar
描述: 展期收益率数据(按date/symbol/var三种类型)
输入: type_method - 类型(date/symbol/var); var - 品种代码; date - 日期; start_day - 开始日期; end_day - 结束日期
输出: 根据type_method不同返回不同字段
```python
ak.get_roll_yield_bar(type_method="date", var="RB", start_day="20191009", end_day="20191030")
```

## get_roll_yield
描述: 特定合约展期收益率
输入: date - 日期; var - 品种; symbol1 - 合约1; symbol2 - 合约2
输出: 展期收益率数据
```python
ak.get_roll_yield(date="20180718", var="IF", symbol1="IF1812", symbol2="IF1811")
```

## get_receipt
描述: 注册仓单数据
输入: start_date - 开始日期; end_date - 结束日期; vars_list - 品种列表
输出: 仓单数据
```python
ak.get_receipt(start_date="20180712", end_date="20180719", vars_list=["CU", "NI"])
```

## futures_spot_price
描述: 近期交易日基差数据
输入: date - 日期(YYYYMMDD格式)
输出: symbol, spot_price, near_contract, near_contract_price, dom_contract, dom_contract_price, near_basis, dom_basis, near_basis_rate, dom_basis_rate, date
```python
futures_spot_price_df = ak.futures_spot_price("20240430")
```

## futures_spot_price_previous
描述: 历史交易日基差数据
输入: date - 日期(YYYYMMDD格式)
输出: 商品, 现货价格, 主力合约代码, 主力合约价格, 主力合约基差, 主力合约变动百分比, 180日内主力基差最高/最低/平均
```python
futures_spot_price_previous_df = ak.futures_spot_price_previous('20240430')
```

## futures_spot_price_daily
描述: 历史某段时间的基差值
输入: start_day - 开始日期; end_day - 结束日期; vars_list - 品种列表
输出: symbol, spot_price, near_contract, near_contract_price, dom_contract, dom_contract_price, near_basis, dom_basis, near_basis_rate, dom_basis_rate, date
```python
futures_spot_price_daily_df = ak.futures_spot_price_daily(start_day="20240415", end_day="20240418", vars_list=["CU", "RB"])
```

## get_rank_sum_daily
描述: 会员持仓排名前5/10/15/20总和
输入: start_day - 开始日期; end_day - 结束日期; vars_list - 品种列表
输出: 会员持仓排名数据
```python
get_rank_sum_daily_df = ak.get_rank_sum_daily(start_day="20180718", end_day="20180719", vars_list=["IF", "C"])
```

## futures_dce_position_rank
描述: 大连商品交易所-日成交持仓排名
输入: date - 交易日; vars_list - 品种列表(如["C", "CS"])
输出: 字典(键为合约名, 值为含long_open_interest, short_open_interest, vol, symbol, variety等字段的DataFrame)
```python
futures_dce_detail_dict = ak.futures_dce_position_rank(date="20200513")
```

## futures_gfex_position_rank
描述: 广州期货交易所-日成交持仓排名
输入: date - 交易日(从20231110开始); vars_list - 品种列表(如['SI', 'LC'])
输出: 字典(键为合约名, 值为含rank, vol, long_open_interest, short_open_interest, symbol, variety等字段的DataFrame)
```python
futures_gfex_position_rank_dict = ak.futures_gfex_position_rank(date="20231113")
```

## futures_warehouse_receipt_czce
描述: 郑州商品交易所-仓单日报
输入: date - 交易日
输出: 键值对字典(键为品种代码, 值为DataFrame)
```python
futures_warehouse_receipt_czce_df = ak.futures_warehouse_receipt_czce(date="20200702")
```

## futures_warehouse_receipt_dce
描述: 大连商品交易所-仓单日报
输入: date - 交易日
输出: 品种代码, 品种名称, 仓库/分库, 昨日仓单量, 今日仓单量, 增减
```python
futures_warehouse_receipt_dce_df = ak.futures_warehouse_receipt_dce(date="20251027")
```

## futures_shfe_warehouse_receipt
描述: 上海期货交易所-仓单日报
输入: date - 交易日
输出: 键值对字典(键为品种代码, 值为DataFrame)
```python
futures_shfe_warehouse_receipt_df = ak.futures_shfe_warehouse_receipt(date="20200702")
```

## futures_gfex_warehouse_receipt
描述: 广州期货交易所-仓单日报
输入: date - 交易日
输出: 键值对字典(键为品种代码, 值为DataFrame)
```python
futures_gfex_warehouse_receipt_df = ak.futures_gfex_warehouse_receipt(date="20240122")
```

## futures_to_spot_dce
描述: 大连商品交易所-期转现统计数据
输入: date - 交易年月(如"202312")
输出: 合约代码, 期转现发生日期, 期转现数量
```python
futures_to_spot_dce_df = ak.futures_to_spot_dce(date="202312")
```

## futures_to_spot_czce
描述: 郑州商品交易所-期转现统计数据
输入: date - 交易日
输出: 合约代码, 合约数量
```python
futures_to_spot_czce_df = ak.futures_to_spot_czce(date="20231228")
```

## futures_to_spot_shfe
描述: 上海期货交易所-期转现数据
输入: date - 交易月份(如"202312")
输出: 日期, 合约, 交割量, 期转现量
```python
futures_to_spot_shfe_df = ak.futures_to_spot_shfe(date="202312")
```

## futures_delivery_dce
描述: 大连商品交易所-交割统计
输入: date - 交易月份(如"202312")
输出: 品种, 合约, 交割日期, 交割量, 交割金额
```python
futures_delivery_dce_df = ak.futures_delivery_dce(date="202312")
```

## futures_delivery_czce
描述: 郑州商品交易所-交割统计
输入: date - 交易日
输出: 品种, 交割数量, 交割额
```python
futures_delivery_czce_df = ak.futures_delivery_czce(date="20210112")
```

## futures_delivery_shfe
描述: 上海期货交易所-交割统计
输入: date - 交易月份(如"202312")
输出: 品种, 交割量-本月, 交割量-比重, 交割量-本年累计, 交割量-累计同比
```python
futures_delivery_shfe_df = ak.futures_delivery_shfe(date="202312")
```

## futures_delivery_match_dce
描述: 大连商品交易所-交割配对
输入: symbol - 交易品种(如"a")
输出: 合约号, 配对日期, 买会员号, 配对手数, 卖会员号, 交割结算价
```python
futures_delivery_match_dce_df = ak.futures_delivery_match_dce(symbol="a")
```

## futures_delivery_match_czce
描述: 郑州商品交易所-交割配对
输入: date - 交易日
输出: 卖方会员, 买方会员, 交割量, 配对日期, 合约代码
```python
futures_delivery_match_czce_df = ak.futures_delivery_match_czce(date="20210106")
```

## futures_stock_shfe_js
描述: 金十财经-上海期货交易所库存周报
输入: date - 日期(每周最后一个交易日)
输出: 商品, 期货总量, 增减, 增减幅度
```python
futures_stock_shfe_js_df = ak.futures_stock_shfe_js(date="20240419")
```

## futures_hold_pos_sina
描述: 新浪财经-期货成交持仓
输入: symbol - 类型(成交量/多单持仓/空单持仓); contract - 合约代码(如"OI2501"); date - 日期
输出: 名次, 会员简称, 成交量, 比上交易增减
```python
futures_hold_pos_sina_df = ak.futures_hold_pos_sina(symbol="成交量", contract="OI2501", date="20241016")
```

## futures_spot_sys
描述: 生意社-商品与期货-现期图
输入: symbol - 期货品种(如"铜"); indicator - 指标(市场价格/基差率/主力基差)
输出: 日期, 现货价格/基差率/主力基差, 主力合约, 最近合约
```python
futures_spot_sys_df = ak.futures_spot_sys(symbol="铜", indicator="市场价格")
```

## futures_contract_info_shfe
描述: 上海期货交易所-交易参数汇总查询
输入: date - 交易日
输出: 合约代码, 上市日, 到期日, 开始交割日, 最后交割日, 挂牌基准价, 交易日, 更新时间
```python
futures_contract_info_shfe_df = ak.futures_contract_info_shfe(date="20240513")
```

## futures_contract_info_ine
描述: 上海国际能源交易中心-交易参数汇总(期货)
输入: date - 交易日
输出: 合约代码, 上市日, 到期日, 开始交割日, 最后交割日, 挂牌基准价, 交易日
```python
futures_contract_info_ine_df = ak.futures_contract_info_ine(date="20241129")
```

## futures_contract_info_dce
描述: 大连商品交易所-合约信息
输入: 无
输出: 品种, 合约代码, 交易单位, 最小变动价位, 开始交易日, 最后交易日, 最后交割日
```python
futures_contract_info_dce_df = ak.futures_contract_info_dce()
```

## futures_contract_info_czce
描述: 郑州商品交易所-参考数据
输入: date - 交易日
输出: 产品名称, 合约代码, 产品代码, 产品类型, 交易单位, 最小变动价位, 交易手续费, 最后交易日, 最后交割日等
```python
futures_contract_info_czce_df = ak.futures_contract_info_czce(date="20240228")
```

## futures_contract_info_gfex
描述: 广州期货交易所-合约信息
输入: 无
输出: 品种, 合约代码, 交易单位, 最小变动单位, 开始交易日, 最后交易日, 最后交割日
```python
futures_contract_info_gfex_df = ak.futures_contract_info_gfex()
```

## futures_contract_info_cffex
描述: 中国金融期货交易所-交易参数
输入: date - 交易日
输出: 合约代码, 合约月份, 挂盘基准价, 上市日, 最后交易日, 涨停板幅度, 跌停板幅度, 持仓限额, 品种, 查询交易日
```python
futures_contract_info_cffex_df = ak.futures_contract_info_cffex(date="20240228")
```

## futures_zh_spot
描述: 新浪财经-期货实时行情数据
输入: subscribe_list - 合约代码; market - 市场(CF商品/FF金融); adjust - 调整(0/1)
输出: symbol, time, open, high, low, current_price, bid_price, ask_price, buy_vol, sell_vol, hold, volume, avg_price, last_close, last_settle_price
```python
futures_zh_spot_df = ak.futures_zh_spot(symbol='V2205', market="CF", adjust='0')
```

## futures_zh_realtime
描述: 新浪财经-期货实时行情数据(按品种)
输入: symbol - 品种名称(如"白糖")
输出: symbol, exchange, name, trade, settlement, presettlement, open, high, low, close, bidprice1, askprice1, volume, position, ticktime, changepercent
```python
futures_zh_realtime_df = ak.futures_zh_realtime(symbol="白糖")
```

## futures_zh_minute_sina
描述: 新浪财经-期货分时数据
输入: symbol - 合约代码(如"IF2008"); period - 周期(1/5/15/30/60分钟)
输出: datetime, open, high, low, close, volume, hold
```python
futures_zh_minute_sina_df = ak.futures_zh_minute_sina(symbol="RB0", period="1")
```

## futures_hist_em
描述: 东方财富网-期货行情数据
输入: symbol - 合约名称(如"热卷主连"); period - 周期(daily/weekly/monthly); start_date - 开始日期; end_date - 结束日期
输出: 时间, 开盘, 最高, 最低, 收盘, 涨跌, 涨跌幅, 成交量, 成交额, 持仓量
```python
futures_hist_em_df = ak.futures_hist_em(symbol="热卷主连", period="daily")
```

## futures_zh_daily_sina
描述: 新浪财经-期货日频数据
输入: symbol - 合约代码(如"RB0"为连续合约)
输出: date, open, high, low, close, volume, hold, settle
```python
futures_zh_daily_sina_df = ak.futures_zh_daily_sina(symbol="RB0")
```

## get_futures_daily
描述: 各交易所历史行情数据
输入: start_date - 开始日期; end_date - 结束日期; market - 交易所(CFFEX/INE/CZCE/DCE/SHFE/GFEX)
输出: symbol, date, open, high, low, close, volume, open_interest, turnover, settle, pre_settle, variety
```python
get_futures_daily_df = ak.get_futures_daily(start_date="20200701", end_date="20200716", market="DCE")
```

## futures_settle
描述: 各交易所结算参数数据(保证金、手续费、涨跌停板等)
输入: date - 结算日期; market - 交易所(CFFEX/INE/CZCE/SHFE/GFEX)
输出: date, symbol, variety, settle_price, long_margin_ratio, short_margin_ratio, trade_fee_ratio, close_today_fee_ratio, limit_ratio, position_limit等
```python
futures_settle_df = ak.futures_settle(date="20250117", market="INE")
```

## futures_hq_subscribe_exchange_symbol
描述: 新浪财经-外盘商品期货品种代码表
输入: 无
输出: symbol, code
```python
futures_hq_subscribe_exchange_symbol_df = ak.futures_hq_subscribe_exchange_symbol()
```

## futures_foreign_commodity_realtime
描述: 新浪财经-外盘商品期货实时行情
输入: symbol - 合约代码(字符串或列表)
输出: 名称, 最新价, 人民币报价, 涨跌额, 涨跌幅, 开盘价, 最高价, 最低价, 昨日结算价, 持仓量, 买价, 卖价, 行情时间, 日期
```python
futures_foreign_commodity_realtime_df = ak.futures_foreign_commodity_realtime(symbol='CT,NID')
```

## futures_global_spot_em
描述: 东方财富网-国际期货实时行情数据
输入: 无
输出: 序号, 代码, 名称, 最新价, 涨跌额, 涨跌幅, 今开, 最高, 最低, 昨结, 成交量, 买盘, 卖盘, 持仓量
```python
futures_global_spot_em_df = ak.futures_global_spot_em()
```

## futures_global_hist_em
描述: 东方财富网-国际期货历史行情数据
输入: symbol - 品种代码(如"HG00Y")
输出: 日期, 代码, 名称, 开盘, 最新价, 最高, 最低, 总量, 涨幅, 持仓, 日增
```python
futures_global_hist_em_df = ak.futures_global_hist_em(symbol="HG00Y")
```

## futures_foreign_hist
描述: 新浪财经-期货外盘历史行情数据
输入: symbol - 外盘期货代码(如"ZSD")
输出: date, open, high, low, close, volume
```python
futures_foreign_hist_df = ak.futures_foreign_hist(symbol="ZSD")
```

## futures_foreign_detail
描述: 新浪财经-期货外盘合约详情
输入: symbol - 外盘期货代码(如"ZSD")
输出: item, value(交易品种, 最小变动价位, 交易时间, 交易代码, 交易单位等)
```python
futures_foreign_detail_df = ak.futures_foreign_detail(symbol="ZSD")
```

## futures_settlement_price_sgx
描述: 新加坡交易所-历史结算价格(需代理访问)
输入: date - 交易日
输出: DATE, COM, COM_MM, COM_YY, OPEN, HIGH, LOW, CLOSE, SETTLE, VOLUME, OINT, SERIES
```python
futures_settlement_price_sgx_df = ak.futures_settlement_price_sgx(date="20231108")
```

## futures_main_sina
描述: 新浪财经-期货主力连续合约历史数据
输入: symbol - 连续合约代码(如"IF0"); start_date - 开始日期; end_date - 结束日期
输出: 日期, 开盘价, 最高价, 最低价, 收盘价, 成交量, 持仓量, 动态结算价
```python
futures_main_sina_hist = ak.futures_main_sina(symbol="V0", start_date="20200101", end_date="20220101")
```

## futures_contract_detail
描述: 新浪财经-期货合约详情数据
输入: symbol - 合约代码(如'AP2101')
输出: item, value
```python
futures_contract_detail_df = ak.futures_contract_detail(symbol='V2001')
```

## futures_contract_detail_em
描述: 东方财富-期货合约详情数据
输入: symbol - 合约标识(如'v2602F')
输出: item, value
```python
futures_contract_detail_em_df = ak.futures_contract_detail_em(symbol="v2603F")
```

## futures_index_ccidx
描述: 中证商品指数
输入: symbol - 指数名称(中证商品期货指数/中证商品期货价格指数)
输出: 日期, 指数代码, 收盘点位, 结算点位, 涨跌, 涨跌幅
```python
futures_index_ccidx_df = ak.futures_index_ccidx(symbol="中证商品期货指数")
```

## futures_spot_stock
描述: 东方财富网-现货与股票
输入: symbol - 板块(能源/化工/塑料/纺织/有色/钢铁/建材/农副)
输出: 商品名称, 近5月~近1月, 最新价, 近半年涨跌幅, 生产商, 下游用户
```python
futures_spot_stock_df = ak.futures_spot_stock(symbol="能源")
```

## futures_comex_inventory
描述: 东方财富网-COMEX库存数据
输入: symbol - 品种(黄金/白银)
输出: 序号, 日期, COMEX库存量-吨, COMEX库存量-盎司
```python
futures_comex_inventory_df = ak.futures_comex_inventory(symbol="黄金")
```

## futures_hog_core
描述: 玄田数据-核心数据(生猪价格)
输入: symbol - 类型(外三元/内三元/土杂猪)
输出: date, value
```python
futures_hog_core_df = ak.futures_hog_core(symbol="外三元")
```

## futures_hog_cost
描述: 玄田数据-成本维度
输入: symbol - 类型(玉米/豆粕/二元母猪价格/仔猪价格)
输出: date, value
```python
futures_hog_cost_df = ak.futures_hog_cost(symbol="玉米")
```

## futures_hog_supply
描述: 玄田数据-供应维度
输入: symbol - 类型(猪肉批发价/储备冻猪肉/饲料原料数据/白条肉/生猪产能/育肥猪/肉类价格指数/猪粮比价)
输出: date, value
```python
futures_hog_supply_df = ak.futures_hog_supply(symbol="猪肉批发价")
```

## index_hog_spot_price
描述: 行情宝-生猪市场价格指数
输入: 无
输出: 日期, 指数, 4个月均线, 6个月均线, 12个月均线, 预售均价, 成交均价, 成交均重
```python
index_hog_spot_price_df = ak.index_hog_spot_price()
```

## futures_news_shmet
描述: 上海金属网-快讯
输入: symbol - 类型(全部/要闻/VIP/财经/铜/铝/铅/锌/镍/锡/贵金属/小金属)
输出: 发布时间, 内容
```python
futures_news_shmet_df = ak.futures_news_shmet(symbol="铜")
```
