# 美国宏观数据

```python
import akshare as ak
```

## 美国GDP
描述: 美国国内生产总值(GDP)报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_gdp_monthly()
```

## 美国CPI月率
描述: 美国CPI月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_cpi_monthly()
```

## 美国CPI年率
描述: 美国CPI年率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_cpi_yoy()
```

## 美国核心CPI月率
描述: 美国核心CPI月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_core_cpi_monthly()
```

## 美国个人支出月率
描述: 美国个人支出月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_personal_spending()
```

## 美国零售销售月率
描述: 美国零售销售月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_retail_sales()
```

## 美国进口物价指数月率
描述: 美国进口物价指数月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_import_price()
```

## 美国出口物价指数月率
描述: 美国出口物价指数月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_export_price()
```

## 美国LMCI
描述: 美国劳动力市场状况指数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_lmci()
```

## 美国失业率
描述: 美国失业率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_unemployment_rate()
```

## 美国挑战者企业裁员人数
描述: 美国挑战者企业裁员人数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_job_cuts()
```

## 美国非农就业人数
描述: 美国非农就业人数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_non_farm()
```

## 美国ADP就业人数
描述: 美国ADP就业人数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_adp_employment()
```

## 美国核心PCE物价指数年率
描述: 美国核心PCE物价指数年率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_core_pce_price()
```

## 美国实际个人消费支出季率
描述: 美国实际个人消费支出季率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_real_consumer_spending()
```

## 美国贸易帐
描述: 美国贸易帐报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_trade_balance()
```

## 美国经常帐
描述: 美国经常帐报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_current_account()
```

## 美国贝克休斯钻井平台
描述: 美国贝克休斯钻井平台报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_rig_count()
```

## 美国PPI
描述: 美国PPI报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_ppi()
```

## 美国核心PPI
描述: 美国核心PPI报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_core_ppi()
```

## 美国API原油库存
描述: 美国API原油库存报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_api_crude_stock()
```

## 美国PMI
描述: 美国PMI报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_pmi()
```

## 美国ISM制造业PMI
描述: 美国ISM制造业PMI报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_ism_pmi()
```

## 美国工业产出月率
描述: 美国工业产出月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_industrial_production()
```

## 美国耐用品订单月率
描述: 美国耐用品订单月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_durable_goods_orders()
```

## 美国工厂订单月率
描述: 美国工厂订单月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_factory_orders()
```

## 美国服务业PMI
描述: 美国服务业PMI报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_services_pmi()
```

## 美国商业库存月率
描述: 美国商业库存月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_business_inventories()
```

## 美国ISM非制造业PMI
描述: 美国ISM非制造业PMI报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_ism_non_pmi()
```

## 美国NAHB房产市场指数
描述: 美国NAHB房产市场指数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_nahb_house_market_index()
```

## 美国新屋开工
描述: 美国新屋开工报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_house_starts()
```

## 美国新屋销售
描述: 美国新屋销售报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_new_home_sales()
```

## 美国营建许可
描述: 美国营建许可报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_building_permits()
```

## 美国成屋销售
描述: 美国成屋销售报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_exist_home_sales()
```

## 美国房价指数
描述: 美国房价指数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_house_price_index()
```

## 美国S&P/CS20座大城市房价指数
描述: 美国S&P/CS20座大城市房价指数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_spcs20()
```

## 美国成屋签约销售指数
描述: 美国成屋签约销售指数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_pending_home_sales()
```

## 美国成屋签约销售指数月率
描述: 美国成屋签约销售指数月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_phs()
```

## 美国谘商会消费者信心指数
描述: 美国谘商会消费者信心指数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_cb_consumer_confidence()
```

## 美国NFIB小型企业信心指数
描述: 美国NFIB小型企业信心指数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_nfib_small_business()
```

## 美国密歇根大学消费者信心指数
描述: 美国密歇根大学消费者信心指数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_michigan_consumer_sentiment()
```

## 美国EIA原油库存
描述: 美国EIA原油库存报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_eia_crude_rate()
```

## 美国初请失业金人数
描述: 美国初请失业金人数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_initial_jobless()
```

## 美国国内原油库存
描述: 美国国内原油库存报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_crude_inner()
```

## 美国CFTC外汇持仓
描述: 美国CFTC外汇持仓报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_cftc_nc_holding()
```

## 美国CFTC商品持仓
描述: 美国CFTC商品持仓报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_cftc_c_holding()
```

## 美国CFTC商品类外汇持仓
描述: 美国CFTC商品类外汇持仓报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_cftc_merchant_currency_holding()
```

## 美国CFTC商品类商品持仓
描述: 美国CFTC商品类商品持仓报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_cftc_merchant_goods_holding()
```

## 美国CME商品持仓
描述: 美国CME商品持仓报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_usa_cme_merchant_goods_holding()
```
