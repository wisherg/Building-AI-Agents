# 欧元区与欧洲宏观数据

```python
import akshare as ak
```

## 欧元区季度GDP年率
描述: 欧元区季度GDP年率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_gdp_yoy()
```

## 欧元区CPI月率
描述: 欧元区CPI月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_cpi_mom()
```

## 欧元区CPI年率
描述: 欧元区CPI年率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_cpi_yoy()
```

## 欧元区PPI月率
描述: 欧元区PPI月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_ppi_mom()
```

## 欧元区零售销售月率
描述: 欧元区零售销售月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_retail_sales_mom()
```

## 欧元区就业人数变化季率
描述: 欧元区就业人数变化季率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_employment_change_qoq()
```

## 欧元区失业率月率
描述: 欧元区失业率月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_unemployment_rate_mom()
```

## 欧元区贸易帐
描述: 欧元区贸易帐报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_trade_balance()
```

## 欧元区经常帐月率
描述: 欧元区经常帐月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_current_account_mom()
```

## 欧元区工业产出月率
描述: 欧元区工业产出月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_industrial_production_mom()
```

## 欧元区制造业PMI
描述: 欧元区制造业PMI报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_manufacturing_pmi()
```

## 欧元区服务业PMI
描述: 欧元区服务业PMI报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_services_pmi()
```

## 欧元区ZEW经济景气指数
描述: 欧元区ZEW经济景气指数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_zew_economic_sentiment()
```

## 欧元区Sentix投资者信心指数
描述: 欧元区Sentix投资者信心指数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_euro_sentix_investor_confidence()
```

## 德国IFO商业景气指数
描述: 德国IFO商业景气指数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_germany_ifo()
```

## 德国CPI月率
描述: 德国CPI月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_germany_cpi_monthly()
```

## 德国CPI年率
描述: 德国CPI年率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_germany_cpi_yearly()
```

## 德国贸易帐
描述: 德国贸易帐报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_germany_trade_adjusted()
```

## 德国GDP
描述: 德国GDP报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_germany_gdp()
```

## 德国零售销售月率
描述: 德国零售销售月率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_germany_retail_sale_monthly()
```

## 德国零售销售年率
描述: 德国零售销售年率报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_germany_retail_sale_yearly()
```

## 德国ZEW经济景气指数
描述: 德国ZEW经济景气指数报告
输入: 无
输出: 商品, 日期, 今值, 预测值, 前值

```python
df = ak.macro_germany_zew()
```

## 瑞士SVME采购经理人指数
描述: 东方财富-瑞士-SVME采购经理人指数
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_swiss_svme()
```

## 瑞士贸易帐
描述: 东方财富-瑞士-贸易帐
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_swiss_trade()
```

## 瑞士CPI年率
描述: 东方财富-瑞士-CPI年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_swiss_cpi_yearly()
```

## 瑞士GDP季率
描述: 东方财富-瑞士-GDP季率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_swiss_gdp_quarterly()
```

## 瑞士GDP年率
描述: 东方财富-瑞士-GDP年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_swiss_gbd_yearly()
```

## 瑞士央行利率决议
描述: 东方财富-瑞士-央行公布利率决议
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_swiss_gbd_bank_rate()
```

## 伦敦金属交易所持仓
描述: 伦敦金属交易所持仓报告
输入: 无
输出: 根据具体品种返回持仓数据

```python
df = ak.macro_euro_lme_holding()
```

## 伦敦金属交易所库存
描述: 伦敦金属交易所库存报告
输入: 无
输出: 根据具体品种返回库存数据

```python
df = ak.macro_euro_lme_stock()
```
