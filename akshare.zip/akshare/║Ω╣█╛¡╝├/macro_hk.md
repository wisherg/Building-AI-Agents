# 中国香港宏观数据

```python
import akshare as ak
```

## 人民币香港银行同业拆息
描述: 香港同业拆借报告
输入: 无
输出: 日期, O/N-定价, O/N-涨跌幅, 1W-定价, 1W-涨跌幅, 2W-定价, 2W-涨跌幅, 1M-定价, 1M-涨跌幅, 3M-定价, 3M-涨跌幅, 6M-定价, 6M-涨跌幅, 9M-定价, 9M-涨跌幅, 1Y-定价, 1Y-涨跌幅

```python
df = ak.macro_china_hk_market_info()
```

## 消费者物价指数
描述: 东方财富-中国香港-消费者物价指数
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_china_hk_cpi()
```

## 消费者物价指数年率
描述: 东方财富-中国香港-消费者物价指数年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_china_hk_cpi_ratio()
```

## 失业率
描述: 东方财富-中国香港-失业率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_china_hk_rate_of_unemployment()
```

## GDP
描述: 东方财富-中国香港-香港GDP
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_china_hk_gbp()
```

## GDP同比
描述: 东方财富-中国香港-香港GDP同比
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_china_hk_gbp_ratio()
```

## 香港楼宇买卖合约数量
描述: 东方财富-中国香港-香港楼宇买卖合约数量
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_china_hk_building_volume()
```

## 香港楼宇买卖合约成交金额
描述: 东方财富-中国香港-香港楼宇买卖合约成交金额
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_china_hk_building_amount()
```

## 香港商品贸易差额年率
描述: 东方财富-中国香港-香港商品贸易差额年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_china_hk_trade_diff_ratio()
```

## 香港制造业PPI年率
描述: 东方财富-中国香港-香港制造业PPI年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_china_hk_ppi()
```
