# 亚太宏观数据

```python
import akshare as ak
```

## 日本央行利率决议
描述: 东方财富-日本-央行公布利率决议
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_japan_bank_rate()
```

## 日本CPI年率
描述: 东方财富-日本-CPI年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_japan_cpi_yearly()
```

## 日本核心CPI年率
描述: 东方财富-日本-核心CPI年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_japan_core_cpi_yearly()
```

## 日本失业率
描述: 东方财富-日本-失业率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_japan_unemployment_rate()
```

## 日本领先指标
描述: 东方财富-日本-领先指标
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_japan_head_indicator()
```

## 英国Halifax房价指数月率
描述: 东方财富-英国-Halifax房价指数月率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_halifax_monthly()
```

## 英国Halifax房价指数年率
描述: 东方财富-英国-Halifax房价指数年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_halifax_yearly()
```

## 英国贸易帐
描述: 东方财富-英国-贸易帐
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_trade()
```

## 英国央行利率决议
描述: 东方财富-英国-央行公布利率决议
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_bank_rate()
```

## 英国核心CPI年率
描述: 东方财富-英国-核心CPI年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_core_cpi_yearly()
```

## 英国核心CPI月率
描述: 东方财富-英国-核心CPI月率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_core_cpi_monthly()
```

## 英国CPI年率
描述: 东方财富-英国-CPI年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_cpi_yearly()
```

## 英国CPI月率
描述: 东方财富-英国-CPI月率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_cpi_monthly()
```

## 英国零售销售月率
描述: 东方财富-英国-零售销售月率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_retail_monthly()
```

## 英国零售销售年率
描述: 东方财富-英国-零售销售年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_retail_yearly()
```

## 英国Rightmove房价指数年率
描述: 东方财富-英国-Rightmove房价指数年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_rightmove_yearly()
```

## 英国Rightmove房价指数月率
描述: 东方财富-英国-Rightmove房价指数月率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_rightmove_monthly()
```

## 英国GDP季率
描述: 东方财富-英国-GDP季率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_gdp_quarterly()
```

## 英国GDP年率
描述: 东方财富-英国-GDP年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_gdp_yearly()
```

## 英国失业率
描述: 东方财富-英国-失业率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_uk_unemployment_rate()
```

## 澳大利亚零售销售月率
描述: 东方财富-澳大利亚-零售销售月率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_australia_retail_rate_monthly()
```

## 澳大利亚贸易帐
描述: 东方财富-澳大利亚-贸易帐
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_australia_trade()
```

## 澳大利亚失业率
描述: 东方财富-澳大利亚-失业率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_australia_unemployment_rate()
```

## 澳大利亚PPI季率
描述: 东方财富-澳大利亚-PPI季率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_australia_ppi_quarterly()
```

## 澳大利亚CPI季率
描述: 东方财富-澳大利亚-CPI季率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_australia_cpi_quarterly()
```

## 澳大利亚消费者物价指数年率
描述: 东方财富-澳大利亚-消费者物价指数年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_australia_cpi_yearly()
```

## 澳大利亚央行利率决议
描述: 东方财富-澳大利亚-央行公布利率决议
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_australia_bank_rate()
```

## 加拿大新屋开工
描述: 东方财富-加拿大-新屋开工
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_canada_new_house_rate()
```

## 加拿大失业率
描述: 东方财富-加拿大-失业率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_canada_unemployment_rate()
```

## 加拿大贸易帐
描述: 东方财富-加拿大-贸易帐
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_canada_trade()
```

## 加拿大零售销售月率
描述: 东方财富-加拿大-零售销售月率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_canada_retail_rate_monthly()
```

## 加拿大央行利率决议
描述: 东方财富-加拿大-央行公布利率决议
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_canada_bank_rate()
```

## 加拿大核心CPI年率
描述: 东方财富-加拿大-核心消费者物价指数年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_canada_core_cpi_yearly()
```

## 加拿大核心CPI月率
描述: 东方财富-加拿大-核心消费者物价指数月率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_canada_core_cpi_monthly()
```

## 加拿大CPI年率
描述: 东方财富-加拿大-消费者物价指数年率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_canada_cpi_yearly()
```

## 加拿大CPI月率
描述: 东方财富-加拿大-消费者物价指数月率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_canada_cpi_monthly()
```

## 加拿大GDP月率
描述: 东方财富-加拿大-GDP月率
输入: 无
输出: 时间, 前值, 现值, 发布日期

```python
df = ak.macro_canada_gdp_monthly()
```
