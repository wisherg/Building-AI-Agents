# QDII数据

```python
import akshare as ak
```

## qdii_e_comm_jsl

描述: 集思录-T+0 QDII-欧美市场-欧美商品

输入: cookie - 用户登录后的cookie

输出: 代码, 名称, 现价, 涨幅, 成交(万元), 场内份额(万份), 场内新增(万份), T-2净值, 净值日期, T-1估值, 估值日期, T-1溢价率, 相关标的, T-1指数涨幅, 申购费, 赎回费, 托管费, 基金公司

```python
qdii_e_comm_jsl_df = ak.qdii_e_comm_jsl()
print(qdii_e_comm_jsl_df)
```

## qdii_a_index_jsl

描述: 集思录-T+0 QDII-亚洲市场-亚洲指数

输入: cookie - 用户登录后的cookie

输出: 代码, 名称, 现价, 涨幅, 成交(万元), 场内份额(万份), 场内新增(万份), 净值, 净值日期, 估值, 溢价率, 相关标的, 指数涨幅, 申购费, 赎回费, 托管费, 基金公司

```python
qdii_a_index_jsl_df = ak.qdii_a_index_jsl()
print(qdii_a_index_jsl_df)
```
