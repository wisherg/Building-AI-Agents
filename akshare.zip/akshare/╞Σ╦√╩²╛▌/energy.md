# 能源数据

```python
import akshare as ak
```

## energy_carbon_bj

描述: 北京市碳排放权电子交易平台-北京市碳排放权公开交易行情

输入: 无

输出: 日期, 成交量(吨), 成交均价(元/吨), 成交额(元), 成交单位

```python
energy_carbon_bj_df = ak.energy_carbon_bj()
print(energy_carbon_bj_df)
```

## energy_carbon_sz

描述: 深圳碳排放交易所-国内碳情

输入: 无

输出: 交易日期, 市场交易指数, 开盘价, 最高价, 最低价, 成交均价, 收盘价, 成交量, 成交额

```python
energy_carbon_sz_df = ak.energy_carbon_sz()
print(energy_carbon_sz_df)
```

## energy_carbon_eu

描述: 深圳碳排放交易所-国际碳情(2018-03-13至2020-04-29)

输入: 无

输出: 交易日期, 市场交易指数, 开盘价, 最高价, 最低价, 成交均价, 收盘价, 成交量, 成交额

```python
energy_carbon_eu_df = ak.energy_carbon_eu()
print(energy_carbon_eu_df)
```

## energy_carbon_hb

描述: 湖北碳排放权交易中心-碳排放权交易数据(2014-04-02至今)

输入: 无

输出: 日期, 成交价, 成交量, 最新, 涨跌

```python
energy_carbon_hb_df = ak.energy_carbon_hb()
print(energy_carbon_hb_df)
```

## energy_carbon_gz

描述: 广州碳排放权交易中心-行情信息(2013-12-19至今)

输入: 无

输出: 日期, 品种, 开盘价, 收盘价, 最高价, 最低价, 涨跌, 涨跌幅(%), 成交数量, 成交金额

```python
energy_carbon_gz_df = ak.energy_carbon_gz()
print(energy_carbon_gz_df)
```

## energy_oil_hist

描述: 东方财富-中国油价-汽柴油历史调价信息

输入: 无

输出: 调整日期, 汽油价格(元/吨), 柴油价格(元/吨), 汽油涨幅(元/吨), 柴油涨幅(元/吨)

```python
energy_oil_hist_df = ak.energy_oil_hist()
print(energy_oil_hist_df)
```

## energy_oil_detail

描述: 东方财富-中国油价-地区油价

输入: date - 调价日期, 如"20240118"; 通过energy_oil_hist()获取历史调价日期

输出: 日期, 地区, V_0(0#柴油价格元/升), V_92, V_95, V_89, ZDE_0(0#柴油涨幅元/升), ZDE_92, ZDE_95, ZDE_89, QE_0(上一次0#柴油价格), QE_92, QE_95, QE_89

```python
energy_oil_detail_df = ak.energy_oil_detail(date="20240118")
print(energy_oil_detail_df)
```
