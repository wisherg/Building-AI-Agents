# 自然语言处理数据

```python
import akshare as ak
```

## nlp_ownthink

描述: 思知-知识图谱查询接口

输入: word - 查询词, 如"人工智能"; indicator - 查询类型: "entity"实体名/"desc"简介/"avg"属性值/"tag"标签

输出: entity返回实体名; desc返回简介文本; avg返回DataFrame(字段,值); tag返回标签列表

```python
nlp_ownthink_df = ak.nlp_ownthink(word="人工智能", indicator="entity")
print(nlp_ownthink_df)

nlp_ownthink_df = ak.nlp_ownthink(word="人工智能", indicator="desc")
print(nlp_ownthink_df)

nlp_ownthink_df = ak.nlp_ownthink(word="人工智能", indicator="avg")
print(nlp_ownthink_df)

nlp_ownthink_df = ak.nlp_ownthink(word="人工智能", indicator="tag")
print(nlp_ownthink_df)
```

## nlp_answer

描述: 思知-对话机器人智能问答接口

输入: question - 问题, 如"姚明的身高"

输出: 答案文本

```python
nlp_answer_df = ak.nlp_answer(question="姚明的身高")
print(nlp_answer_df)
```
