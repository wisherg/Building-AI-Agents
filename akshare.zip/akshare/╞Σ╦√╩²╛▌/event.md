# 迁徙数据

```python
import akshare as ak
```

## migration_area_baidu

描述: 百度地图慧眼-百度迁徙-迁入/迁出地数据(前100个城市)

输入: area - 省份或城市全称, 如"重庆市"; indicator - "move_in"迁入/"move_out"迁出; date - 日期如"20230922"(需滞后一天)

输出: city_name, province_name, value(迁徙规模比例)

```python
migration_area_baidu_df = ak.migration_area_baidu(area="重庆市", indicator="move_in", date="20230922")
print(migration_area_baidu_df)
```

## migration_scale_baidu

描述: 百度地图慧眼-百度迁徙-迁徙规模

输入: area - 省份或城市全称, 如"广州市"; indicator - "move_in"迁入/"move_out"迁出

输出: 日期, 迁徙规模指数

```python
migration_scale_baidu_df = ak.migration_scale_baidu(area="广州市", indicator="move_in")
print(migration_scale_baidu_df)
```
