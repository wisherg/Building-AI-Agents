# 波动率与多因子数据

```python
import akshare as ak
```

## article_rlab_rv

描述: Risk-Lab 已实现波动率数据

输入: symbol - 指数代码, 如"39693"; help(article_rlab_rv)查看可选值

输出: index(日期), data(波动率数据)

```python
article_rlab_rv_df = ak.article_rlab_rv(symbol="39693")
print(article_rlab_rv_df)
```

## article_ff_crr

描述: Fama-French Current Research Returns 多因子数据

输入: 无

输出: item, 动态日期列(如September 2019), Last 3 Months, Last 12 Months

```python
article_ff_crr_df = ak.article_ff_crr()
print(article_ff_crr_df)
```

## article_epu_index

描述: 国家或地区的经济政策不确定性(EPU)数据

输入: symbol - 国家/地区英文名; 可选: Global, Australia, Canada, China, Europe, Germany, Hong Kong, Ireland, Japan, Mexico, Russia, Spain, UK, USA, Brazil, Chile, Colombia, France, Greece, India, Italy, South Korea, Netherlands, Singapore, Sweden

输出: year, month, {国家名}_Policy_Index

```python
article_epu_index_df = ak.article_epu_index(symbol="China")
print(article_epu_index_df)
```
