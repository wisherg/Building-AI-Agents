# 加密货币数据

```python
import akshare as ak
```

## crypto_bitcoin_hold_report

描述: 比特币持仓报告

输入: 无

输出: 代码, 公司名称-英文, 公司名称-中文, 国家/地区, 市值, 比特币占市值比重, 持仓成本, 持仓占比, 持仓量, 当日持仓市值, 查询日期, 公告链接, 分类, 倍数

```python
crypto_bitcoin_hold_report_df = ak.crypto_bitcoin_hold_report()
print(crypto_bitcoin_hold_report_df)
```

## crypto_bitcoin_cme

描述: 芝加哥商业交易所-比特币成交量报告

输入: date - 交易日, 如"20230830"

输出: 商品, 类型, 电子交易合约, 场内成交合约, 场外成交合约, 成交量, 未平仓合约, 持仓变化

```python
crypto_bitcoin_cme_df = ak.crypto_bitcoin_cme(date="20230830")
print(crypto_bitcoin_cme_df)
```
