# 工具箱

```python
import akshare as ak
```

## tool_trade_date_hist_sina

描述: 新浪财经-股票交易日历数据(1990-12-19至2024-12-31)

输入: 无

输出: trade_date(交易日)

```python
tool_trade_date_hist_sina_df = ak.tool_trade_date_hist_sina()
print(tool_trade_date_hist_sina_df)
```
