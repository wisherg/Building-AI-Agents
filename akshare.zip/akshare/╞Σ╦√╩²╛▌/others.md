# 另类数据

```python
import akshare as ak
```

## car_market_total_cpca

描述: 乘联会-统计数据-总体市场

输入: symbol - {"狭义乘用车", "广义乘用车"}; indicator - {"产量", "批发", "零售", "出口"}

输出: 月份, {前一年}年(万辆), {当前年}年(万辆)

```python
car_market_total_cpca_df = ak.car_market_total_cpca(symbol="狭义乘用车", indicator="产量")
print(car_market_total_cpca_df)
```

## car_market_man_rank_cpca

描述: 乘联会-统计数据-厂商排名

输入: symbol - {"狭义乘用车-单月", "狭义乘用车-累计", "广义乘用车-单月", "广义乘用车-累计"}; indicator - {"批发", "零售"}

输出: 厂商, {前一年月份}, {当前年月份}

```python
car_market_man_rank_cpca_df = ak.car_market_man_rank_cpca(symbol="狭义乘用车-单月", indicator="批发")
print(car_market_man_rank_cpca_df)
```

## car_market_cate_cpca

描述: 乘联会-统计数据-车型大类

输入: symbol - {"轿车", "MPV", "SUV", "占比"}; indicator - {"批发", "零售"}

输出: 月份, {前一年}年(万辆), {当前年}年(万辆)

```python
car_market_cate_cpca_df = ak.car_market_cate_cpca(symbol="轿车", indicator="批发")
print(car_market_cate_cpca_df)
```

## car_market_country_cpca

描述: 乘联会-统计数据-国别细分市场

输入: 无

输出: 月份, 自主, 德系, 日系, 法系, 美系, 韩系, 其他欧系(万辆)

```python
car_market_country_cpca_df = ak.car_market_country_cpca()
print(car_market_country_cpca_df)
```

## car_market_segment_cpca

描述: 乘联会-统计数据-级别细分市场

输入: symbol - {"轿车", "MPV", "SUV"}

输出: 月份, A00, A0, A, B, C(万辆)

```python
car_market_segment_cpca_df = ak.car_market_segment_cpca(symbol="轿车")
print(car_market_segment_cpca_df)
```

## car_market_fuel_cpca

描述: 乘联会-统计数据-新能源细分市场

输入: symbol - {"整体市场", "销量占比-PHEV-BEV", "销量占比-ICE-NEV"}

输出: 月份, {前一年}年(万辆), {当前年}年(万辆)

```python
car_market_fuel_cpca_df = ak.car_market_fuel_cpca()
print(car_market_fuel_cpca_df)
```

## car_sale_rank_gasgoo

描述: 盖世汽车资讯-汽车销量排行榜

输入: symbol - {"车企榜", "品牌榜", "车型榜"}; date - 月份如"202311"

输出: 品牌/车型/厂商, {年-月}, 月同比(%), 月环比(%), {年}-1到{当前年}, {前一年}-1到{当前年}, {前二年}-1到{当前年}

```python
car_sale_rank_gasgoo_df = ak.car_sale_rank_gasgoo(symbol="品牌榜", date="202311")
print(car_sale_rank_gasgoo_df)
```

## news_cctv

描述: 新闻联播文字稿(20160330至今)

输入: date - 日期如"20240424"

输出: date(新闻日期), title(新闻标题), content(新闻内容)

```python
news_cctv_df = ak.news_cctv(date="20240424")
print(news_cctv_df)
```

## sunrise_daily

描述: 中国各大城市-日出和日落时间(单日, 19990101至今, 建议代理)

输入: date - 日期如"20240428"; city - 城市拼音如"beijing"

输出: date, Sunrise, Sunset, Length, Difference, Start(天文曙暮光), End, Start.1(航海曙暮光), End.1, Start.2(民用曙暮光), End.2, Time(太阳正午), Mil. km

```python
sunrise_daily_df = ak.sunrise_daily(date="20240428", city="beijing")
print(sunrise_daily_df)
```

## sunrise_monthly

描述: 中国各大城市-日出和日落时间(整月, 19990101至今, 建议代理)

输入: date - 日期如"20240428"; city - 城市拼音如"beijing"

输出: date, feb(月份简称), Sunrise, Sunset, Length, Difference, Start, End, Start.1, End.1, Start.2, End.2, Time, Mil. km

```python
sunrise_monthly_df = ak.sunrise_monthly(date="20240428", city="beijing")
print(sunrise_monthly_df)
```

## air_quality_hebei

描述: 河北省实时空气质量数据

输入: 无

输出: 城市, 区域, 监测点, 时间, AQI, 空气质量等级, 首要污染物, 经度, 纬度, PM10_IAQI, PM10_浓度, PM2.5_IAQI, PM2.5_浓度, 一氧化碳_IAQI, 一氧化碳_浓度, 二氧化氮_IAQI, 二氧化氮_浓度, 二氧化硫_IAQI, 二氧化硫_浓度, 臭氧1小时_IAQI, 臭氧1小时_浓度, 臭氧8小时_IAQI, 臭氧8小时_浓度

```python
air_quality_hebei_df = ak.air_quality_hebei()
print(air_quality_hebei_df)
```

## air_city_table

描述: 所有能获取空气质量数据的城市表

输入: 无

输出: 序号, 省份, 城市, AQI, 空气质量, PM2.5浓度, 首要污染物

```python
air_city_table_df = ak.air_city_table()
print(air_city_table_df)
```

## air_quality_hist

描述: 指定城市和频率的空气质量历史数据

输入: city - 城市如"北京"; period - "hour"/"day"/"month"; start_date - 如"20200320"; end_date - 如"20200427"

输出: time, aqi, pm2_5, pm10, co, no2, o3, so2, complexindex, rank, primary_pollutant, temp, humi, windlevel, winddirection, weather

```python
air_quality_hist_df = ak.air_quality_hist(city="北京", period="day", start_date="20200320", end_date="20200427")
print(air_quality_hist_df)
```

## air_quality_rank

描述: 168个城市空气质量排名

输入: date - ""实时/"20200312"日/"202003"月/"2019"年

输出: 降序(排名), 省份, 城市, AQI/综合指数, 空气质量/最大指数, PM2.5浓度/首要污染物

```python
air_quality_rank_df = ak.air_quality_rank(date="")
print(air_quality_rank_df)
```

## air_quality_watch_point

描述: 每个城市所有空气质量监测点数据

输入: city - 城市如"杭州"; start_date - 如"2018-01-01"; end_date - 如"2020-04-27"

输出: pointname, aqi, pm2_5, pm10, no2, so2, o3, co

```python
air_quality_watch_point_df = ak.air_quality_watch_point(city="杭州", start_date="2018-01-01", end_date="2020-04-27")
print(air_quality_watch_point_df)
```

## fortune_rank

描述: 财富世界500强公司排行榜

输入: year - 年份如"2023"

输出: 排名, 公司名称(中文), 国家, 关键数据等(以当年数据为准)

```python
fortune_rank_df = ak.fortune_rank(year="2023")
print(fortune_rank_df)
```

## forbes_rank

描述: 福布斯中国榜单数据(87个指标)

输入: symbol - 榜单名称, 如"2020福布斯中国400富豪榜"; 访问forbeschina.com/lists获取

输出: 排名, 及根据symbol而异的其他字段

```python
forbes_rank_df = ak.forbes_rank(symbol="2020福布斯中国400富豪榜")
print(forbes_rank_df)
```

## xincaifu_rank

描述: 新财富500富豪榜(2003年至今)

输入: year - 年份如"2022"

输出: 排名, 财富(亿元), 姓名, 主要公司, 相关行业, 公司总部, 性别, 年龄, 年份

```python
xincaifu_rank_df = ak.xincaifu_rank(year="2022")
print(xincaifu_rank_df)
```

## hurun_rank

描述: 胡润百富榜单(富豪榜/创业/500强/特色系列)

输入: indicator - {"胡润百富榜", "胡润全球富豪榜", "胡润印度榜", "胡润全球独角兽榜", "全球瞪羚企业榜", "胡润Under30s创业领袖榜", "胡润世界500强", "胡润艺术榜"}; year - 年份如"2023"

输出: 排名, 财富, 姓名, 企业, 行业(百富榜/全球富豪榜/独角兽榜); 排名, 排名变化, 企业估值, 企业信息, CEO, 行业(世界500强); 排名, 排名变化, 成交额, 姓名, 年龄, 艺术类别(艺术榜)

```python
hurun_rank_df = ak.hurun_rank(indicator="胡润百富榜", year="2023")
print(hurun_rank_df)
```

## movie_boxoffice_realtime

描述: 实时电影票房(每5分钟更新)

输入: 无

输出: 排序, 影片名称, 实时票房(万), 票房占比(%), 上映天数, 累计票房(万)

```python
movie_boxoffice_realtime_df = ak.movie_boxoffice_realtime()
print(movie_boxoffice_realtime_df)
```

## movie_boxoffice_daily

描述: 指定日期的电影票房

输入: date - 日期如"20240219"

输出: 排序, 影片名称, 单日票房(万), 环比变化(%), 累计票房(万), 平均票价(元), 场均人次, 口碑指数, 上映天数

```python
movie_boxoffice_daily_df = ak.movie_boxoffice_daily(date="20240219")
print(movie_boxoffice_daily_df)
```

## movie_boxoffice_weekly

描述: 指定日期所在完整周的票房数据

输入: date - 日期如"20240218"

输出: 排序, 影片名称, 排名变化, 单周票房(万), 环比变化(%), 累计票房(万), 平均票价, 场均人次, 口碑指数, 上映天数

```python
movie_boxoffice_weekly_df = ak.movie_boxoffice_weekly(date="20240218")
print(movie_boxoffice_weekly_df)
```

## movie_boxoffice_monthly

描述: 指定日期所在月份的票房数据

输入: date - 日期如"20240218"

输出: 排序, 影片名称, 单月票房(万), 月度占比(%), 平均票价, 场均人次, 上映日期, 口碑指数, 月内天数

```python
movie_boxoffice_monthly_df = ak.movie_boxoffice_monthly(date="20240218")
print(movie_boxoffice_monthly_df)
```

## movie_boxoffice_yearly

描述: 指定日期所在年度的票房数据

输入: date - 日期如"20240218"

输出: 排序, 影片名称, 类型, 总票房(万), 平均票价, 场均人次, 国家及地区, 上映日期

```python
movie_boxoffice_yearly_df = ak.movie_boxoffice_yearly(date="20240218")
print(movie_boxoffice_yearly_df)
```

## movie_boxoffice_yearly_first_week

描述: 指定日期所在年度的年度首周票房数据

输入: date - 日期如"20201018"

输出: 排序, 影片名称, 类型, 首周票房(万), 占总票房比重(%), 场均人次, 国家及地区, 上映日期, 首周天数

```python
movie_boxoffice_yearly_first_week_df = ak.movie_boxoffice_yearly_first_week(date="20201018")
print(movie_boxoffice_yearly_first_week_df)
```

## movie_boxoffice_cinema_daily

描述: 指定日期各影院的日票房数据

输入: date - 日期如"20240219"

输出: 排序, 影院名称, 单日票房(元), 单日场次, 场均人次, 场均票价, 上座率(%)

```python
movie_boxoffice_cinema_daily_df = ak.movie_boxoffice_cinema_daily(date="20240219")
print(movie_boxoffice_cinema_daily_df)
```

## movie_boxoffice_cinema_weekly

描述: 指定日期完整周各影院的票房数据

输入: date - 日期如"20240219"

输出: 排序, 影院名称, 当周票房(万), 单银幕票房(元), 场均人次, 单日单厅票房, 单日单厅场次

```python
movie_boxoffice_cinema_weekly_df = ak.movie_boxoffice_cinema_weekly(date="20240219")
print(movie_boxoffice_cinema_weekly_df)
```

## video_tv

描述: 艺恩-视频放映-电视剧集(前一日数据)

输入: 无

输出: 排序, 名称, 类型, 播映指数, 媒体热度, 用户热度, 好评度, 观看度, 统计日期

```python
video_tv_df = ak.video_tv()
print(video_tv_df)
```

## video_variety_show

描述: 艺恩-视频放映-综艺节目(前一日数据)

输入: 无

输出: 排序, 名称, 类型, 播映指数, 媒体热度, 用户热度, 好评度, 观看度, 统计日期

```python
video_variety_show_df = ak.video_variety_show()
print(video_variety_show_df)
```

## business_value_artist

描述: 艺恩-艺人商业价值

输入: 无

输出: 排名, 艺人, 商业价值, 专业热度, 关注热度, 预测热度, 美誉度, 统计日期

```python
business_value_artist_df = ak.business_value_artist()
print(business_value_artist_df)
```

## online_value_artist

描述: 艺恩-艺人流量价值

输入: 无

输出: 排名, 艺人, 流量价值, 专业热度, 关注热度, 预测热度, 带货力, 统计日期

```python
online_value_artist_df = ak.online_value_artist()
print(online_value_artist_df)
```

## stock_js_weibo_report

描述: 微博舆情报告中近期受关注的股票

输入: time_period - 时间周期; CNHOUR2(2小时)/CNHOUR6(6小时)/CNHOUR12(12小时)/CNHOUR24(1天)/CNDAY7(1周)/CNDAY30(1月)

输出: name(股票名称), rate(人气排行指数)

```python
stock_js_weibo_report_df = ak.stock_js_weibo_report(time_period="CNHOUR12")
print(stock_js_weibo_report_df)
```

## index_bloomberg_billionaires

描述: 彭博实时亿万富豪指数(全球前500名, 需代理)

输入: 无

输出: rank, name, total_net_worth, last_change, YTD_change, country, industry

```python
index_bloomberg_billionaires_df = ak.index_bloomberg_billionaires()
print(index_bloomberg_billionaires_df)
```

## index_bloomberg_billionaires_hist

描述: 历史彭博亿万富豪指数(按年份, 需代理)

输入: year - 年份如"2021"

输出: rank, name, total_net_worth, last_change, YTD_change, country, industry, age

```python
index_bloomberg_billionaires_hist_df = ak.index_bloomberg_billionaires_hist(year="2019")
print(index_bloomberg_billionaires_hist_df)
```

## game_hot_rank_taptap

描述: TapTap平台游戏排行榜

输入: symbol - {"热玩榜", "热门榜", "新品榜", "预约榜", "热卖榜"}

输出: 排名, 游戏名称, 评分, 总点击量, 游玩次数, 评论数, 粉丝数, 标签, 推荐语, 发布时间, 游戏ID, 图标链接, 简介

```python
game_hot_rank_taptap_df = ak.game_hot_rank_taptap(symbol="热玩榜")
print(game_hot_rank_taptap_df)
```
