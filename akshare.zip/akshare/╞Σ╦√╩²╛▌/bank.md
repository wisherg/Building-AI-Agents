# 银行数据

```python
import akshare as ak
```

## bank_fjcf_table_detail

描述: 银保监分局本级行政处罚信息公开表

输入: page - 获取前N页数据; item - 选择类型, {"机关", "本级", "分局本级"}; begin - 开始页面

输出: 行政处罚决定书文号, 姓名, 单位, 单位名称, 主要负责人姓名, 主要违法违规事实（案由）, 行政处罚依据, 行政处罚决定, 作出处罚决定的机关名称, 作出处罚决定的日期

```python
bank_fjcf_table_detail_df = ak.bank_fjcf_table_detail(page=5, item="分局本级")
print(bank_fjcf_table_detail_df)
```
