# 高频数据

```python
import akshare as ak
```

## hf_sp_500

描述: 标普500指数分钟数据(仅2012-2018年, 建议使用代理)

输入: year - 年份, 如"2017"; 只能获取2012-2018年数据

输出: date(日期时间), open(开盘价), high(最高价), low(最低价), close(收盘价)

```python
hf_sp_500_df = ak.hf_sp_500(year="2017")
print(hf_sp_500_df)
```
